/********************************************************
** Copyright, 1998 - 2013, Intergraph Corporation. All rights reserved.
**
** FILE:     Resolution.h
** CREATED:  21Mar06 3:27:34 PM
** AUTHOR:   Simon Cope
** PURPOSE:  CFile class header
** EDITS:    [xx] ddMmmyy NAME COMMENTS
 *******************************************************/

#ifndef NCSECWRESOLUTION_H
#define NCSECWRESOLUTION_H

#include "NCSEcw/SDK/HashList_T.h"
#include "NCSEcw/ECW/PrecinctList.h"
#include "NCSEcw/SDK/Atomic.h"

namespace NCS {
namespace ECW {

class NCSECW_IMPEX CFile::CResolution: public SDK::NodeTiler2D_T<CFile::CPrecinctList::read_accessor, CPrecinctList::write_accessor> {
	public:
		CResolution(CFile *pFile, class CComponent *pComponent, UINT8 r);
		virtual ~CResolution();

		NCS_INLINE QmfLevel *Qmf() { return(m_pQmf); };
		NCS_INLINE void Qmf(QmfLevel *pQmf) { m_pQmf = pQmf; };

		NCS_INLINE UINT8 Index() {	return(m_nResolution); };

		NCS_INLINE CComponent *Component() { return(m_pComponent); };
		NCS_INLINE void Component(CComponent *pComponent) { m_pComponent = pComponent; };
		CFile *File() { return(Component()->File()); };

		NCS_INLINE INT16 BandBin() { return(m_nBandBin); };
		NCS_INLINE void BandBin(INT16 b) { m_nBandBin = b; };

		NCS_INLINE bool Precinct(CPrecinctList::read_accessor &acc_r, NCSBlockId n) {
						return(m_Precincts.find(acc_r, n));
					};
		NCS_INLINE bool Precinct(CPrecinctList::write_accessor &acc_w, NCSBlockId n) {
						return(m_Precincts.insert(acc_w, n));
					};
		// test temp
		//NCS_INLINE bool Precinct(CPrecinctList::read_accessor &acc_r, NCSBlockId n, INT32 nNodeNr) {
		//				return(m_vPrecincts[nNodeNr].find(acc_r, n));
		//			};
		//NCS_INLINE bool Precinct(CPrecinctList::write_accessor &acc_w, NCSBlockId n, INT32 nNodeNr) {
		//				return(m_vPrecincts[nNodeNr].insert(acc_w, n));
		//			};

		virtual bool Link(ContextID nCtx, UINT16 nInputs, CNode2D *pInput, ...);

		virtual bool UnLink(ContextID nCtx);

			/** 
			 * Get normal Node Width.
			 * @return      INT32		Un-clipped Width of codeblocks.
			 */
		virtual UINT32 GetNodeWidth(UINT16 iComponent = 0);
			/** 
			 * Get normal Node Height.
			 * @return      INT32		Un-clipped height of codeblocks.
			 */
		virtual UINT32 GetNodeHeight(UINT16 iComponent = 0);
			/** 
			 * Get number of nodes wide.
			 * @return      INT32		Nr of codeblocks across.
			 */
		virtual UINT32 GetNumNodesWide(UINT16 iComponent = 0);
			/** 
			 * Get number of nodes high.
			 * @return      INT32		Nr of codeblocks high.
			 */
		virtual UINT32 GetNumNodesHigh(UINT16 iComponent = 0);
			/** 
			 * Get pointer to specific node.
			 * @param		UINT32		Node nr
			 * @return      CNode2D * Ptr to node.
			 */
		virtual bool GetNode(CPrecinctList::read_accessor &acc_r, UINT32 nNode, UINT16 iComponent = 0);
		virtual bool GetNode(CPrecinctList::write_accessor &acc_w, UINT32 nNode, UINT16 iComponent = 0);

		NCS_INLINE CPrecinctList &Precincts() 
		{ 
			return(m_Precincts); 
		};
		//NCS_INLINE CPrecinctList &Precincts(INT32 nNodeNr) { return(m_vPrecincts[nNodeNr]); };

		NCS_INLINE NCSBlockId FirstPacketNr() { return(Qmf()->nFirstBlockNumber); };

		virtual NCSBlockId GetNeighbourId(NCSBlockId nId, Neighbour f);
		virtual NCSBlockId GetNeighbourId(UINT32 nX, UINT32 nY, Neighbour f);
		
		NCS::SDK::CAtomicUnsignedInt m_LastId;
		NCS::SDK::CAtomicInt64 m_X_Vector;
		NCS::SDK::CAtomicInt64 m_Y_Vector;
		NCS::SDK::CAtomicInt64 m_X_Count;
		NCS::SDK::CAtomicInt64 m_Y_Count;

		// test temp
		std::vector<UINT64> m_vNode_Count;

		void AddIncompletePrecinct( CPrecinct *pPrecinct )
		{
			if(File()->m_pStream->IsPacketStream()) {
				m_PrecinctsIncomplete.Add( pPrecinct );
			}
		}
		void EraseIncompletePrecinct()
		{
			if(File()->m_pStream->IsPacketStream()) {
				m_PrecinctsIncomplete.Erase();
			}
		}

		/** Node-row list, added on 12/05/2011 to reduce calculation for every line 
		 *  Each node-row holds the number of references which are decoding
		 */
		std::vector<UINT32> m_vNodeRowList;	// test temp

		virtual void AddRef(UINT32 inRowNr) {
			if (inRowNr < m_vNodeRowList.size())
				m_vNodeRowList[inRowNr]++;
		};

		virtual void UnRef(UINT32 inRowNr) {
			if (inRowNr < m_vNodeRowList.size() && m_vNodeRowList[inRowNr] > 0)
				m_vNodeRowList[inRowNr]--;
		};

	protected:
		//FIXME 
		QmfLevel	*m_pQmf;
		UINT8		m_nResolution;
		INT16		m_nBandBin;
		CComponent *m_pComponent;
		CPrecinctList m_Precincts;
		//std::vector<CPrecinctList> m_vPrecincts;

		// This is used to track the precincts that are decoded before all the required
		// blocks have arrived (ECWP)
		class CPrecinctIDList : public CMutex {
		public:
			CPrecinctIDList(CResolution *pResolution)
			{
				m_pResolution = pResolution;
			}

			void Add( CPrecinct *pPrecinct ) {
				CMutexLock lock(this);
				CPacketId id = pPrecinct->GetId();
				m_PrecinctList[id] = id;
			}

			void Erase()
			{
				CMutexLock lock(this);
				std::map<CPacketId, CPacketId>::iterator itCur = m_PrecinctList.begin();
				std::map<CPacketId, CPacketId>::iterator itEnd = m_PrecinctList.end();
				while( itCur != itEnd ) {
					m_pResolution->Precincts().erase(itCur->first);
					itCur++;
				}
				m_PrecinctList.clear();
			}
		protected:
			CResolution *m_pResolution;

			std::map<CPacketId, CPacketId> m_PrecinctList;
		};
		CPrecinctIDList m_PrecinctsIncomplete;
	};
};
};
#endif // !NCSECWRESOLUTION_H
