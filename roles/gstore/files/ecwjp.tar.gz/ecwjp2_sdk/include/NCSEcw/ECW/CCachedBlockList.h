/********************************************************
** Copyright, 1998 - 2013, Intergraph Corporation. All rights reserved.
**
** FILE:     CCachedBlockList.h
** CREATED:  21Mar06 3:27:34 PM
** AUTHOR:   Simon Cope
** PURPOSE:  CFile class header
** EDITS:    [xx] ddMmmyy NAME COMMENTS
 *******************************************************/

#ifndef NCSECWCCACHEDBLOCKLIST_H
#define NCSECWCCACHEDBLOCKLIST_H

#include "NCSEcw/SDK/HashList_T.h"
#include "NCSEcw/ECW/File.h"

namespace NCS {
namespace ECW {

	class CFile::CCachedBlockList: public SDK::HashList_T<CPacketId, CFile::CCachedBlock>, public CEvent {
	public:
		CCachedBlockList(CFile *pFile) : SDK::HashList_T<CPacketId, CFile::CCachedBlock>(-1) { m_pFile = pFile; }; // changed on 29/05/2012 according to HashList_T constructor change
		virtual ~CCachedBlockList() {};
		bool GetCacheBlock(write_accessor &acc_r, NCSBlockId nBlock, CFile::NCSEcwBlockRequestMethod eRequest);
		bool GetCacheBlock(read_accessor &acc_r, NCSBlockId nBlock, CFile::NCSEcwBlockRequestMethod eRequest);

		NCS::CPacketId FrontKey() {
			return (NCS::CPacketId)SDK::HashList_T<CPacketId, CFile::CCachedBlock>::m_Front;
		}
	protected:
		CFile *m_pFile;
	};
};
};
#endif // !NCSECWCCACHEDBLOCKLIST_H
