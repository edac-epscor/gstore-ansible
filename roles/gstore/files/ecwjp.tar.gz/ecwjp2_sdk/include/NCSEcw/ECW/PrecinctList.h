/********************************************************
** Copyright, 1998 - 2013, Intergraph Corporation. All rights reserved.
**
** This software is covered by US patent #6,442,298,
** #6,102,897 and #6,633,688.  Rights to use these patents 
** is included in the license agreements.
**
** FILE:     PrecinctList.h
** CREATED:  21Mar06 3:27:34 PM
** AUTHOR:   Simon Cope
** PURPOSE:  CFile class header
** EDITS:    [xx] ddMmmyy NAME COMMENTS
 *******************************************************/

#ifndef NCSECWPRECINCTLIST_H
#define NCSECWPRECINCTLIST_H

#include "NCSEcw/SDK/HashList_T.h"
#include "NCSEcw/ECW/File.h"

namespace NCS {
namespace ECW {

class CFile::CPrecinctList: public SDK::HashList_T<CPacketId, CPrecinct> 
{
public:
		CPrecinctList() : SDK::HashList_T<CPacketId, CPrecinct>(-1) {}; // added on 29/05/2012 according to HashList_T constructor change
		CPrecinctList(CResolution *p) : SDK::HashList_T<CPacketId, CPrecinct>(-1) { m_pResolution = p; }; // changed on 29/05/2012 according to HashList_T constructor change
		virtual ~CPrecinctList() {};
		bool GetNeighbour(read_accessor &acc_r, CPrecinct &P, Neighbour f);
		void Clear() {
			while(size()) {		
				erase_front();
			}
		};
		virtual bool FreeOne();
	protected:
		CResolution *m_pResolution;
};
class CFile::CPrecinctListWriteAccessor: public CFile::CPrecinctList::write_accessor {};	

}
}
#endif // !NCSECWPRECINCTLIST_H
