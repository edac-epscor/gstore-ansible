#ifndef STL_CONCURRENT_QUEUE_H
#define STL_CONCURRENT_QUEUE_H

#include <list>
#include "NCSMutex.h"

namespace NCS {
namespace SDK {
	
template<typename T>
class stl_concurrent_queue : public std::list<T>
{
public:
	stl_concurrent_queue(size_t nMaxSize = 1024) : m_nMaxSize(nMaxSize) {};
	virtual ~stl_concurrent_queue() {};

	void push(const T &Source) {
		m_Mutex.Lock();
		while(std::list<T>::size() > m_nMaxSize) {
			m_Mutex.UnLock();
			NCSSleep(1);
			m_Mutex.Lock();
		}
		std::list<T>::push_back(Source);
		m_Mutex.UnLock();
	}
	void pop(T &Destination) {
		m_Mutex.Lock();
		while(std::list<T>::size() == 0) {
			m_Mutex.UnLock();
			NCSSleep(1);
			m_Mutex.Lock();
		}
		Destination = std::list<T>::front();
		std::list<T>::pop_front();
		m_Mutex.UnLock();
	}

	bool try_push(const T &Source) {
		m_Mutex.Lock();
		if(std::list<T>::size() < m_nMaxSize) {
			std::list<T>::push_back(Source);
			m_Mutex.UnLock();
			return true;
		}
		m_Mutex.UnLock();
		return false;
	}
	bool try_pop(T &Destination) {
		m_Mutex.Lock();
		if(std::list<T>::size() > 0) {
			Destination = std::list<T>::front();
			std::list<T>::pop_front();
			m_Mutex.UnLock();
			return true;
		}
		m_Mutex.UnLock();
		return false;
	}

	std::list<T>::iterator unsafe_begin() { return std::list<T>::begin(); };
	std::list<T>::iterator unsafe_end() { return std::list<T>::end(); };
	
	size_t capacity() { return m_nMaxSize; };
	void set_capacity(size_t nCapacity) { m_nMaxSize = nCapacity; };
protected:
	NCS::CMutex m_Mutex;
	size_t m_nMaxSize;
};

} // SDK
} // NCS

#endif // STL_CONCURRENT_QUEUE_H
