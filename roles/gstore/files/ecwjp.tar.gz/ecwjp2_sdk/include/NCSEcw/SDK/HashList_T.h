/**********************************
** Copyright, 1998 - 2013, Intergraph Corporation. All rights reserved.
** 
** FILE:     HashList_T.h 
** CREATED:  13/12/2002 3:27:34 PM
** AUTHOR:   Simon Cope
** PURPOSE:  concurrent hash map wrapper with a sorted linked list for 
** 			 easy purging.
***********************************/
#ifndef HASHLIST_T_H
#define HASHLIST_T_H

#include <limits>

#include "NCSEcw/SDK/Atomic.h"
#include "NCSEcw/SDK/spin_lock.h"

#ifdef _MSC_VER
#pragma warning(push)
#pragma warning(disable: 4512 4245 4127)
#endif
#define __TBB_NO_IMPLICIT_LINKAGE 1
#include "tbb/concurrent_hash_map.h"
#ifdef _MSC_VER
#pragma warning(pop)
#endif
namespace NCS {
namespace SDK {

template<typename T> struct ItemsDefaultHash_T;
template<class Key_t, class Item, typename ItemHash = ItemsDefaultHash_T<Key_t> > class HashList_T {
public:
	class Item_T: public Item {
	public:
		Item_T() : m_nHits(), m_nUsed() {
				m_nHits = 0;
				m_nUsed = 0;
				m_pCache = NULL;
				m_nSeq = 0;
				m_pPrev = NULL;
				m_pNext = NULL;
		};

		Item_T(const Item_T &s) {
				*this = s;
			};
		virtual Item_T &operator=(const Item_T &s) {
				*(Item*)this = (Item&)s;
				m_pCache = s.m_pCache;

				m_nSeq = s.m_nSeq;
				m_nHits = s.m_nHits;
				m_K = s.m_K;
				m_nUsed = s.m_nUsed;

				if(m_pCache) {
					NCS::SDK::CSpinLock::CScopedLock _lock(m_pCache->m_Mutex);
					m_pPrev = s.m_pPrev;
					if(m_pPrev) {
						m_pPrev->m_pNext = this;
					}
					if(m_pCache->m_pFront == &s) {
						m_pCache->m_pFront = this;
					}
					m_pNext = s.m_pNext;
					if(m_pNext) {
						m_pNext->m_pPrev = this;
					}
					if(m_pCache->m_pBack == &s) {
						m_pCache->m_pBack = this;
					}
					((Item_T&)s).m_pPrev = NULL;
					((Item_T&)s).m_pNext = NULL;
				} else {
					m_pPrev = NULL;
					m_pNext = NULL;
				}
				return(*this);
			};
		virtual ~Item_T() {
				if(m_pCache) {
					m_pCache->remove(this);
				}
			};
		NCS_INLINE UINT64 sequence() { return(m_nSeq); };
		NCS_INLINE NCS::tbb::atomic<UINT64> &hits() { return(m_nHits); };
		NCS_INLINE Key_t key() { return(m_K); };
		bool used() { return !(m_nUsed==0); };

		Item_T *Next() { return m_pNext; };
		Item_T *Prev() { return m_pPrev; };

	protected:
		HashList_T<Key_t, Item, ItemHash> *m_pCache;
		UINT64 m_nSeq;
		NCS::tbb::atomic<UINT64> m_nHits;
		Key_t m_K;
		mutable NCS::tbb::atomic<INT32> m_nUsed;

		friend class HashList_T<Key_t, Item, ItemHash>;
		class Item_T *m_pPrev;
		class Item_T *m_pNext;

	};
protected:
	Key_t m_Front;
	Key_t m_Back;
	Item_T *m_pFront;
	Item_T *m_pBack;

public:
#if TBB_INTERFACE_VERSION == 4001
	typedef typename tbb::concurrent_hash_map<Key_t, Item_T, ItemHash > CCacheItems;
#else
	typedef typename tbb::interface5::concurrent_hash_map<Key_t, Item_T, ItemHash > CCacheItems;
#endif
	//typedef typename CCacheItems::const_accessor read_accessor;
	class read_accessor : public CCacheItems::const_accessor
	{
	public:
		read_accessor() : CCacheItems::const_accessor()
		{
		}
		virtual ~read_accessor()
		{
            if( !CCacheItems::const_accessor::empty() )
			{
				(*this)->second.m_nUsed--;
			}
		}
		void release() {
            if( !CCacheItems::const_accessor::empty() )
				(*this)->second.m_nUsed--;

			CCacheItems::const_accessor::release();
		}
	protected:
	};

	//typedef typename CCacheItems::accessor write_accessor;
	class write_accessor : public CCacheItems::accessor
	{
	public:
		write_accessor() : CCacheItems::accessor()
		{
		}
		virtual ~write_accessor()
		{
            if( !CCacheItems::accessor::empty() )
			{
				(*this)->second.m_nUsed--;
			}
		}
		void release() {
            if( !CCacheItems::accessor::empty() )
				(*this)->second.m_nUsed--;

			CCacheItems::accessor::release();
		}
	protected:
	};
	
protected:
	CCacheItems m_MC;
	Key_t		K_INVALID;
	NCS::tbb::atomic<UINT64> m_nSequence;
	NCS::tbb::atomic<UINT64> m_nNodes;
	NCS::tbb::atomic<UINT64> m_nListNodes;

	NCS::SDK::CSpinLock m_Mutex;

	NCS_INLINE virtual bool on_insert(write_accessor &acc_w) {
				Item_T *item = &acc_w->second;
				return(push_back(item));
			};
	NCS_INLINE virtual bool on_find(write_accessor &acc_w) {
				Item_T *item = &acc_w->second;
				return(move_back(item));
			};
	NCS_INLINE virtual bool on_find(read_accessor &acc_r) {
				Item_T *item = (Item_T*)&acc_r->second;
				return(move_back(item));
			};

public:
	//HashList_T() {
	HashList_T(Key_t InvalidValue) : m_nSequence(), m_nNodes(), m_nListNodes() { // added on 29/05/2012 
				m_nSequence = 0;
				m_nNodes = 0;
				m_nListNodes = 0;
				m_pFront = NULL;
				m_pBack = NULL;
				K_INVALID = InvalidValue;
				m_Front = K_INVALID;
				m_Back = K_INVALID;
			};
	virtual ~HashList_T() {
				m_MC.clear();
				m_pFront = NULL;
				m_pBack = NULL;
				m_Front = K_INVALID;
				m_Back = K_INVALID;
			};

	NCS_INLINE UINT64 size() { return(m_nNodes); };
	NCS_INLINE void clear() { return(m_MC.clear()); };
	NCS_INLINE bool empty() { return(m_nNodes == 0); };

	NCS_INLINE bool insert(write_accessor &acc_w, const Key_t K) {
				if(m_MC.insert(acc_w, K)) {
					m_nNodes++;
					Item_T *item = &acc_w->second;
					item->m_pCache = this;
					item->m_nSeq = m_nSequence++;
					item->m_nHits = 1;
					item->m_K = K;
					item->m_nUsed = 1;

					return(on_insert(acc_w));
				} else {
					Item_T *item = &acc_w->second;
					item->m_nHits++;
					item->m_nUsed++;
					move_back(item);
				}
				return(false);
			};
	NCS_INLINE bool find(write_accessor &acc_w, const Key_t K) {
				if(m_MC.find(acc_w, K)) {
					Item_T *item = &acc_w->second;

					item->m_nHits++;
					item->m_nUsed = 1;

					return(on_find(acc_w));
				}
				return(false);
			};
	NCS_INLINE bool find(read_accessor &acc_r, const Key_t K) {
				if(m_MC.find(acc_r, K)) {
					Item_T *item = (Item_T*)&acc_r->second;

					item->m_nHits++;
					item->m_nUsed++;

					return(on_find(acc_r));
				}
				return(false);
			};
	NCS_INLINE bool erase(const Key_t K) {
			if(m_MC.erase(K)) {
				m_nNodes--;
				return(true);
			}
			return(false);
		};
	NCS_INLINE bool erase(read_accessor &acc_r) {
			if(m_MC.erase(acc_r)) {
				m_nNodes--;
				return(true);
			}
			return(false);
		};
	NCS_INLINE bool erase(write_accessor &acc_w) {
			if(m_MC.erase(acc_w)) {
				m_nNodes--;
				return(true);
			}
			return(false);
		};
	NCS_INLINE bool maintenance_find(read_accessor &acc_r, const Key_t K) {
		if(m_MC.find(acc_r, K)) {
			Item_T *item = (Item_T*)&acc_r->second;
			item->m_nUsed++;
			return(true);
		}
		return(false);
	};
	NCS_INLINE bool maintenance_find(write_accessor &acc_w, const Key_t K) {
		if(m_MC.find(acc_w, K)) {
			Item_T *item = &acc_w->second;
			item->m_nUsed = 1;
			return(true);
		}
		return(false);
	};
	NCS_INLINE bool erase_front() {
			while(m_Front != K_INVALID) {
				if(erase(m_Front)) {
					return(true);
				}
			} 
			return(false);
		};
	NCS_INLINE bool try_erase_front() {
			read_accessor acc_r;
			if (m_MC.find(acc_r, m_Front)) {
				Item_T *item = (Item_T*)&acc_r->second;
				if (item->m_nUsed == 0) {
					Key_t key = item->m_K;
					acc_r.release();
					return erase(key);
				}
			}
			return(false);
		};
	// test temp added on 12/05/2012
	NCS_INLINE bool try_erase(read_accessor &acc_r) {
			Item_T *item = (Item_T*)&acc_r->second;
			if (item->m_nUsed == 0) {
				Key_t key = item->m_K;
				acc_r.release();
				return erase(key);
			}
			return(false);
		};
	// test temp added on 12/05/2012
	NCS_INLINE bool try_erase(const Key_t K) {
			read_accessor acc_r;
			if(m_MC.find(acc_r, K)) {
				Item_T *item = (Item_T*)&acc_r->second;
				if (item->m_nUsed == 0) {
					acc_r.release();
					return erase(K);
				}
			}
			return(false);
		};
	NCS_INLINE bool erase_front_if_unused(Key_t &keyOut) {
			Key_t key = K_INVALID;
			{
				NCS::SDK::CSpinLock::CScopedLock _lock(m_Mutex);
				if(m_Front != K_INVALID && m_pFront && !m_pFront->used() ) {
					key = m_Front;
				} 
			}
			if( key != K_INVALID ) {
				if(erase(key)) {
					keyOut = key;
					return true;
				}
			}
			return false;
		};
	NCS_INLINE bool erase_back() {
			while(m_Back != K_INVALID) {
				if(erase(m_Back)) {
					return(true);
				}
			} 
			return(false);
		};

	NCS_INLINE bool push_back(Item_T *item) {
			NCS::SDK::CSpinLock::CScopedLock _lock(m_Mutex);
			m_nListNodes++;

			if(!m_pFront) {
				m_pFront = item;
				m_Front = item->m_K;
				item->m_pPrev = NULL;
				item->m_pNext = NULL;
				m_pBack = item;
				m_Back = item->m_K;
			} else {
				m_pBack->m_pNext = item;
				item->m_pPrev = m_pBack;
				item->m_pNext = NULL;
				m_pBack = item;
				m_Back = item->m_K;
			}
			return(true);
		};
	NCS_INLINE bool remove(Item_T *item) {
			NCS::SDK::CSpinLock::CScopedLock _lock(m_Mutex);
			
			UINT64 n = 0;
				// more than 1 item and not already last in list...
			if(item->m_pPrev) {
				item->m_pPrev->m_pNext = item->m_pNext;
				n = 1;
			}
			if(item->m_pNext) {
				item->m_pNext->m_pPrev = item->m_pPrev;
				n = 1;
			} 
			if(m_pFront == item) {
				// item == First
				m_pFront = item->m_pNext;
				m_Front = m_pFront ? m_pFront->m_K : K_INVALID;
				n = 1;
			}
			if(m_pBack == item) {
				// item == Last
				m_pBack = item->m_pPrev;
				m_Back = m_pBack ? m_pBack->m_K : K_INVALID;
				n = 1;
			}
			item->m_pPrev = NULL;
			item->m_pNext = NULL;
			m_nListNodes -= n;
			return(true);
		};

#ifdef _DEBUG
	bool validate()
	{
		NCS::SDK::CSpinLock::CScopedLock _lock(m_Mutex);
		UINT64 nCount = 0;

		Item_T *pNext = m_pFront;
		while( pNext ) {
			nCount++;
			pNext = pNext->m_pNext;
		}
		return (nCount == m_nListNodes);
	}
#endif

	NCS_INLINE bool move_back(Item_T *item) {
			NCS::SDK::CSpinLock::CScopedLock _lock(m_Mutex);

			if(m_pBack != item) {
					// more than 1 item and not already last in list...
				if(item->m_pPrev) {
					item->m_pPrev->m_pNext = item->m_pNext;
				}
				if(item->m_pNext) {
					item->m_pNext->m_pPrev = item->m_pPrev;
				} 
				if(m_pFront == item) {
					// item == First
					m_pFront = item->m_pNext;
					m_Front = m_pFront ? m_pFront->m_K : K_INVALID;
				}
				if(!m_pFront) {
					m_pFront = item;
					m_Front = item->m_K;
					item->m_pPrev = NULL;
					item->m_pNext = NULL;
					m_pBack = item;
					m_Back = item->m_K;
				} else {
					m_pBack->m_pNext = item;
					item->m_pPrev = m_pBack;
					item->m_pNext = NULL;
					m_pBack = item;
					m_Back = item->m_K;
				}
			}
			return(true);
		};
};

template<typename T>
struct ItemsDefaultHash_T {
	static size_t hash( const T& t ) { return(size_t)(t % (std::numeric_limits<size_t>::max)()); }
    static bool equal( const T& a, const T& b ) { return a == b; }
	size_t operator()( const T& t ) const { return(size_t)(t % (std::numeric_limits<size_t>::max)()); };
};

};
};

#endif //HASHLIST_T_H
