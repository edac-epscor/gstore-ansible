#ifndef STL_CONCURRENT_HASH_MAP_H
#define STL_CONCURRENT_HASH_MAP_H

//#include <unordered_map>
#include "boost/unordered_map.hpp"

#include <functional>

#include "NCSUtil.h"
#include "NCSMultiLock.h"
#include "NCSEcw/SDK/spin_lock.h"

namespace NCS {
namespace SDK {

struct stl_concurrent_hash_map_node_base
{
	stl_concurrent_hash_map_node_base *pNext;
};

template<class K, class T>
class stl_concurrent_hash_map_node : public NCS::SDK::CSpinRWLock, public stl_concurrent_hash_map_node_base
{
public:
	stl_concurrent_hash_map_node(K key) : first(key), second() {
		stl_concurrent_hash_map_node::pNext = NULL;
	};

	stl_concurrent_hash_map_node(const stl_concurrent_hash_map_node &s) {
		(*this) = s;
	}
	stl_concurrent_hash_map_node &operator=(const stl_concurrent_hash_map_node &s) {
		pNext = s.pNext;
		first = s.first;
		second = s.second;
		return(*this);
	}

	T second;
	K first;
};

template<class K, class T>
class stl_concurrent_hash_map_const_accessor
{
public:
	stl_concurrent_hash_map_const_accessor() : m_pNode(NULL) {};
	virtual ~stl_concurrent_hash_map_const_accessor() { release(); };

	virtual bool try_acquire(stl_concurrent_hash_map_node<K, T> *pNode)
	{
		release();
		if(pNode && pNode->try_lock(false)) {
			m_pNode = pNode;
			return true;
		}
		return false;
	}
	virtual bool try_acquire(stl_concurrent_hash_map_node<K, T> &Node)
	{
		release();
		if(Node.try_lock(false)) {
			m_pNode = &Node;
			return true;
		}
		return false;
	}
	virtual void acquire(stl_concurrent_hash_map_node<K, T> *pNode)
	{
		release();
		pNode->lock(false);
		m_pNode = pNode;
	}
	virtual void acquire(stl_concurrent_hash_map_node<K, T> &Node)
	{
		release();
		Node.lock(false);
		m_pNode = &Node;
	}
	virtual void release()
	{
		if(m_pNode) {
			m_pNode->unlock(false);
			m_pNode = NULL;
		}
	}
	virtual bool empty() { return m_pNode == NULL; };
	const stl_concurrent_hash_map_node<K, T> *operator->() { return m_pNode; };
protected:
	stl_concurrent_hash_map_node<K, T> *m_pNode;
};

template<class K, class T>
class stl_concurrent_hash_map_accessor
{
public:
	stl_concurrent_hash_map_accessor() : m_pNode(NULL) {};
	virtual ~stl_concurrent_hash_map_accessor() { release(); };

	virtual bool try_acquire(stl_concurrent_hash_map_node<K, T> *pNode)
	{
		release();
		if(pNode && pNode->try_lock(true)) {
			m_pNode = pNode;
			return true;
		}
		return false;
	}
	virtual bool try_acquire(stl_concurrent_hash_map_node<K, T> &Node)
	{
		release();
		if(Node.try_lock(true)) {
			m_pNode = &Node;
			return true;
		}
		return false;
	}
	virtual void acquire(stl_concurrent_hash_map_node<K, T> *pNode)
	{
		release();
		pNode->lock(true);
		m_pNode = pNode;
	}
	virtual void acquire(stl_concurrent_hash_map_node<K, T> &Node)
	{
		release();
		Node.lock(true);
		m_pNode = &Node;
	}
	virtual void release()
	{
		if(m_pNode) {
			m_pNode->unlock(true);
			m_pNode = NULL;
		}
	}
	virtual bool empty() { return m_pNode == NULL; };
	stl_concurrent_hash_map_node<K, T> *operator->() { return m_pNode; };
protected:
	stl_concurrent_hash_map_node<K, T> *m_pNode;
};




template<typename T>
struct STL_ItemsDefaultHash_T {
	static size_t hash( const T& t ) { return(size_t)(t % (std::numeric_limits<size_t>::max)()); }
    static bool equal( const T& a, const T& b ) { return a == b; }
	size_t operator()( const T& t ) const { return(size_t)(t % (std::numeric_limits<size_t>::max)()); };
};


//template<class K, class T, class H, class P, class A>
template<class K, class T, class H = STL_ItemsDefaultHash_T<K>, class P = std::equal_to<K>, class A = std::allocator<std::pair<const K, T> > >
class stl_concurrent_hash_map : public NCS::SDK::CSpinRWLock
{
public:
	typedef stl_concurrent_hash_map_const_accessor<K, T> const_accessor;
	typedef stl_concurrent_hash_map_accessor<K, T> accessor;
	//typedef typename std::map<size_t, stl_concurrent_hash_map_bucket>::iterator bucket_iterator;
	//typedef typename std::map<size_t, stl_concurrent_hash_map_bucket>::const_iterator const_bucket_iterator;

protected:

	struct cache_bucket
	{
		NCS::SDK::CSpinRWLock m_Lock;
		NCS::SDK::stl_concurrent_hash_map_node_base *m_pNext;
	};
	typedef std::vector<cache_bucket> CBucketVector;

	class cache_segment : public CBucketVector {
	public:
		cache_segment(size_t nBucketCount) {
			m_pBucketSizes = (unsigned char *)NCSMalloc((UINT32)nBucketCount * sizeof(unsigned char), TRUE);
			CBucketVector::resize(nBucketCount);
			CBucketVector &B = *this;
			for(size_t nI = 0; nI < nBucketCount; nI++) {
				B[nI].m_pNext = NULL;
			}
		}
		virtual ~cache_segment() {
			size_t nBucketCount = CBucketVector::size();
			CBucketVector &B = *this;
			for(size_t nI = 0; nI < nBucketCount; nI++) {
				NCS::SDK::stl_concurrent_hash_map_node_base *pNode = B[nI].m_pNext;
				while(pNode != NULL) {
					pNode = (CMapNode*)pNode->pNext;
					delete pNode;
				}
			}
		}

		class const_bucket_accessor {
		public:
			const_bucket_accessor() : m_pBucket(NULL) {
			}
			virtual ~const_bucket_accessor() {
				release();
			}
			bool acquire(cache_segment &Segment, size_t nPseudoKey) {
				release();
				for(; ;) {
					if(Segment[nPseudoKey].m_Lock.try_lock(false)) {
						m_pBucket = &Segment[nPseudoKey];
						return true;
					}
				}
			}
			bool try_acquire(cache_segment &Segment, size_t nPseudoKey) {
				release();
				if(Segment[nPseudoKey].m_Lock.try_lock(false)) {
					m_pBucket = &Segment[nPseudoKey];
					return true;
				}
				return false;
			}
			void release() {
				if(m_pBucket) {
					m_pBucket->m_Lock.unlock(false);
					m_pBucket = NULL;
				}
			}

			cache_bucket *operator->() { return m_pBucket; };
		protected:
			cache_bucket *m_pBucket;
		};

		class bucket_accessor {
		public:
			bucket_accessor() : m_pBucket(NULL) {
			}
			virtual ~bucket_accessor() {
				release();
			}
			bool acquire(cache_segment &Segment, size_t nPseudoKey) {
				release();
				for(; ;) {
					if(Segment[nPseudoKey].m_Lock.try_lock(true)) {
						m_pBucket = &Segment[nPseudoKey];
						return true;
					}
				}
			}
			bool try_acquire(cache_segment &Segment, size_t nPseudoKey) {
				release();
				if(Segment[nPseudoKey].m_Lock.try_lock(true)) {
					m_pBucket = &Segment[nPseudoKey];
					return true;
				}
				return false;
			}
			void release() {
				if(m_pBucket) {
					m_pBucket->m_Lock.unlock(true);
					m_pBucket = NULL;
				}
			}
			cache_bucket *operator->() { return m_pBucket; };
		protected:
			cache_bucket *m_pBucket;
		};

		void acquire(bucket_accessor &acc_w, size_t nPseudoKey) {
			acc_w.acquire(*this, nPseudoKey);
		}
		void acquire(const_bucket_accessor &acc_r, size_t nPseudoKey) {
			acc_r.acquire(*this, nPseudoKey);
		}
		bool try_acquire(bucket_accessor &acc_w, size_t nPseudoKey) {
			return acc_w.try_acquire(*this, nPseudoKey);
		}
		bool try_acquire(const_bucket_accessor &acc_r, size_t nPseudoKey) {
			return acc_r.try_acquire(*this, nPseudoKey);
		}
		unsigned char *m_pBucketSizes;
	};


	typedef std::vector<cache_segment *> CSegmentVector;
	CSegmentVector m_Segments;

	size_t m_nBucketsPerSegment, m_nMaxItemsPerBucket;
	
	typedef boost::unordered_map<K, int, H> CPseudoKeySegmentMap;
	CPseudoKeySegmentMap m_PseudoKeyMap;
	
	typedef stl_concurrent_hash_map_node<K, T> CMapNode;

	cache_segment *GetKeySegment(const K &Key) {
		cache_segment *pSegment = NULL;
		NCS::SDK::CSpinRWLock::lock(false);
		CPseudoKeySegmentMap::const_iterator it = m_PseudoKeyMap.find(Key);
		if(it != m_PseudoKeyMap.end()) {
			pSegment = m_Segments[it->second];
		}
		NCS::SDK::CSpinRWLock::unlock(false);

		return pSegment;
	}
	bool InsertKeySegment(const K &Key, int nCacheSegment) {
		bool bRet = false;
		NCS::SDK::CSpinRWLock::lock(true);
		CPseudoKeySegmentMap::const_iterator it = m_PseudoKeyMap.find(Key);
		if(it == m_PseudoKeyMap.end()) {
			m_PseudoKeyMap.insert(std::pair<K, int>(Key, nCacheSegment));
			bRet = true;
		}
		NCS::SDK::CSpinRWLock::unlock(true);
		return bRet;
	}
	void RemoveKeySegment(const K &Key) {
		NCS::SDK::CSpinRWLock::lock(true);
		CPseudoKeySegmentMap::const_iterator it = m_PseudoKeyMap.find(Key);
		if(it != m_PseudoKeyMap.end()) {
			m_PseudoKeyMap.erase(it);
		}
		NCS::SDK::CSpinRWLock::unlock(true);
	}
	cache_segment *GrowSegment(int &nSegment) {
		cache_segment *pSegment = new cache_segment(m_nBucketsPerSegment);
		NCS::SDK::CSpinRWLock::lock(true);
		nSegment = (int)m_Segments.size();
		m_Segments.push_back(pSegment);
		NCS::SDK::CSpinRWLock::unlock(true);
		return pSegment;
	}

	cache_segment *GetSegment(int nSegment) {
		cache_segment *pSegment = NULL;
		NCS::SDK::CSpinRWLock::lock(false);
		if(nSegment < m_Segments.size()) {
			pSegment = m_Segments[nSegment];
		}
		NCS::SDK::CSpinRWLock::unlock(false);
		return pSegment;
	}

	friend class iterator;
public:
	stl_concurrent_hash_map(size_t nBucketsPerSegment = 1024, size_t nMaxItemsPerBucket = 3) : m_nBucketsPerSegment(nBucketsPerSegment), m_nMaxItemsPerBucket(nMaxItemsPerBucket) {
		m_Segments.resize(1);
		m_Segments.reserve(8);
		m_Segments[0] = new cache_segment(m_nBucketsPerSegment);
	}
	virtual ~stl_concurrent_hash_map() {
		clear();
	}

	bool find(const_accessor &acc_r, const K &Key) 
	{
		acc_r.release();

		cache_segment *pSegment = GetKeySegment(Key);
		if(pSegment == NULL) {
			return false;
		}
		size_t nPseudoKey = H::hash(Key);
		nPseudoKey %= m_nBucketsPerSegment;
		cache_segment::const_bucket_accessor acc_rB;

		for(; ;) {
			if(pSegment->try_acquire(acc_rB, nPseudoKey)) {
				CMapNode *pNode = (CMapNode*)acc_rB->m_pNext;
				while(pNode != NULL) {
					if(H::equal(Key, pNode->first)) {
						if(acc_r.try_acquire(pNode)) {
							return true;
						} else {
							break;
						}
					}
					pNode = (CMapNode*)pNode->pNext;
				}
				if(pNode == NULL) {
					// node removed
					return false;
				}
			}
		}
	}

	bool try_find(const_accessor &acc_r, const K &Key) 
	{
		acc_r.release();

		cache_segment *pSegment = GetKeySegment(Key);
		if(pSegment == NULL) {
			return false;
		}
		size_t nPseudoKey = H::hash(Key);
		nPseudoKey %= m_nBucketsPerSegment;
		cache_segment::const_bucket_accessor acc_rB;

		if(pSegment->try_acquire(acc_rB, nPseudoKey)) {
			CMapNode *pNode = (CMapNode*)acc_rB->m_pNext;
			while(pNode != NULL) {
				if(H::equal(Key, pNode->first)) {
					return acc_r.try_acquire(pNode);
				}
				pNode = (CMapNode*)pNode->pNext;
			}
			return false;
		}
	}

	bool try_find(accessor &acc_w, const K &Key) 
	{
		acc_w.release();

		cache_segment *pSegment = GetKeySegment(Key);
		if(pSegment == NULL) {
			return false;
		}
		size_t nPseudoKey = H::hash(Key);
		nPseudoKey %= m_nBucketsPerSegment;
		cache_segment::const_bucket_accessor acc_rB;

		for(; ;) {
			if(pSegment->try_acquire(acc_rB, nPseudoKey)) {
				CMapNode *pNode = (CMapNode*)acc_rB->m_pNext;
				while(pNode != NULL) {
					if(H::equal(Key, pNode->first)) {
						return acc_w.try_acquire(pNode);
					}
					pNode = (CMapNode*)pNode->pNext;
				}
				return false;
			}
		}
	}
		
	bool find(accessor &acc_w, const K &Key) 
	{
		acc_w.release();

		cache_segment *pSegment = GetKeySegment(Key);
		if(pSegment == NULL) {
			return false;
		}
		size_t nPseudoKey = H::hash(Key);
		nPseudoKey %= m_nBucketsPerSegment;
		cache_segment::const_bucket_accessor acc_rB;

		for(; ;) {
			if(pSegment->try_acquire(acc_rB, nPseudoKey)) {
				CMapNode *pNode = (CMapNode*)acc_rB->m_pNext;
				while(pNode != NULL) {
					if(H::equal(Key, pNode->first)) {
						if(acc_w.try_acquire(pNode)) {
							return true;
						} else {
							break;
						}
					}
					pNode = (CMapNode*)pNode->pNext;
				}
				if(pNode == NULL) {
					// node removed
					return false;
				}
			}
		}
	}

	bool insert(accessor &acc_w, const K &Key) 
	{
		acc_w.release();

		size_t nPseudoKey = H::hash(Key);
		nPseudoKey %= m_nBucketsPerSegment;
restart:
		cache_segment *pSegment = GetKeySegment(Key);

		if(pSegment != NULL) {
			cache_segment::const_bucket_accessor acc_rB;
			for(; ;) {
				if(pSegment->try_acquire(acc_rB, nPseudoKey)) {
					CMapNode *pNode = (CMapNode*)acc_rB->m_pNext;
					while(pNode != NULL) {
						if(H::equal(Key, pNode->first)) {
							if(acc_w.try_acquire(pNode)) {
								return false;
							} else {
								break;
							}
						}
						pNode = (CMapNode*)pNode->pNext;
					}
					if(pNode == NULL) {
						//erased
						break;
					}
				}
			}
		}

		for(; ;) {
			int nSegment = 0;
			cache_segment *pSegment = GetSegment(nSegment);
			while(pSegment) {
				if(pSegment->m_pBucketSizes[nPseudoKey] < m_nMaxItemsPerBucket) {
					cache_segment::bucket_accessor acc_rB;
					for(; ;) {
						if(pSegment->try_acquire(acc_rB, nPseudoKey)) {
							if(pSegment->m_pBucketSizes[nPseudoKey] >= m_nMaxItemsPerBucket) {
								// bucket full continue to next segment
								break;
							}
							CMapNode *pNode = (CMapNode*)acc_rB->m_pNext;
							if(pNode == NULL) {
								if(InsertKeySegment(Key, nSegment)) {
									acc_rB->m_pNext = new stl_concurrent_hash_map_node<K, T>(Key);
									acc_w.acquire((CMapNode*)acc_rB->m_pNext);
									pSegment->m_pBucketSizes[nPseudoKey] = 1;
									return true;
								} else {
									goto restart;
								}							
							}
							while(pNode != NULL) {
								if(H::equal(Key, pNode->first)) {
									if(acc_w.try_acquire(pNode)) {
										// item inserted by another thread
										return false;
									} else {
										// item inserted by another thread but inaccessible.
										goto restart;
									}
								}
								if(pNode->pNext == NULL) {
									if(InsertKeySegment(Key, nSegment)) {
										pNode->pNext = new stl_concurrent_hash_map_node<K, T>(Key);
										pSegment->m_pBucketSizes[nPseudoKey]++;
										acc_w.acquire((CMapNode*)pNode->pNext);
										return true;
									} else {
										goto restart;
									}				
								}
								pNode = (CMapNode*)pNode->pNext;
							}
						}
					}
				}
				pSegment = GetSegment(++nSegment);
			}
			for(; ;) {
regrow:
				pSegment = GrowSegment(nSegment);
				if(pSegment->m_pBucketSizes[nPseudoKey] < m_nMaxItemsPerBucket) {
					cache_segment::bucket_accessor acc_rB;
					if(pSegment->try_acquire(acc_rB, nPseudoKey)) {
						if(pSegment->m_pBucketSizes[nPseudoKey] >= m_nMaxItemsPerBucket) {
							// bucket full continue to next segment
							goto regrow;
						}
						CMapNode *pNode = (CMapNode*)acc_rB->m_pNext;
						if(pNode == NULL) {
							if(InsertKeySegment(Key, nSegment)) {
								acc_rB->m_pNext = new stl_concurrent_hash_map_node<K, T>(Key);
								pSegment->m_pBucketSizes[nPseudoKey] = 1;
								acc_w.acquire((CMapNode*)acc_rB->m_pNext);
								return true;
							} else {
								goto restart;
							}	
						}
						while(pNode != NULL) {
							if(H::equal(Key, pNode->first)) {
								if(acc_w.try_acquire(pNode)) {
									// item inserted by another thread
									return false;
								} else {
									// item inserted by another thread but inaccessible.  spin.
									goto restart;
								}
							}
							if(pNode->pNext == NULL) {
								if(InsertKeySegment(Key, nSegment)) {
									pNode->pNext = new stl_concurrent_hash_map_node<K, T>(Key);
									pSegment->m_pBucketSizes[nPseudoKey]++;
									acc_w.acquire((CMapNode*)pNode->pNext);
									return true;
								} else {
									goto restart;
								}	
							}
							pNode = (CMapNode*)pNode->pNext;
						}
					}
				}
			}
		}
	}

	bool erase(accessor &acc_w)
	{
		if(acc_w.empty()) {
			return false;
		}
		size_t nPseudoKey = H::hash(acc_w->first);
		nPseudoKey %= m_nBucketsPerSegment;

		cache_segment *pSegment = GetKeySegment(acc_w->first);
		if(pSegment == NULL) {
			acc_w.release();
			return false;
		}
		cache_segment::bucket_accessor acc_rB;
		for(; ;) {
			if(pSegment->try_acquire(acc_rB, nPseudoKey)) {
				CMapNode *pNode = (CMapNode*)acc_rB->m_pNext;
				if(pNode != NULL) {
					if(H::equal(acc_w->first, pNode->first)) {
						acc_rB->m_pNext = pNode->pNext;
						RemoveKeySegment(acc_w->first);
						acc_w.release();
						delete pNode;
						pSegment->m_pBucketSizes[nPseudoKey]--;
						return true;
					}
					CMapNode *pNodePrev = pNode;
					pNode = (CMapNode*)pNode->pNext;
					while(pNode != NULL) {
						if(H::equal(acc_w->first, pNode->first)) {
							pNodePrev->pNext = pNode->pNext;
							RemoveKeySegment(acc_w->first);
							acc_w.release();
							delete pNode;
							pSegment->m_pBucketSizes[nPseudoKey]--;
							return true;
						}
						pNodePrev = pNode;
						pNode = (CMapNode*)pNode->pNext;
					}
				}
				if(pNode == NULL) {
					return false;
				}
			}
		}
		return false;
	}

	bool erase(const K &Key)
	{
		accessor acc_w;
		if(try_find(acc_w, Key)) {
			return erase(acc_w);
		}
		return false;
	}

	void clear()
	{
		for(size_t nI = 0; nI < m_Segments.size(); nI++) {
			delete m_Segments[nI];
		}
		m_Segments.clear();
	}

	//class iterator
	//{
	//public:
	//	virtual ~iterator() {};
	//	
	//	CMapNode& operator*() {
	//		return *m_pCurrentNode;
	//	}

	//	CMapNode& operator++() {
	//		Increment();
	//		return *m_pCurrentNode;
	//	}

	//	CMapNode &operator++(int) {	
	//		CMapNode *pOld = m_pCurrentNode;
	//		Increment();
	//		return *pOld;
	//	}

	//protected:
	//	iterator(stl_concurrent_hash_map *pMap) : m_pMap(pMap) {
	//		m_pCurrentSegment = m_pMap->GetSegment(0);
	//		m_nSegmentIndex = m_nBucketIndex = m_nCurrentIndex = 0;
	//		m_pCurrentBucket = (*((CBucketVector*)m_pCurrentSegment))[0];
	//		m_pCurrentNode = (CMapNode *)m_pCurrentBucket->m_pNext;
	//		if(m_pCurrentNode == NULL) {
	//			Increment();
	//		}
	//	}
	//	
	//	bool Increment_Node() {
	//		if(m_pCurrentNode == NULL || m_pCurrentNode->pNext == NULL) {
	//			return false;
	//		}
	//		while(m_nCurrentIndex < m_pMap->m_nMaxItemsPerBucket) {
	//			m_nCurrentIndex++;
	//			m_pCurrentNode = (CMapNode *)m_pCurrentNode->pNext;
	//			if(m_pCurrentNode != NULL) {
	//				return true;
	//			}
	//		}
	//		return false;
	//	}

	//	bool Increment_Bucket() {
	//		if(m_nBucketIndex >= m_pMap->m_nBucketsPerSegment) {
	//			return false;
	//		}



	//		while(m_nCurrentIndex < m_pMap->m_nMaxItemsPerBucket) {
	//			m_nCurrentIndex++;
	//			m_pCurrentNode = (CMapNode *)m_pCurrentNode->pNext;
	//			if(m_pCurrentNode != NULL) {
	//				return true;
	//			}
	//		}
	//		return false;
	//	}

	//	void Increment() {
	//		if(!Increment_Node()) {

	//		}
	//		do {
	//			if(m_pCurrentNode != NULL && m_pCurrentNode->pNext != NULL) {
	//				m_nCurrentIndex++;
	//				m_pCurrentNode = (CMapNode *)m_pCurrentNode->pNext;
	//				return;
	//			}
	//			if(m_nBucketIndex < m_pMap->m_nBucketsPerSegment) {
	//				m_pCurrentBucket = m_pCurrentSegment[++m_nBucketIndex];
	//				m_nCurrentIndex = 0;
	//				m_pCurrentNode = (CMapNode *)m_pCurrentBucket->m_pNext;
	//				return;
	//			}
	//		} while(m_pCurrentNode == NULL);
	//	}

	//	CMapNode *m_pCurrentNode;
	//	stl_concurrent_hash_map *m_pMap;
	//	cache_segment *m_pCurrentSegment;
	//	cache_bucket *m_pCurrentBucket;
	//	int m_nCurrentIndex, int m_nBucketIndex, int m_nSegmentIndex;
	//	
	//};

	//iterator begin() {
	//}

	/*
	
	bool erase(accessor &acc_w)
	{
		NCS::CExclusiveLock _Lock(m_Mutex);
		typename std::unordered_map<K, node<T> *, H, P, A>::iterator it = std::unordered_map<K, node<T> *, H, P, A>::find(acc_w.Key());
		if(it == std::unordered_map<K, node<T> *, H, P, A>::end()) {
			return false;
		}
		acc_w.release();
		delete it->second;
		std::unordered_map<K, node<T> *, H, P, A>::erase(it);
		return true;
	}

	bool erase(const K &Key)
	{
		for(; ;) {
			accessor acc_w;
			NCS::CExclusiveLock _Lock(m_Mutex);
			typename std::unordered_map<K, node<T> *, H, P, A>::iterator it = std::unordered_map<K, node<T> *, H, P, A>::find(Key);
			if(it == std::unordered_map<K, node<T> *, H, P, A>::end()) {
				return false;
			}
			if(acc_w.try_acquire(Key, it->second)) {
				acc_w.release();
				delete it->second;
				std::unordered_map<K, node<T> *, H, P, A>::erase(it);
				return true;
			}
		}
	}

	void clear()
	{
		m_Mutex.UnLockExclusive();
		typename std::unordered_map<K, node<T> *, H, P, A>::iterator it = std::unordered_map<K, node<T> *, H, P, A>::begin();
		while(it != std::unordered_map<K, node<T> *, H, P, A>::end()) {
			if(it->second) {
				delete it->second;
				it->second = NULL;
			}
			it++;
		}
		std::unordered_map<K, node<T> *, H, P, A>::clear();
	}

	void clear_free()
	{
		m_Mutex.UnLockExclusive();
		typename std::unordered_map<K, node<T> *, H, P, A>::iterator it = std::unordered_map<K, node<T> *, H, P, A>::begin();
		while(it != std::unordered_map<K, node<T> *, H, P, A>::end()) {
			if(it->second) {
				if(it->second->second) {
					delete it->second->second;
					it->second->second = NULL;
				}
				delete it->second;
				it->second = NULL;
			}
			it++;
		}
		std::unordered_map<K, node<T> *, H, P, A>::clear();
	}
	*/
};

} // SDK
} // NCS

#endif // STL_CONCURRENT_HASH_MAP_H