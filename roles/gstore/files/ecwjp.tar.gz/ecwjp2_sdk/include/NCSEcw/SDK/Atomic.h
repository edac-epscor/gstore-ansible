/********************************************************** 
** Copyright, 1998 - 2013, Intergraph Corporation. All rights reserved.
** 
** FILE:   	Atomic.h
** CREATED:	01/03/2013
** PURPOSE:	Public Atomic wrapper class
**
********************************************************/

#ifndef NCS_SDK_ATOMIC_H
#define NCS_SDK_ATOMIC_H

#include "NCSDefs.h"

namespace NCS {
namespace SDK {

template<typename T> class CAtomicImpl;

class NCSECW_IMPEX CAtomicBool {
public:
	CAtomicBool(const bool Value = false);
	CAtomicBool(const CAtomicBool &s);
	virtual ~CAtomicBool();
	const CAtomicBool &operator=(const CAtomicBool &s);
	operator bool() const;
	void operator=(const bool &Value);
	bool operator+=(const bool &Value);
	bool operator-=(const bool &Value);
	bool operator++();
	bool operator--();
	bool operator++(int);
	bool operator--(int);
protected:
	CAtomicImpl<bool> *m_pValue;
};

class NCSECW_IMPEX CAtomicInt {
public:
	CAtomicInt(const int Value = 0);
	CAtomicInt(const CAtomicInt &s);
	virtual ~CAtomicInt();
	const CAtomicInt &operator=(const CAtomicInt &s);
	operator int() const;
	void operator=(const int &Value);
	int operator+=(const int &Value);
	int operator-=(const int &Value);
	int operator++();
	int operator--();
	int operator++(int);
	int operator--(int);
protected:
	CAtomicImpl<int> *m_pValue;
};

class NCSECW_IMPEX CAtomicUnsignedInt {
public:
	CAtomicUnsignedInt(const UINT32 Value = 0);
	CAtomicUnsignedInt(const CAtomicUnsignedInt &s);
	virtual ~CAtomicUnsignedInt();
	const CAtomicUnsignedInt &operator=(const CAtomicUnsignedInt &s);
	operator UINT32() const;
	void operator=(const UINT32 &Value);
	UINT32 operator+=(const UINT32 &Value);
	UINT32 operator-=(const UINT32 &Value);
	UINT32 operator++();
	UINT32 operator--();
	UINT32 operator++(int);
	UINT32 operator--(int);
protected:
	CAtomicImpl<UINT32> *m_pValue;
};

//class CAtomicFloat {
//public:
//	CAtomicFloat(const float Value = 0.0f);
//	virtual ~CAtomicFloat();
//
//	operator float() const;
//	void operator=(const float &Value);
//	float operator+=(const float &Value);
//	float operator-=(const float &Value);
//	float operator++();
//	float operator--();
//	float operator++(int);
//	float operator--(int);
//protected:
//	CAtomicImpl<float> *m_pValue;
//};
//
//class CAtomicDouble {
//public:
//	CAtomicDouble(const double Value = 0.0);
//	virtual ~CAtomicDouble();
//
//	operator double() const;
//	void operator=(const double &Value);
//	double operator+=(const double &Value);
//	double operator-=(const double &Value);
//	double operator++();
//	double operator--();
//	double operator++(int);
//	double operator--(int);
//protected:
//	CAtomicImpl<double> *m_pValue;
//};

class NCSECW_IMPEX CAtomicInt64 {
public:
	CAtomicInt64(const INT64 Value = 0);
	CAtomicInt64(const CAtomicInt64 &s);
	virtual ~CAtomicInt64();
	const CAtomicInt64 &operator=(const CAtomicInt64 &s);
	operator INT64() const;
	void operator=(const INT64 &Value);
	INT64 operator+=(const INT64 &Value);
	INT64 operator-=(const INT64 &Value);
	INT64 operator++();
	INT64 operator--();
	INT64 operator++(int);
	INT64 operator--(int);
protected:
	CAtomicImpl<INT64> *m_pValue;
};

class NCSECW_IMPEX CAtomicUnsignedInt64 {
public:
	CAtomicUnsignedInt64(const UINT64 Value = 0);
	CAtomicUnsignedInt64(const CAtomicUnsignedInt64 &s);
	virtual ~CAtomicUnsignedInt64();
	const CAtomicUnsignedInt64 &operator=(const CAtomicUnsignedInt64 &s);

	operator UINT64() const;
	void operator=(const UINT64 &Value);
	UINT64 operator+=(const UINT64 &Value);
	UINT64 operator-=(const UINT64 &Value);
	UINT64 operator++();
	UINT64 operator--();
	UINT64 operator++(int);
	UINT64 operator--(int);
protected:
	CAtomicImpl<UINT64> *m_pValue;
};

} // SDK
} // NCS

#endif // NCS_SDK_ATOMIC_H