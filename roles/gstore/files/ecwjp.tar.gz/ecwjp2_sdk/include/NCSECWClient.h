/********************************************************** 
** Copyright, 1998 - 2013, Intergraph Corporation. All rights reserved.
** 
** FILE:   	NCSECWClient.h
** CREATED:	08 May 1999
** PURPOSE:	Public client interface to ECW JP2 image decompression library
**
********************************************************/

/** @file NCSECWClient.h */

#ifndef NCSECWCLIENT_H
#define NCSECWCLIENT_H

#ifndef NCSDEFS_H
#include "NCSDefs.h"
#endif
#ifndef NCSERRORS_H
#include "NCSErrors.h"
#endif

#include "NCSEcw/GTIF/geo_public_defs.h"
#include "NCSEcw/GTIF/geokeys.h"

#define NCS_V3_COMPAT_NAMES
#ifdef NCS_V3_COMPAT_NAMES
#include "NCSECWCompatibility.h"
#endif


#ifdef __cplusplus
extern "C" {
#endif

#ifndef ERS_WAVELET_DATASET_EXT
/**
 *	@def 
 *	Allowed file extensions for ECW files.
 */
#define ERS_WAVELET_DATASET_EXT	".ecw"
#define ERS_WAVELET_DATASET_EXT_T	NCS_T(".ecw")
#endif

#ifndef ERS_JP2_DATASET_EXTS 
/**	
 *	@def
 *	Allowed file extensions for JPEG 2000 files.
 */
#define ERS_JP2_DATASET_EXTS	{ ".jp2" , ".j2k" , ".j2c" , ".jpc", ".jpx", ".jpf" } /*[12]*/
#define ERS_JP2_DATASET_EXTS_T	{ NCS_T(".jp2"), NCS_T(".j2k"), NCS_T(".j2c"), NCS_T(".jpc"), NCS_T(".jpx"), NCS_T(".jpf") } /*[12]*/
#endif

#ifndef ERS_JP2_WORLD_FILE_EXTS
/**	
 *	@def
 *	World filename extension definitions.
 */
#define ERS_JP2_WORLD_FILE_EXTS	{ ".j2w" , ".jxw" , ".jfw" }  
#endif

#ifndef ERSWAVE_VERSION_STRING
/**	
 *	@def
 *	Current version of the ECW format
 */
#define ERSWAVE_VERSION_STRING	"3.0"
#endif

#ifndef NCS_ECW_PROXY_KEY
#define NCS_ECW_PROXY_KEY		"ECWP Proxy"
#define NCS_ECW_PROXY_KEY_T		NCS_T("ECWP Proxy")
#endif

/** 
 *	@enum
 *  Enumerated type for the return status from read line routines.
 *	The application should treat CANCELLED operations as non-fatal,
 *	in that they most likely mean this view read was cancelled for
 *	performance reasons.
 */
typedef enum {
	/** Successful read */
	NCS_READ_OK			= 0,
	/** Read failed due to an error */
	NCS_READ_FAILED		= 1,
	/** Read was cancelled, either because a new SetView arrived or a 
	    library shutdown is in progress */
	NCS_READ_CANCELLED	= 2	
} NCSReadStatus;

/** 
 *	@enum
 *  Enumerated type for the cell sizes supported by the SDK.
 */
typedef enum {
	/** Invalid cell units */
	ECW_CELL_UNITS_INVALID	=	0,
	/** Cell units are standard meters */
	ECW_CELL_UNITS_METERS	=	1,
	/** Degrees */
	ECW_CELL_UNITS_DEGREES	=	2,
	/** US Survey feet */
	ECW_CELL_UNITS_FEET		=	3,
	/** Unknown cell units */
	ECW_CELL_UNITS_UNKNOWN	=	4
} NCSCellSizeUnitType;

/** 
 *	@enum
 *  Enumerated type for file types supported by the SDK.
 */
typedef enum {
	/** Unknown file type or no file open */
	NCS_FILE_UNKNOWN	=	0,
	/** The file is an ECW */
	NCS_FILE_ECW	=	1,
	/** The file is a Jpeg 2000 File */
	NCS_FILE_JP2	=	2
} NCSFileType;

/** 
 *	@enum
 *  Enumerated type for the format of projection/datum pair
 *  This only works for ecw file which has version 3 or above
 */
typedef enum {
	/* Return projection information in "DATUM:EPSG:XXXXX, PROJECTION:ESPG:XXXXX" format */
	NCS_PROJECTION_EPSG_FORMAT = 0,
	/* Return projection information in old format such as "DATUM:WGS84, PROJECTION:GEODETIC"*/
	NCS_PROJECTION_ERMAPPER_FORMAT = 1
} NCSProjectionFormat;

/**
 * \enum	NCSResampleMethod
 *
 * \brief	Values of possible resampling when reading files.
**/
typedef enum { 
	NCS_RESAMPLE_NEAREST_NEIGHBOUR_INTERPOLATION = 0,
	NCS_RESAMPLE_BILINEAR_INTERPOLATION = 1
} NCSResampleMethod;

/** 
 *	@enum
 *	Enumerated type for all the possible argument types
 *	for the SDK configuration function NCSEcwSetConfig
 */
typedef enum {
	/** BOOLEAN value, whether to texture image */
	NCSCFG_TEXTURE_DITHER			= 0,
	/** BOOLEAN value, whether to reopen file for each view opened */
	NCSCFG_FORCE_FILE_REOPEN		= 1,
	/** UINT32 value, target maximum memory cache size */
	NCSCFG_CACHE_MAXMEM				= 2,
	/** UINT32 value, target maximum number of files to have open to use for cache */ /*[07]*/
	NCSCFG_CACHE_MAXOPEN			= 3,
	/** NCSTimeStampMs value, time an ecwp:// blocking read will wait before returning - default 10000 ms */ /*[08]*/
	NCSCFG_BLOCKING_TIME_MS			= 4,
	/** NCSTimeStampMs value, time delay between blocks arriving and the next refresh callback - default 500 ms */
	NCSCFG_REFRESH_TIME_MS			= 5,
	/** NCSTimeStampMs value, minimum time delay between last cache purge and the next one - default 1000 ms */ /*[08]*/
	NCSCFG_PURGE_DELAY_MS			= 6,
	/** NCSTimeStampMs value, time delay between last view closing and file being purged from cache - default 1800000ms */ /*[08]*/
	NCSCFG_FILE_PURGE_DELAY_MS		= 7,
	/** NCSTimeStampMs value, minimum time delay between last view closing and file being purged from cache - default 30000 ms */ /*[08]*/
	NCSCFG_MIN_FILE_PURGE_DELAY_MS	= 8,
	/** (char *) value, "server" name of ECWP proxy server */
	NCSCFG_ECWP_PROXY				= 9,
	/** BOOLEAN value, whether to force a low-memory compression */ /*[09]*/
	NCSCFG_FORCE_LOWMEM_COMPRESS	= 10,
	/** BOOLEAN value, whether to try to reconnect if ECWP connection is lost */ /*[10]*/
	NCSCFG_TRY_ECWP_RECONNECT		= 11,
	/** BOOLEAN value, whether to manage ICC profiles on file read */
	NCSCFG_MANAGE_ICC			= 12,
	/** UINT32 value, number of cahce bytes to use for JP2 file I/O caching - default 2^15 == 32768 */
	NCSCFG_JP2_FILEIO_CACHE_MAXMEM	= 13,
	/** UINT32 value, maximum size for progressive views */
	NCSCFG_MAX_PROGRESSIVE_VIEW_SIZE = 14,
	/** UINT64 value, target maximum memory cache size */
	NCSCFG_CACHE_MAXMEM_64			 = 15,
	/** UINT32 value, maximum number of concurrent file reads PER FILE */
	NCSCFG_FILE_MAXREADS			= 16,
	/** BOOLEAN value, enable the local ECWP client cache */
	NCSCFG_ECWP_CACHE_ENABLED		= 17,
	/** INT32 value, max size in MB on disk of local ECWP client cache */
	NCSCFG_ECWP_CACHE_SIZE_MB		= 18,
	/** CHAR* value, location of local ECWP client cache directory*/
	NCSCFG_ECWP_CACHE_LOCATION		= 19,
	/** INT64 value, current size on disk of local ECWP client cache */
	NCSCFG_ECWP_CACHE_CURRENT_SIZE	= 20,
	/** BOOLEAN value, enable auto generation of .j2i index files on open*/
	NCSCFG_JP2_AUTOGEN_J2I			= 21,
	/** BOOLEAN value, enable optimization of the SDK for non progressive use, progressive mode will no longer work*/
	NCSCFG_OPTIMIZE_NON_PROGRESSIVE	= 22,
	/** BOOLEAN value, enable optimization of the SDK for random reading of files when purging the caches*/
	NCSCFG_OPTIMIZE_CACHE_PURGE_RANDOM_MODE = 23,
	/** BOOLEAN value, enable optimization of using nearest neighbour interpolation*/
	NCSCFG_OPTIMIZE_USE_NEAREST_NEIGHBOUR = 24,
	/** BOOLEAN value, force to use buffered io stream for JP2 file reading*/
	NCSCFG_USE_BUFFERED_IO_STREAM = 25,
	/** BOOLEAN value, force the reader to scale to the output buffer size*/
	NCSCFG_USE_AUTO_SCALE_DOWN = 26,
	/** UINT32 value, number of streams in the pool, assists multi-threaded reading */
	NCSCFG_JP2_MAX_FILE_STREAMS = 27,
	/** BOOLEAN value, be resiliant about decoding (or fussy and fail) */
	NCSCFG_RESILIENT_DECODING = 28,
	/** BOOLEAN value, Enable ECWP Disk cache for connections where a username and password were supplied */
	NCSCFG_ECWP_CACHE_ENABLE_SECURE = 29,
	/** BOOLEAN value, Enable attempting to connect to IWS with ECWP3 */
	NCSCFG_ECWP3_CLIENT = 30,
	/** UINT32 value, number of concurrent download sessions */
	NCSCFG_ECWP3_CLIENT_MAX_CONCURRENT_DOWNLOADS = 31,
	/** UINT32 value, max number of blocks to request per download sessions */
	NCSCFG_ECWP3_CLIENT_MAX_BLOCKS_PER_DOWNLOAD = 32,
	/** UINT32 value, min number of blocks to request per download sessions */
	NCSCFG_ECWP3_CLIENT_MIN_BLOCKS_PER_DOWNLOAD = 33,
	/** UINT32 value, timeout in ms before a download session is closed */
	NCSCFG_ECWP3_CLIENT_CONNECTION_TIMEOUT_MS = 34,
	/** CHAR* value, utf8 encoded path for temporary compression files */
	NCSCFG_COMPRESSION_TEMP_PATH_UTF8 = 35,
	/** wchar_t* value, path for temporary compression files.  On Get, caller will need to NCSFree the pointer. */
	NCSCFG_COMPRESSION_TEMP_PATH_WCHART = 36,
	/** UINT32 value, number of threads the tile based compressor will use.  On Get, caller will need to NCSFree the pointer. */
	NCSCFG_COMPRESSION_TILE_THREADS = 37,
	/** UINT64 value, bytes of memory the compressor can use.  0 for auto. */
	NCSCFG_COMPRESSION_MAXMEM = 38,
	/** BOOLEAN value, Use SSE when compression ECW file in using the Tiled API */
	NCSCFG_COMRESSION_USE_SSE = 39,
	/** UINT8 value, the format of returned projection information of ecw and jp2 files */
	NCSCFG_PROJECTION_FORMAT = 40,
	/** BOOLEAN value, Serialise the blocks for v3 ECW files compressed with the tiled compressor (makes decoding on slow IO faster) */
	NCSCFG_COMPRESSION_TILED_SERIALISE_BLOCKS = 41,
	/** BOOLEAN value, when ITransforms*'s are set in a NCSFile set this to FALSE to make the SDK not delete them (default TRUE) */
	NCSCFG_VIEW_ALWAYS_DELETE_TRANSFORMS = 42,
	/** (UTF-8 char *) value, user agent that will be presented to web server.  On Get, caller will need to NCSFree the pointer. */
	NCSCFG_ECWP_CLIENT_HTTP_USER_AGENT = 43
} NCSConfigType;

#define NCSCFG_JP2_MANAGE_ICC NCSCFG_MANAGE_ICC
/**
 *	@enum
 *	Enumerated type to describe the usage and precedence of geographic metadata in conjunction with JPEG 2000.
 */
typedef enum {
		/** Do not use geodata */
		JP2_GEODATA_USE_NONE				= 0,		//000000000
		/** Use GeoTIFF UUID box metadata only */
		JP2_GEODATA_USE_PCS_ONLY			= 1,		//000000001
		/** Use GML header box metadata only */
		JP2_GEODATA_USE_GML_ONLY			= 2,		//000000010
		/** Use world files only */
		JP2_GEODATA_USE_WLD_ONLY			= 4,		//000000100
		/** Use the GML box then the GeoTIFF box */
		JP2_GEODATA_USE_GML_PCS				= 10,		//000001010
		/** Use the world file then the GeoTIFF box */
		JP2_GEODATA_USE_WLD_PCS				= 12,		//000001100
		/** Use the GeoTIFF box then the GML box */
		JP2_GEODATA_USE_PCS_GML				= 17,		//000010001
		/** Use the world file then the GML box */
		JP2_GEODATA_USE_WLD_GML				= 20,		//000010100
		/** Use the GeoTIFF box then the world file */
		JP2_GEODATA_USE_PCS_WLD				= 33,		//000100001
		/** Use the GML box then the world file */
		JP2_GEODATA_USE_GML_WLD				= 34,		//000100010
		/** Use the world file, then the GML box, then the GeoTIFF box */
		JP2_GEODATA_USE_WLD_GML_PCS			= 84,		//001010100
		/** Use the GML box, then the world file, then the GeoTIFF box */
		JP2_GEODATA_USE_GML_WLD_PCS			= 98,		//001100010
		/** Use the world file, then the GeoTIFF box, then the GML box */
		JP2_GEODATA_USE_WLD_PCS_GML			= 140,		//010001100
		/** Use the GeoTIFF box, then the world file, then the GML box */
		JP2_GEODATA_USE_PCS_WLD_GML			= 161,		//010100001
		/** Use the GML box, then the GeoTIFF box, then the world file */
		JP2_GEODATA_USE_GML_PCS_WLD			= 266,		//100001010
		/** Use the GeoTIFF box, then the GML box, then the world file */
		JP2_GEODATA_USE_PCS_GML_WLD			= 273		//100010001
} NCSGeodataUsage;

/** 
 *	@struct
 *	Struct containing metadata for a specific band in the file.
 */
typedef struct {
	/** Bit depth used in band, including sign bit */
	UINT8	nBits;
	/** Whether band data is signed */
	BOOLEAN	bSigned;
	/** ASCII description of band, e.g. "Red" or "Band1" */
	char	*szDesc;
} NCSFileBandInfo;

/** 
 *	@defgroup banddescs
 *	These are the allowable ASCII descriptions in the current implementation.
 *  @{
 */
/** @def */
#define NCS_BANDDESC_Red							"Red"
/** @def */
#define NCS_BANDDESC_Green							"Green"
/** @def */
#define NCS_BANDDESC_Blue							"Blue"
/** @def */
#define NCS_BANDDESC_All							"All"
/** @def */
#define NCS_BANDDESC_RedOpacity						"RedOpacity"
/** @def */
#define NCS_BANDDESC_GreenOpacity					"GreenOpacity"
/** @def */
#define NCS_BANDDESC_BlueOpacity					"BlueOpacity"
/** @def */
#define NCS_BANDDESC_AllOpacity						"AllOpacity"
/** @def */
#define NCS_BANDDESC_RedOpacityPremultiplied		"RedOpacityPremultiplied"
/** @def */
#define NCS_BANDDESC_GreenOpacityPremultiplied		"GreenOpacityPremultiplied"
/** @def */
#define NCS_BANDDESC_BlueOpacityPremultiplied		"BlueOpacityPremultiplied"
/** @def */
#define NCS_BANDDESC_AllOpacityPremultiplied		"AllOpacityPremultiplied"
/** @def */
#define NCS_BANDDESC_Greyscale						"Grayscale"
/** @def */
#define NCS_BANDDESC_GreyscaleOpacity				"GrayscaleOpacity"
/** @def */
#define NCS_BANDDESC_GreyscaleOpacityPremultiplied	"GrayscaleOpacityPremultiplied"
/** @def */
#define NCS_BANDDESC_Band							"Band #%d"
/*@}*/

/** 
 *	@enum
 *	The color space used by a compressed file.
 *	For compatibility with ECW, these values cannot be changed or reordered.
 */
typedef enum {
	/** No color space */
	NCSCS_NONE						= 0,
	/** Greyscale image */
	NCSCS_GREYSCALE					= 1,	// Greyscale
	/** Luminance-chrominance color space */
	NCSCS_YUV						= 2,	// YUV - JPEG Digital, JP2 ICT
	/** Multiband image */
	NCSCS_MULTIBAND					= 3,	// Multi-band imagery
	/** sRGB color space */
	NCSCS_sRGB						= 4,	// sRGB
	/** Modified luminance-chrominance color space */
	NCSCS_YCbCr						= 5		// YCbCr - JP2 ONLY, Auto-converted to sRGB
} NCSFileColorSpace;

/*
 * FileMetadata, only for ecw version 3 and above
 */
typedef struct 
{
	/** image classificatioin */	
	NCSTChar* sClassification;
	/** Acquistion date on the image, the format should be YYYY-MM-DD */	
	NCSTChar* sAcquisitionDate;
	/** Acquisition Sensor Name */	
	NCSTChar* sAcquisitionSensorName;
	/** Software that is used to compress the image */
	NCSTChar* sCompressionSoftware; 
	/** Author who compress the image */
	NCSTChar* sAuthor; // updatable
	/** Copyright on the compressed image */
	NCSTChar* sCopyright; 
	/** Company which owns the compressed image */
	NCSTChar* sCompany; // updatable
	/** Contact email */
	NCSTChar* sEmail; // updatable
	/** Contact address */
	NCSTChar* sAddress;// updatable
	/** Contact phone */
	NCSTChar* sTelephone; // updatable
} NCSFileMetaData;

/*
 * Rapid Positioning Capability data, only for ecw version 3 and above
 */
typedef struct
{
	/** Error - Bias, should be >= 0 */
	IEEE8 ERR_BIAS;
	/** Error - Random, should be >= 0 */
	IEEE8 ERR_RAND;
	/** 	Line Offset, should be >= 0 */
	IEEE8 LINE_OFF;
	/** 	Sample Offset, should be >= 0 */
	IEEE8 SAMP_OFF;
	/** 	Geodetic Latitude Offset, range from -90 to +90 */
	IEEE8 LAT_OFF;
	/**  Geodetic Longitude Offset , range from -180 to +180 */
	IEEE8 LONG_OFF;
	/** 	Geodetic Height Offset */
	IEEE8 HEIGHT_OFF;
	/** 	Line Scale, should be > 0 */
	IEEE8 LINE_SCALE;
	/** Sample Scale, should be > 0 */
	IEEE8 SAMP_SCALE;
	/** Geodetic Latitude Scale, range is (0, 90] */
	IEEE8 LAT_SCALE;
	/** 	Geodetic Longitude Scale, range is (0, 180] */
	IEEE8 LONG_SCALE;
	/** Geodetic Height Scale, should be > 0 */
	IEEE8 HEIGHT_SCALE;
	/** Line Numerator Coefficients */
	IEEE8 LINE_NUM_COEFFS[20];
	/** Line Denominator Coefficients */
	IEEE8 LINE_DEN_COEFFS[20];
	/** Sample Numerator Coefficients */
	IEEE8 SAMP_NUM_COEFFS[20];
	/** Sample Denominator Coefficients */
	IEEE8 SAMP_DEN_COEFFS[20];
} NCSRPCData;

/** 
 *	@struct
 *	Extended file metadata structure for the JPEG 2000 interface.
 *	This structure is derived from a compressed JPEG 2000 file.
 *	It is important to note that the information contained within it 
 *	is informative, not normative.  For example, although the file may 
 *	contain metadata that indicates the image it contains is to be rotated,
 *	the SDK will not rotate that image itself.
 *	The SDK function NCSGetViewFileInfoEx() returns a pointer to this
 *	file info structure for a given view.
 */
typedef struct {		
	/** Dataset cells in X direction */	
	UINT32	nSizeX;
	/** Dataset cells in X direction */
	UINT32	nSizeY;
	/** Number of bands in the file, e.g. 3 for a RGB file */
	UINT16	nBands;	
	/** Target compression rate, e,g, 20 == 20:1 compression.  May be zero */
	UINT16	nCompressionRate;
	/** Units used for pixel size */
    NCSCellSizeUnitType	eCellSizeUnits;
	/** Increment in eCellSizeUnits in X direction.  May be negative.  Never zero */
	IEEE8	fCellIncrementX;
	/** Increment in eCellSizeUnits in Y direction.  May be negative.  Never zero */
	IEEE8	fCellIncrementY;
	/** World X origin for top left corner of top left cell, in eCellSizeUnits */
	IEEE8	fOriginX;
	/** World Y origin for top left corner of top left cell, in eCellSizeUnits */
	IEEE8	fOriginY;
	/** Datum name string, can be in different format according to setting on NCSProjectionFormat. Never NULL */
	char	*szDatum;	
	/** Projection name string, can be in different format according to setting on NCSProjectionFormat. Never NULL */
	char	*szProjection;
	/** Clockwise rotation of image in degrees */
	IEEE8	fCWRotationDegrees;
	/** Color space of image */
	NCSFileColorSpace eColorSpace;
	/** Cell type of image samples */
    NCSCellType eCellType;
	/** A pointer to an array of band information structures for each band of the image */
	NCSFileBandInfo *pBands;
	/** What version on the jp2 or ecw file */ 
	UINT8	nFormatVersion;
	/** Optional cell bits for MULTIBAND, RGB, YUV and GREYSCALE, currently support 8 (default) and 16 bits (progressing) */
	UINT8	nCellBitDepth;
	/** Compression date, this field will be automatically filled after compression */	
	char* sCompressionDate;
	/** Actual copression rate, this field will be automatically filled after compression  */
	IEEE4	fActualCompressionRate;

	/** FileMetaData */
	NCSFileMetaData* pFileMetaData;
} NCSFileInfo;

/** 
 *	@struct
 *	Information about an open view into a compressed image file.
 *	This structure contains updated information about the extents and processing status
 *	of an open file view.  NCSGetViewSetInfo() will return a pointer to this structure
 *	for a file view
 */
typedef struct {
	/** Client data */
	void	*pClientData;
	/** Number of bands to read */
	UINT32 nBands;				
	/** Array of band indices being read from the file - the size of this array is nBands */
	UINT32 *pBandList;
	/** Top left of the view in image coordinates */
	UINT32 nTopX, nLeftY;
	/** Bottom right of the view in image coordinates */
	UINT32 nBottomX, nRightY;
	/** Size of the view in pixels */
	UINT32 nSizeX, nSizeY;			
	/** Number of file blocks within the view area */
	UINT32 nBlocksInView;
	/** Number of these file blocks that are currently available */
	UINT32 nBlocksAvailable;
	/** Blocks of the file that were available at the time of the corresponding SetView */
	UINT32 nBlocksAvailableAtSetView;
	/** Number of blocks that were missed during the read of this view */
	UINT32 nMissedBlocksDuringRead;
	/** Top left of the view in world coordinates (if using SetViewEx) */
	IEEE8  fTopX, fLeftY;
	/** Bottom right of the view in world coordinates (if using SetViewEx) */ /*[02]*/
	IEEE8  fBottomX, fRightY;	
} NCSSetViewInfo;

/** 
 *	@struct
 *	Individual band statistics
 */
typedef struct {
		/** mode */
		IEEE4 fMode;
		/** minimum value on the band */
		IEEE4 fMinVal;
		/** max value on the band */
		IEEE4 fMaxVal;
		/** mean value on the band */
		IEEE4 fMeanVal;
		/** median value on the band */
		IEEE4 fMedianVal;
		/** standard deviation on the band */
		IEEE4 fStandardDev;
		/** histogram min value */
		IEEE4 fMinHist;
		/** histogram max value */
		IEEE4 fMaxHist;
		/** histogram bucket count */
		UINT32 nHistBucketCount;
		/** histogram on the band */
		UINT64* Histogram;
} NCSBandStats;

/** 
 *	@struct
 *	Statistics on a ecw file that client can set and get, only for ecw version 3 and above
 */
typedef struct
{
	NCSBandStats* BandsStats;
	/** number of bands */
	UINT32 nNumberOfBands;
} NCSFileStatistics;

/** 
 *	@struct
 *	geokeyentry on a ecw file that client can get, only for ecw version 3 and above
 */
typedef struct
{
	//key id
	geokey_t keyId;
	// type of the key, can be TYPE_SHORT, TYPE_ASCII and TYPE_DOUBLE
	tagtype_t keyType;
	// value count, should be 1 for TYPE_SHORT and TYPE_DOUBLE, and string length for TYPE_ASCII
	UINT32 valCount;
} NCSGeoKeyEntry;

/** 
 *	@typedef
 *	This type definition promotes properly transparent usage of the SDK structures.
 */
typedef struct NCSFileViewStruct NCSFileView;

/** 
 * Initialise the SDK libraries. 
 * Should not be called directly on Windows DLL as it is called automatically on DllLoad and DllUnload.
 */
extern void NCS_CALL NCSInit(void);
/** 
 * Shutdown the SDK libraries. 
 * Should not be called directly on Windows DLL as it is called automatically on DllLoad and DllUnload.
 */
extern void NCS_CALL NCSShutdown(void);

/** 
 *	Set custom functions to be used by the SDK library to open, close, read, seek and tell input files.
 *	This can be used to manage "wrapper" files which encapsulate the ordinary compressed files 
 *  handled by the SDK.
 *
 *	@param[in]	pOpenCB		Callback function for opening input files
 *	@param[in]	pCloseCB	Callback function for closing input files
 *	@param[in]	pReadCB		Callback function for reading input files
 *	@param[in]	pSeekCB		Callback function for seeking input files
 *	@param[in]	pTellCB		Callback function for telling input files
 *	@return					NCSError value, NCS_SUCCESS or the code of any applicable error
 */
extern NCSError NCS_CALL NCSSetIOCallbacks(NCSError (NCS_CALL *pOpenCB)(char *szFileName, void **ppClientData),
									  NCSError (NCS_CALL *pCloseCB)(void *pClientData),
									  NCSError (NCS_CALL *pReadCB)(void *pClientData, void *pBuffer, UINT32 nLength),
									  NCSError (NCS_CALL *pSeekCB)(void *pClientData, UINT64 nOffset),
									  NCSError (NCS_CALL *pTellCB)(void *pClientData, UINT64 *pOffset));
/** 
 *	Reports if this is a local or remote file, and breaks URL down into sections
 *
 *	@param[in]	szUrlPath			The URL to be broken down and analysed
 *	@param[out]	ppProtocol			The protocol of the URL (pointer to char *)
 *	@param[out]	pnProtocolLength	The length of the protocol
 *	@param[out]	ppHost				The hostname specified in the URL
 *	@param[out] pnHostLength		The length of the specified hostname
 *	@param[out]	ppFilename			The filename specified by the URL
 *	@param[out]	pnFilenameLength	The length of the specified filename
 *	@return							BOOLEAN value, if this is a local file
 */
extern BOOLEAN NCS_CALL NCSNetBreakdownUrlA( const char *szUrlPath,
						   char **ppProtocol,	int *pnProtocolLength,
						   char **ppHost,		int *pnHostLength,
						   char **ppFilename,	int *pnFilenameLength);

/** 
 *	Reports if this is a local or remote file, and breaks URL down into sections
 *
 *	@param[in]	szUrlPath			The URL to be broken down and analysed
 *	@param[out]	ppProtocol			The protocol of the URL (pointer to char *)
 *	@param[out]	pnProtocolLength	The length of the protocol
 *	@param[out]	ppHost				The hostname specified in the URL
 *	@param[out] pnHostLength		The length of the specified hostname
 *	@param[out]	ppFilename			The filename specified by the URL
 *	@param[out]	pnFilenameLength	The length of the specified filename
 *	@return							BOOLEAN value, if this is a local file
 */
extern BOOLEAN NCS_CALL NCSNetBreakdownUrlW( const wchar_t *szUrlPath,
						   wchar_t **ppProtocol,	int *pnProtocolLength,
						   wchar_t **ppHost,		int *pnHostLength,
						   wchar_t **ppFilename,	int *pnFilenameLength);

#ifdef UNICODE
#define NCSNetBreakdownUrl NCSNetBreakdownUrlW
#else
#define NCSNetBreakdownUrl NCSNetBreakdownUrlA
#endif // UNICODE

/** 
 *	Opens a file view.  After calling this function, call GetViewFileInfo to obtain file metadata
 *
 *	@param[in]	szUrlPath			The location of the file on which to open a view
 *	@param[out]	ppNCSFileView		The NCSFileView structure to initialise
 *	@param[in]	pRefreshCallback	The refresh callback with which to handle progressive reads (may be NULL for the blocking interface)
 *	@return							NCSError value, NCS_SUCCESS or any applicable error code
 */
extern NCSError NCS_CALL NCSOpenFileViewA(const char *szUrlPath, NCSFileView **ppNCSFileView,
                       NCSReadStatus (*pRefreshCallback)(NCSFileView *pNCSFileView));

/** 
 *	Opens a file view.  After calling this function, call GetViewFileInfo to obtain file metadata
 *
 *	@param[in]	szUrlPath			The location of the file on which to open a view
 *	@param[out]	ppNCSFileView		The NCSFileView structure to initialise
 *	@param[in]	pRefreshCallback	The refresh callback with which to handle progressive reads (may be NULL for the blocking interface)
 *	@return							NCSError value, NCS_SUCCESS or any applicable error code
 */
extern NCSError NCS_CALL NCSOpenFileViewW(const wchar_t *szUrlPath, NCSFileView **ppNCSFileView,
                       NCSReadStatus (*pRefreshCallback)(NCSFileView *pNCSFileView));

#ifdef UNICODE
#define NCSOpenFileView NCSOpenFileViewW
#else
#define NCSOpenFileView NCSOpenFileViewA
#endif // UNICODE

/**	
 *	Closes a file view.  This can be called at any time after NCScbmOpenFileView is called to clean up an open file view.
 *
 *	@param[in]	pNCSFileView		The file view to close
 *	@return							NCSError value, NCS_SUCCESS or any applicable error code
 */
extern NCSError NCS_CALL NCSCloseFileView(NCSFileView *pNCSFileView);

/**	
 *	Closes a file view.  This can be called at any time after NCScbmOpenFileView is called to clean up an open file view.
 *
 *	This version allows the developer to forcibly close a file and free the resources allocated to it.
 *	@param[in]	pNCSFileView		The file view to close
 *	@param[in]	bFreeCachedFile		Whether to force the freeing of the file's memory cache
 *	@return							NCSError value, NCS_SUCCESS or any applicable error code
 */
extern NCSError NCS_CALL NCSCloseFileViewEx(NCSFileView *pNCSFileView, BOOLEAN bFreeCachedFile);


/** 
 *	Populates a structure with information about an open image file.  Use this version when dealing with ECW files only.
 *
 *	@param[in]	pNCSFileView			The file view open on the file whose metadata is being obtained
 *	@param[out]	ppNCSFileViewFileInfo	A pointer to a pointer to the NCSFileInfo struct to populate with the metadata
 *	@return								NCSError value, NCS_SUCCESS or any applicable error code
 */
extern NCSError NCS_CALL NCSGetViewFileInfo(NCSFileView *pNCSFileView, NCSFileInfo **ppNCSFileInfo);

/** 
 *	Obtains information about the current request to set the view, including statistics about the data being processed
 *
 *	@param[in]	pNCSFileView			The open file view the extents of which are currently being set
 *	@param[out]	ppNCSFileViewSetInfo	The information about the view being set
 *	@return								NCSError value, either NCS_SUCCESS or an applicable error code
 */
extern NCSError NCS_CALL NCSGetSetViewInfo(NCSFileView *pNCSFileView, NCSSetViewInfo **ppNCSSetViewInfo);

/** 
 *	Sets the extents and band content of an open file view, and the output view size.  This function can be called at 
 *	any time after a successful call to NCScbmOpenFileView.  In progressive mode, multiple calls to NCScbmSetFileView 
 *	can be made, even if previous SetViews are still being processed, enhancing client interaction with the view.  After 
 *	the call to NCScbmSetFileView, the band list array pBandList can be freed if so desired.  It is used only during the 
 *  processing of the call, and not afterward.
 *
 *	@param[in]	pNCSFileView			The open file view to set
 *	@param[in]	pBandList				An array of integers specifying which bands of the image to read, and in which order
 *	@param[in]	nTLX					Left edge of the view in dataset cells
 *	@param[in]	nTLY					Top edge of the view in dataset cells
 *	@param[in]	nBRX				Right edge of the view in dataset cells
 *	@param[in]	nBRY					Bottom edge of the view in dataset cells
 *	@param[in]	nSizeX					Width of the view to be constructed from the image subset
 *	@param[in]	nSizeY					Height of the view to be constructed from the image subset
 *	@return								NCSError value, NCS_SUCCESS or any applicable error code
 */
extern NCSError NCS_CALL NCSSetFileView(NCSFileView *pNCSFileView,
										   UINT32 nBands,					
										   UINT32 *pBandList,				
										   UINT32 nTLX, UINT32 nTLY,	
										   UINT32 nBRX, UINT32 nBRY,
										   UINT32 nSizeX, UINT32 nSizeY);	

/** 
 *	Sets the extents and band content of an open file view, and the output view size.  This function can be called at 
 *	any time after a successful call to NCSOpenFileView.  In progressive mode, multiple calls to NCSSetFileView
 *	can be made, even if previous SetViews are still being processed, enhancing client interaction with the view.  After 
 *	the call to NCSSetFileView, the band list array pBandList can be freed if so desired.  It is used only during the
 *  processing of the call, and not afterward.  This version also allows the calling program to specify world coordinates 
 *	for the view.
 *
 *	@param[in]	pNCSFileView			The open file view to set
 *	@param[in]	pBandList				An array of integers specifying which bands of the image to read, and in which order
 *	@param[in]	nTLX					Left edge of the view in dataset cells
 *	@param[in]	nTLY					Top edge of the view in dataset cells
 *	@param[in]	nBRX				Bottom edge of the view in dataset cells
 *	@param[in]	nBRY					Right edge of the view in dataset cells
 *	@param[in]	nSizeX					Width of the view to be constructed from the image subset
 *	@param[in]	nSizeY					Height of the view to be constructed from the image subset
 *	@param[in]	fWorldTLX					Left edge of the view in world coordinates
 *	@param[in]	fWorldTLY					Top edge of the view in world coordinates
 *	@param[in]	fWorldBRX				Right edge of the view in world coordinates
 *	@param[in]	fWorldBRY					Bottom edge of the view in world coordinates
 *	@return								NCSError value, NCS_SUCCESS or any applicable error code
 */
extern NCSError NCS_CALL NCSSetFileViewEx(NCSFileView *pNCSFileView,
											 UINT32 nBands,					
											 UINT32 *pBandList,				
											 UINT32 nTLX, UINT32 nTLY,	
											 UINT32 nBRX, UINT32 nBRY,
											 UINT32 nSizeX, UINT32 nSizeY,	
											 IEEE8 fWorldTLX, IEEE8 fWorldTLY,		
											 IEEE8 fWorldBRX, IEEE8 fWorldBRY);	

/** 
 *	Read line by line in BIL format.
 *
 *	@param[in]	pNCSFileView			The open file view from which to read view lines
 *	@param[out]	ppOutputLine			The buffer into which to read the interleaved band information
 *	@return								NCSReadStatus value, NCS_READ_OK or any applicable error code
 */
extern NCSReadStatus NCS_CALL NCSReadViewLineBIL( NCSFileView *pNCSFileView, UINT8 **ppOutputLine);

/** 
 *	Read line by line in BIL format to different data types.  This extended version allows the client 
 *	program to read in view lines made up of cells with sample bitdepth other than 8-bit.
 *
 *	@param[in]	pNCSFileView			The open file view from which to read view lines
 *	@param[in]	eType					The cell type of the view lines being read
 *	@param[out]	ppOutputLine			The buffer into which to read the interleaved band information
 *	@return								NCSReadStatus value, NCS_READ_OK or any applicable error code
 */
extern NCSReadStatus NCS_CALL NCSReadViewLineBILEx( NCSFileView *pNCSFileView, NCSCellType eType, void **ppOutputLine);

/** 
 *	Read line by line in RGB format.
 *
 *	@param[in]	pNCSFileView			The open file view from which to read view lines
 *	@param[out]	pRGBTriplets			The buffer into which to read the red-green-blue sample triplets.
 *	@return								NCSReadStatus value, NCS_READ_OK or any applicable error code
 */
extern NCSReadStatus NCS_CALL NCSReadViewLineRGB( NCSFileView *pNCSFileView, UINT8 *pRGBTriplets);

/** 
 *	Read line by line in BGR format.
 *
 *	@param[in]	pNCSFileView			The open file view from which to read view lines
 *	@param[out]	pBGRTriplets			The buffer into which to read the blue-red-green sample triplets.
 *	@return								NCSReadStatus value, NCS_READ_OK or any applicable error code
 */
extern NCSReadStatus NCS_CALL NCSReadViewLineBGR( NCSFileView *pNCSFileView, UINT8 *pBGRTriplets);

/**
 *	Read line by line in RGBA format.  Samples are read into a buffer of UINT32 values, each value comprising
 *	the four bytes of a red-green-blue-alpha sample.  Alpha values will be zero if the input file is in ECW
 *	format as this format does not 'understand' alpha channels.  SDK programmers wanting to compress and 
 *	decompress data in four bands are advised to use multiband compression and NCSReadViewLineBil(Ex) to
 *	handle their data.
 *
 *	@param[in]	pNCSFileView			The open file view from which to read view lines
 *	@param[out]	pRGBA					The buffer of packed UINT32 values.
 *	@return								NCSReadStatus value, NCS_READ_OK or any applicable error code
 */
extern NCSReadStatus NCS_CALL NCSReadViewLineRGBA( NCSFileView *pNCSFileView, UINT32 *pRGBA);

/**	
 *	Read line by line in BGRA format.  Samples are read into a buffer of UINT32 values, each value comprising
 *	the four bytes of a red-green-blue-alpha sample.  Alpha values will be zero if the input file is in ECW
 *	format as this format does not 'understand' alpha channels.  SDK programmers wanting to compress and 
 *	decompress data in four bands are advised to use multiband compression and NCSReadViewLineBil(Ex) to
 *	handle their data.
 *
 *	@param[in]	pNCSFileView			The open file view from which to read view lines
 *	@param[out]	pBGRA					The buffer of packed UINT32 values.
 *	@return								NCSReadStatus value, NCS_READ_OK or any applicable error code
 */
extern NCSReadStatus NCS_CALL NCSReadViewLineBGRA( NCSFileView *pNCSFileView, UINT32 *pBGRA);

/** 
 *	Return the major and minor versions of this SDK.
 *
 *	@param[out]	nMajor		The major version
 *	@param[out] nMinor		The minor version
 */
extern void NCS_CALL NCSGetLibVersion( INT32 *nMajor, INT32 *nMinor );

/**	
 *	Set configuration parameters for the SDK functions
 *
 *	@param[in]	eType		The configuration parameter to set, to be followed in the variable argument list by its desired value
 *	@return					NCSError value, NCS_SUCCESS or any applicable error code
 */
extern NCSError NCS_CALL NCSSetConfig(NCSConfigType eType, ...);

/**	
 *	Get configuration parameters for the SDK functions
 *
 *	@param[in]	eType		The configuration parameter to obtain, to be followed in the variable argument list by a value buffer
 *	@return					NCSError value, NCS_SUCCESS or any applicable error code
 */
extern NCSError NCS_CALL NCSGetConfig(NCSConfigType eType, ...);
/**
 * Initialize a FileInfo structure.
 * @param		pDst			The file info structure to initialize.
 */
extern void NCS_CALL NCSInitFileInfo(NCSFileInfo *pDst);

/**
 * Free a FileInfo structure.
 * @param		pDst			The file info structure to initialize.
 */
extern void NCS_CALL NCSFreeFileInfo(NCSFileInfo *pDst);

/**
 * Copy a FileInfo structure.
 * @param		pDst			The file info structure to initialize.
 */
extern void NCS_CALL NCSCopyFileInfo(NCSFileInfo *pDst, NCSFileInfo *pSrc);

/**
 *	Get the file type of the file view (typically ECW or JP2)
 *
 *	@param[in]	pNCSFileView		The file view
 *	@return		NCSFileType the type of file in the view.
 */
extern NCSFileType NCS_CALL NCSGetFileType( NCSFileView *pNCSFileView );

/**
 *	Get the mime type of the file view (typically image/x-ecw or image/jp2)
 *
 *	@param[in]	pNCSFileView		The file view
 *	@return		NCSFileType        A char* string representing the mime type.
 */
extern char* NCS_CALL NCSGetFileMimeType( NCSFileView *pNCSFileView );

/**
 * check if a FileInfo structure is georeferenced
 * @param		pInfo			File info to test.
 * @return		BOOLEAN			TRUE if FileInfo is georeferences (Non RAW/RAW).
 */
extern BOOLEAN NCS_CALL NCSIsFileInfoExGeoreferenced(NCSFileInfo *pInfo);

/**
 * Standardize a FileInfo structure
 * @param		pInfo			File info to standardize.
 */
extern void NCS_CALL NCSStandardizeFileInfoEx(NCSFileInfo *pInfo);

/**
 * Set the custom GDT data path (for EPSG<-->ER Mapper projection/datum mapping)
 * @param szPath the new GDT data path
 */
extern void NCS_CALL NCSSetGDTPath(char *szPath);

/**
 * Get the custom GDT data path (for EPSG<-->ER Mapper projection/datum mapping)
 * @return the custom path being used, or NULL
 */
extern char* NCS_CALL NCSGetGDTPath(void);

/**
 * Get an EPSG Code for a specified GDT Datum/Projection pairing
 * @param		szDatum			GDT Datum name
 * @param		szProjection	GDT Projection name
 * @param		pnEPSG			Returned EPSG code
 * @return		NCSError		NCS_SUCCESS, or error on failure
 */
extern NCSError NCS_CALL NCSGetEPSGCode(char *szDatum, char *szProjection, INT32 *pnEPSG);

/**
 * Get an ER Mapper projection/datum pair from an EPSG code, if any are applicable
 * @param		nEPSGCode		EPSG code
 * @param		pszProjection	Returned ER Mapper projection string
 * @param		pszDatum		Returned ER Mapper datum string
 * @return		NCSError		NCS_SUCCESS, or error on failure
 */
extern NCSError NCS_CALL NCSGetProjectionAndDatum(INT32 nEPSGCode, char **pszProjection, char **pszDatum);

/**
 * Refresh the custom GDT data path, doing a search and validity check on
 * the current path value and several common GDT data locations
 */
extern void NCS_CALL NCSDetectGDTPath(void);

/**
 * Set the usage of geographical metadata when reading and writing JPEG 2000 files.
 * @param		nGeodataUsage	NCSGeodataUsage enum value specifying which metadata to use
 */
extern void NCS_CALL NCSSetJP2GeodataUsage(NCSGeodataUsage nGeodataUsage);

	/**
	 * Get the statistics on the file
	 * @param		pFilePath	ecw file path where the stats should be get
	 * @param		ppStats 	a pointer to stats data which is allocated and returned if the file contains stats, or NULL if the file doesn't. 
	 * @return     	NCSError    NCS_SUCCESS, or error on failure
	 * @note		make sure *ppStats is initialised as NULL
	 */
extern NCSError NCS_CALL NCSGetViewStatistics(NCSFileView *pNCSFileView, NCSFileStatistics** ppStats);
	/**
 	 * Initialize the statistics structure if histBucketCounts is not null then also NCSInitStatisticsHistograms is called
  	 * @param		ppStats 	a pointer to stats data that needs to be initialized
	 * @param		numberOfBands 	number of image bands 
	 * @param		histBucketCounts list of histogram lengths 
	 * @return      NCSError     NCS_SUCCESS, or error on failure
	 * @note		make sure *ppStats is initialised as NULL
 	 */
extern NCSError NCS_CALL NCSInitStatistics(NCSFileStatistics** ppStats, UINT32 numberOfBands,UINT32* histBucketCounts);
	/**
 	 * Initialize the statistics structure and NCSInitStatisticsHistograms is called with an array of numberOfBands length filled
	 * with nHistBucketCounts
  	 * @param		ppStats 	a pointer to stats data that needs to be initialized
	 * @param		numberOfBands 	number of image bands 
	 * @param		nHistBucketCounts histogram counts
	 * @return      NCSError     NCS_SUCCESS, or error on failure
	 * @note		make sure *ppStats is initialised as NULL
 	 */
extern NCSError NCS_CALL NCSInitStatisticsDefault(NCSFileStatistics** ppStats, UINT32 numberOfBands,UINT32 nHistBucketCounts);
	/**
 	 * Initialize histograms (allocate and clear memory) of the statistics structure
  	 * @param		ppStats 	a pointer to stats data that needs to be initialized
	 * @param		histBucketCounts 	histogram bucket counts 
	 * @return      NCSError     NCS_SUCCESS, or error on failure
	 * @note		make sure ppStats is initialised
 	 */
extern NCSError NCS_CALL NCSInitStatisticsHistograms(NCSFileStatistics* ppStats, UINT32* histBucketCounts);
	/**
	 * Free the statistics
	 * @param		pStats 	  stats data that needs to be freed
	 * @return      NCSError     NCS_SUCCESS, or error on failure
 	 */
extern NCSError NCS_CALL NCSFreeStatistics(NCSFileStatistics* pStats);
	/**
	 * Copy statistics 
	 * @param		pDstStats 	destination stats data that needs to be copied into
	 * @param		srcStats 	source stats data that needs to be copied from
	 * @return      NCSError     NCS_SUCCESS, or error on failure
	 * @note		*ppDstStats will be allocated first, make sure *ppStats is initialised as NULL
	 */
extern NCSError NCS_CALL NCSCopyStatistics(NCSFileStatistics** pDstStats, const NCSFileStatistics* pSrcStats);
	/**
	 * Parse the NCSFileStatistics from XML.  This does not Parse the histograms.
	 * @param		pDstStats 	initialised destination stats data to parse into
	 * @param		wszXML		source xml document to parse from
	 * @return      NCSError     NCS_SUCCESS, or error on failure
	 */
extern NCSError NCS_CALL NCSParseStatisticsXML(NCSFileStatistics* pDstStats, const wchar_t* wszXML);
	/**
	 * UnParse the NCSFileStatistics to XML.  This does not UnParse the histograms.
	 * @param		pSrcStats 	source stats data to unparse from
	 * @param		wszXML		destination xml document to unparse to
	 * @return      NCSError     NCS_SUCCESS, or error on failure
	 * @note		*wszXML will be allocated first, make sure *ppStats is initialised as NULL and NCSFree it when you're finished with it.
	 */
extern NCSError NCS_CALL NCSUnParseStatisticsXML(const NCSFileStatistics* pSrcStats, wchar_t** wszXML);
	/**
 	 * Initialize the file metadata structure 
  	 * @param		ppFileMetaData 	a pointer to FileMetaData that needs to be initialized
	 * @return      NCSError     NCS_SUCCESS, or error on failure
	 * @note		make sure *ppFileMetaData is initialised as NULL
 	 */
extern NCSError NCS_CALL NCSInitMetaData(NCSFileMetaData** ppFileMetaData);
	/**
	 * Copy metadata
	 * @param		ppDstMetaData 	a pointer to destination stats data that needs to be copied into
	 * @param		srcMetaData  source meta data that needs to be copied from
	 * @return      NCSError     NCS_SUCCESS, or error on failure
	 * @note		*ppDstMetaData will be allocated first, make sure *ppDstMetaData is initialised as NULL
	 */	
extern NCSError NCS_CALL NCSCopyMetaData(NCSFileMetaData** ppDstMetaData, const NCSFileMetaData* pSrcMetaData);
	/**
	 * Free the metadata
	 * @param		pMetaData 	 meta data that needs to be freed
	 * @return      NCSError     NCS_SUCCESS, or error on failure
 	 */
extern NCSError NCS_CALL NCSFreeMetaData(NCSFileMetaData* pMetaData);
	/**
	 * Parse the NCSFileMetaData from XML
	 * @param		pMetaData 	 meta data structure to store the parsed result
	 * @param		wszXMLData 	 The source XML document
	 * @return      NCSError     NCS_SUCCESS, or error on failure
 	 */
extern NCSError NCS_CALL NCSParseMetaDataXML(NCSFileMetaData* pMetaData, const wchar_t *wszXMLData);
	/**
	 * UnParse the NCSFileMetaData to XML
	 * @param		pMetaData 	 meta data structure to read from
	 * @param		wszXMLData 	 The destination XML document.  This memory will be alloc'd caller must NCSFree it
	 * @return      NCSError     NCS_SUCCESS, or error on failure
 	 */
extern NCSError NCS_CALL NCSUnParseMetaDataXML(const NCSFileMetaData* pMetaData, wchar_t **wszXMLData);
	/**
	 * Get the rpc data on the file
	 * @param		pFilePath	ecw file path where the RPCData should be get
	 * @param		ppRPCData 	a pointer to stats data which is allocated and returned if the file contains rpc data, or NULL if the file doesn't
	 * @return      NCSError     NCS_SUCCESS, or error on failure
	 * @note        make sure *ppRPCData is initialised as NULL
	 */
extern NCSError NCS_CALL NCSGetViewRPCData(NCSFileView *pNCSFileView, NCSRPCData** ppRPCData);
	/**
	 * Copy rpc data
	 * @param		pDstRPCData 	destination rpc data that needs to be copied into
	 * @param		pSrcRPCData  	source rpc data that needs to be copied from
	 * @return      NCSError     NCS_SUCCESS, or error on failure
	 * @note		*pDstRPCData will be allocated first, so make sure *ppDstMetaData is initialised as NULL
	 */
extern NCSError NCS_CALL NCSCopyRPCData(NCSRPCData** pDstRPCData, const NCSRPCData *pSrcRPCData);
	/**
	 * Free the rpc data
	 * @param		pMetaData 	 meta data that needs to be freed
	 * @return      NCSError     NCS_SUCCESS, or error on failure
	 */
extern NCSError NCS_CALL NCSFreeRPCData(NCSRPCData* pRPCData);

	/**
	 * Get all geotiff key entries from the opened fileview.
	 * @param		pNCSFileView 	The open file view from which to get geotiff key entries
	 * @param		ppGeoKeyIds 	a pointer to a geokeyentry array which is allocated and returned if the file contains any geokey data, or NULL if the file doesn't
	 * @param		count 			count of geokeyentry data
	 * @return      NCSError     NCS_SUCCESS, or error on failure
	 * @note		make sure *ppGeoKeyIds is initialised as NULL
	 */
extern NCSError NCS_CALL NCSGetAllGeotiffKeyEntries(NCSFileView *pNCSFileView, NCSGeoKeyEntry **ppGeoKeyIds, UINT32* count);

	/**
	 * Get individual key value frome the open fileview.
	 * @param		pNCSFileView 	The open file view from which to get geotiff key
	 * @param		key 			key id
	 * @param		val 			a pointer to key value
	 * @param		index			key index, usually is zero
	 * @param	    count			value count. it is one if the key type is short or double and character count if the key type is ascii
	 * @return      NCSError     NCS_SUCCESS, or error on failure
	 */
extern NCSError NCS_CALL NCSGetGeotiffKey(NCSFileView *pNCSFileView, geokey_t key, void *val, int index, int count);

	/**
	 * Get individual tag details frome the open fileview.
	 * @param		pNCSFileView 	The open file view from which to get geotiff key
	 * @param		tag 			The geotiff tag. It can only be GTIFF_PIXELSCALE, GTIFF_TIEPOINT,GTIFF_TRANSMATRIX.
	 * @param       pCount			a pointer to value count returned by SDK.
	 * @param		ppValue			a pointer to a value array which is allocated and return if the file has the values for the tag, otherwise NULL
	 * @return      NCSError     NCS_SUCCESS, or error on failure
	 * @note		make sure *ppValue is initialised as NULL
	 */
extern NCSError NCS_CALL NCSGetGeotiffTag(NCSFileView *pNCSFileView, unsigned short tag, int *pCount, IEEE8** ppValue);

#ifdef __cplusplus
}
#endif

#endif	// NCSECWCLIENT_H
