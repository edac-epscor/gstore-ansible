/********************************************************
** Copyright, 1998 - 2013, Intergraph Corporation. All rights reserved.
**
** FILE:     NCSFileIOStream.h 
** CREATED:  28/11/2002 3:27:34 PM
** AUTHOR:   Simon Cope
** PURPOSE:  CIOStream class header
** EDITS:    [xx] ddMmmyy NAME COMMENTS
 *******************************************************/

#ifndef NCSFILEIOSTREAM_H
#define NCSFILEIOSTREAM_H

#ifndef NCSIOSTREAM_H
#include "NCSIOStream.h"
#endif // NCSIOSTREAM_H

#ifndef NCSUTIL_H
#include "NCSUtil.h"
#endif // NCSUTIL_H

#ifdef _MSC_VER
#pragma warning(push)
#pragma warning(disable:4251)
#endif

namespace NCS {

class NCSECW_IMPEX CFileIOStream: public CIOStream {
public:

	static bool GetInfo(CString sFilename, UINT64 *pnSize=NULL,
		UINT64 *pnLastAccessTime=NULL, UINT64 *pnLastWriteTime=NULL, UINT64 *pnCreationTime=NULL);

	CFileIOStream();
	virtual ~CFileIOStream();
	virtual CFileIOStream *Clone();
	
	virtual CError Open(const CString &FileName, bool bWrite = false);
	virtual CError Open(const CString sFilename, bool bWrite, bool bCreateNew, bool bSharedWrite);
	virtual CError Open(const CString &FileName, UINT32 iFlags = NCS_FILE_READ);
	virtual CError Close();

	virtual bool Seek(INT64 offset, Origin origin = CURRENT);
	virtual bool Seek();
	virtual INT64 Tell();
	virtual INT64 Size();

	virtual bool Read(void* buffer, UINT32 count);
	virtual bool Read(void* buffer, UINT32 count, UINT32 *pBytesRead);
	virtual bool Read(INT64 offset, void* buffer, UINT32 count);
	virtual bool ReadMSB(UINT8 &Buffer);
	virtual bool Write(void* buffer, UINT32 count);
	virtual void FlushFileBuffers();
	

#ifdef NCS_BUILD_UNICODE
	static CError SetIOCallbacks(NCSError (NCS_CALL *pOpenACB)(char *szFileName, void **ppClientData),
									NCSError (NCS_CALL *pOpenWCB)(wchar_t *szFileName, void **ppClientData),
									NCSError (NCS_CALL *pCloseCB)(void *pClientData),
									NCSError (NCS_CALL *pReadCB)(void *pClientData, void *pBuffer, UINT32 nLength),
									NCSError (NCS_CALL *pSeekCB)(void *pClientData, UINT64 nOffset),
									NCSError (NCS_CALL *pTellCB)(void *pClientData, UINT64 *pOffset));
#else
	static CError SetIOCallbacks(NCSError (NCS_CALL *pOpenCB)(char *szFileName, void **ppClientData),
									NCSError (NCS_CALL *pCloseCB)(void *pClientData),
									NCSError (NCS_CALL *pReadCB)(void *pClientData, void *pBuffer, UINT32 nLength),
									NCSError (NCS_CALL *pSeekCB)(void *pClientData, UINT64 nOffset),
									NCSError (NCS_CALL *pTellCB)(void *pClientData, UINT64 *pOffset));
#endif

	virtual bool Lock( INT64 nOffset, INT64 nBytes, bool bExclusive, bool bWait );
	virtual bool UnLock( INT64 nOffset, INT64 nBytes );

	virtual UINT64 GetLastAccessTime();
	virtual UINT64 GetLastWriteTime();
	virtual UINT64 GetCreationTime();
	
	virtual bool SetFileValidData(INT64 ValidDataLength);

protected:
	NCS_FILE_HANDLE m_hFile;
	CString m_sFilename;

	typedef struct {
		NCS_FILE_HANDLE hFile;
		bool	bInUse;
	} Handle;
	CMutex	m_mHandles;
	CEvent	m_eHandles;
	std::vector<Handle> m_Handles;

	INT64	m_nFileSize;

	static NCSError (NCS_CALL *sm_pOpenACB)(char *szFileName, void **ppClientData);
	static NCSError (NCS_CALL *sm_pOpenWCB)(wchar_t *szFileName, void **ppClientData);
	static NCSError (NCS_CALL *sm_pCloseCB)(void *pClientData);
	static NCSError (NCS_CALL *sm_pReadCB)(void *pClientData, void *pBuffer, UINT32 nLength);
	static NCSError (NCS_CALL *sm_pSeekCB)(void *pClientData, UINT64 nOffset);
	static NCSError (NCS_CALL *sm_pTellCB)(void *pClientData, UINT64 *pOffset);
};
}

#ifdef _MSC_VER
#pragma warning(pop)
#endif

#ifndef NCS_NO_COMPAT_NAMES
typedef NCS::CFileIOStream CNCSJPCFileIOStream;
#endif

#endif // !NCSFILEIOSTREAM_H
