/********************************************************
** Copyright, 1998 - 2013, Intergraph Corporation. All rights reserved.
**
** FILE:   	NCScnet.h
** CREATED:	Thu Mar 4 09:19:00 WST 1999
** AUTHOR: 	Doug Mansell
** PURPOSE:	IWS client side networking - public interface
** EDITS:
** [01] sjc 01Oct99 Protocol version define
** [02] sjc 25Feb00 Chenged NCS_PROTOCOL_VERSION to 3
** [03] ny  12May00 Added bIsConnected parameter to NCScnetSendPacket
**					to enable the propagation of loss of connection
**					error to the upper level
** [04] jmp 06Mar01 Added generic NCScnetPostURL
** [05] rar 14May01 Added NCSUrlStream.
** [06] rar 17-May-01 Modified NCSnetPacketRecvCB() to include a returned error code.
** [07] rar 28May01 Added sending of ping packet by client,
**					incremented version to 4.
** [08] cmt 12Mar10 Added opacity as appended stream, bumped protocol to v5
 *******************************************************/

#ifndef NCSCNET_H
#define NCSCNET_H


#include "NCSTypes.h"
#include "NCSErrors.h"

#ifdef NCSCNET3
	#ifdef __cplusplus
	#include "NCSUrlStream.h"
	#endif
#endif

#if defined(_WIN32)
typedef SIZE_T DWORD_PTR, *PDWORD_PTR;
#include "WinInet.h"
#elif defined(POSIX)
typedef void* HINTERNET;
#else
Not implemented
#endif //_WIN32


#ifndef NCS_MAX_PACKET_SIZE
#define NCS_MAX_PACKET_SIZE (1024*1024)
#endif
#ifndef NCS_PROTOCOL_VERSION
/*
** Version of the wire protocol.  keep in sync with NCSsnet.h [01]
*/
#define NCS_PROTOCOL_VERSION	5 /**[07][08]**/
#endif

typedef void *pNCSnetClient;
typedef void NCSnetPacketRecvCB(void *, INT32, pNCSnetClient, void *, NCSError eError);	 /**[06]**/	// pPacket, nLength, pClient, pUserData, eError
typedef void NCSnetPacketSentCB(NCSError, void *, void *);					// eError, pPacket, pUserData

typedef int (*NCScnetWriteCallback)(void *szCurrent,
                                      unsigned long nSize,
                                      void *szAllData,
									  void *pUserData);

/////

#ifdef __cplusplus
extern "C" {
#endif

BOOLEAN NCScnetVerifyURLW(wchar_t *szURL);
void NCScnetSetIISDLLNameW(wchar_t *szDLLname);
NCSError NCScnetCreateW(wchar_t *szURL, void **ppClient, void *pPacketIn, int nLengthIn,
						void **ppPacketOut, INT32 *pLengthOut, NCSnetPacketRecvCB *pRecvCB, void *pRecvUserdata,
						wchar_t *pszHttpHeaders);
NCSError NCScnetCreateExW(wchar_t *szURL, void **ppClient, void *pPacketIn, int nLengthIn,
						void **ppPacketOut, INT32 *pLengthOut, NCSnetPacketRecvCB *pRecvCB, void *pRecvUserdata,
						wchar_t *pszIISDLLName, wchar_t *pszHttpHeaders);
NCSError NCScnetCreateProxyW(wchar_t *szURL, void **ppClient, void *pPacketIn, int nLengthIn,
						void **ppPacketOut, INT32 *pLengthOut, NCSnetPacketRecvCB *pRecvCB, void *pRecvUserdata,
						wchar_t *pszIISDLLName, wchar_t *pszUsername, wchar_t *pszPassword, wchar_t *pszHttpHeaders );
NCSError NCScnetPostURLW(wchar_t *szURL, void *szBody, wchar_t *szHeaders, wchar_t **ppAccept, BOOLEAN bIsPost, BOOLEAN bUseCache, UINT8**szResponse, int *nRespLength, UINT32 *pnStatusCode, UINT32 *pnContentLength);		/**[04]**/

NCSError NCScnetPostURLExtW(wchar_t *szURL, void *szBody, wchar_t *szHeaders, wchar_t **ppAccept, BOOLEAN bIsPost, BOOLEAN bUseCache, UINT8**szResponse, int *nRespLength, UINT32 *pnStatusCode, UINT32 *pnContentLength, wchar_t**ppContentType);

NCSError NCScnetPostURLExt2W(wchar_t *szURL, void *pBody, UINT32 nBodyLength, wchar_t *szHeaders, wchar_t **ppAccept, BOOLEAN bIsPost, BOOLEAN bUseCache, UINT8**szResponse, int *nRespLength, UINT32 *pnStatusCode, UINT32 *pnContentLength, wchar_t**ppContentType, BOOLEAN bSuppressDlg);

NCSError NCScnetPostURLExtSuppressDlgW(wchar_t *szURL, void *pBody, wchar_t *szHeaders, wchar_t **ppAccept, BOOLEAN bIsPost, 
									  BOOLEAN bUseCache, UINT8**szResponse, int *nRespLength, UINT32 *pnStatusCode,
									  UINT32 *pnContentLength, wchar_t**ppContentType);
NCSError NCScnetPostURLPersistentW(const wchar_t *szURL, void *pBody, UINT32 nBodyLength, wchar_t *szHeaders, wchar_t **ppAccept, BOOLEAN bIsPost, BOOLEAN bUseCache, NCScnetWriteCallback pWriteCB, int nDataReadSize, HINTERNET *hSession, HINTERNET *hConnection, void *pUserData, void **pResponse, UINT32 *nContentLength);

BOOLEAN NCScnetVerifyURLA(char *szURL);
void NCScnetSetIISDLLNameA(char *szDLLname);
NCSError NCScnetCreateA(char *szURL, void **ppClient, void *pPacketIn, int nLengthIn,
						void **ppPacketOut, INT32 *pLengthOut, NCSnetPacketRecvCB *pRecvCB, void *pRecvUserdata,
						char *pszHttpHeaders);
NCSError NCScnetCreateExA(char *szURL, void **ppClient, void *pPacketIn, int nLengthIn,
						void **ppPacketOut, INT32 *pLengthOut, NCSnetPacketRecvCB *pRecvCB, void *pRecvUserdata,
						char *pszIISDLLName, char *pszHttpHeaders);
NCSError NCScnetCreateProxyA(char *szURL, void **ppClient, void *pPacketIn, int nLengthIn,
						void **ppPacketOut, INT32 *pLengthOut, NCSnetPacketRecvCB *pRecvCB, void *pRecvUserdata,
						char *pszIISDLLName, char *pszUsername, char *pszPassword, char *pszHttpHeaders );
NCSError NCScnetPostURLA(char *szURL, void *szBody, char *szHeaders, char **ppAccept, BOOLEAN bIsPost, BOOLEAN bUseCache, UINT8**szResponse, int *nRespLength, UINT32 *pnStatusCode, UINT32 *pnContentLength);		/**[04]**/

NCSError NCScnetPostURLExtA(char *szURL, void *szBody, char *szHeaders, char **ppAccept, BOOLEAN bIsPost, BOOLEAN bUseCache, UINT8**szResponse, int *nRespLength, UINT32 *pnStatusCode, UINT32 *pnContentLength, char **ppContentType);

NCSError NCScnetPostURLExt2A(char *szURL, void *pBody, UINT32 nBodyLength, char *szHeaders, char **ppAccept, BOOLEAN bIsPost, BOOLEAN bUseCache, UINT8**szResponse, int *nRespLength, UINT32 *pnStatusCode, UINT32 *pnContentLength, char **ppContentType, BOOLEAN bSuppressDlg);

NCSError NCScnetPostURLExtSuppressDlgA(char *szURL, void *pBody, char *szHeaders, char **ppAccept, BOOLEAN bIsPost, 
									  BOOLEAN bUseCache, UINT8**szResponse, int *nRespLength, UINT32 *pnStatusCode,
									  UINT32 *pnContentLength, char**ppContentType);
NCSError NCScnetPostURLPersistentA(const char *szURL, void *pBody, UINT32 nBodyLength, char *szHeaders, char **ppAccept, BOOLEAN bIsPost, BOOLEAN bUseCache, NCScnetWriteCallback pWriteCB, int nDataReadSize, HINTERNET *hSession, HINTERNET *hConnection, void *pUserData, void **pResponse, UINT32 *nContentLength);

#ifdef UNICODE

#define NCScnetVerifyURL NCScnetVerifyURLW
#define NCScnetSetIISDLLName NCScnetSetIISDLLNameW
#define NCScnetCreate NCScnetCreateW
#define NCScnetCreateEx NCScnetCreateExW
#define NCScnetCreateProxy NCScnetCreateProxyW
#define NCScnetPostURL NCScnetPostURLW
#define NCScnetPostURLExt NCScnetPostURLExtW
#define NCScnetPostURLExt2 NCScnetPostURLExt2W
#define NCScnetPostURLExtSuppressDlg NCScnetPostURLExtSuppressDlgW
#define NCScnetPostURLPersistent NCScnetPostURLPersistentW

#else

#define NCScnetVerifyURL NCScnetVerifyURLA
#define NCScnetSetIISDLLNameNCScnetSetIISDLLNameA
#define NCScnetCreate NCScnetCreateA
#define NCScnetCreateEx NCScnetCreateExA
#define NCScnetCreateProxy NCScnetCreateProxyA
#define NCScnetPostURL NCScnetPostURLA
#define NCScnetPostURLExt NCScnetPostURLExtA
#define NCScnetPostURLExt2 NCScnetPostURLExt2A
#define NCScnetPostURLExtSuppressDlg NCScnetPostURLExtSuppressDlgA
#define NCScnetPostURLPersistent NCScnetPostURLPersistentA

#endif // UNICODE

void NCScnetSetSendBlocking(void *pConnection, BOOLEAN bOn);
void NCScnetSetRecvCB(pNCSnetClient pClient, NCSnetPacketRecvCB *pRecvCB, void *pUserdata);
void NCScnetSetSentCB(pNCSnetClient pClient, NCSnetPacketSentCB *pSentCB);
BOOLEAN NCS_EXPORT NCScnetIsPollingConnection(pNCSnetClient pClient);
BOOLEAN NCScnetSendPacket(pNCSnetClient pClient, void *pPacket, int nLength, void *pUserdata, BOOLEAN *bIsConnected);
void NCScnetCloseHandle(HINTERNET hInternet);
void NCScnetDestroy(pNCSnetClient pClient);
void NCScnetInit();
void NCScnetShutdown();

void NCScnetSetProxy( wchar_t *pProxy, INT32 nPort, wchar_t *pProxyBypass );

//
// Function specifically required for use by the IWS Proxy
//
#ifdef PROXYSERVER
void NCSUseWinHTTP( BOOL bValue );
#endif //PROXYSERVER

#if defined(_DEBUG) && defined (WIN32)
__declspec(dllexport) void NCScnetSetTimeout(BOOLEAN bTimeout);
#endif

#ifdef __cplusplus
};
#endif

#endif
