/********************************************************
** Copyright, 1998 - 2013, Intergraph Corporation. All rights reserved.
**
** FILE:   	NCSLog.h
** CREATED:	Mon May 31 09:19:00 WST 1999
** AUTHOR: 	Doug Mansell
** PURPOSE:	NCS server logging interface
** EDITS:
** [01] 06-06-02 Changed the Registry key names to match IWS 1.7
** [02] 08-12-05 tfl lint fixes
 *******************************************************/


#ifndef NCSLOG_H
#define NCSLOG_H

#ifndef NCSTYPES_H
#include "NCSTypes.h"
#endif // NCSTYPES_H

#define MOD_ECWSDK_UTIL	NCS_T("com.erdas.ecwsdk.util")
#define MOD_ECWSDK_CNET	NCS_T("com.erdas.ecwsdk.cnet")
#define MOD_ECWSDK_ECWJP2	NCS_T("com.erdas.ecwsdk.ecwjp2")
#define MOD_GENERIC_ERROR	NCS_T("com.erdas.generic.error")

#ifdef __cplusplus 
extern "C" {
#endif
#ifndef SWIG

#define NCS_SERVER_LOG_FILE_NAME_PREF		"Log Filename"		//[01]
#define NCS_SERVER_LOG_FILE_LEVEL_PREF		"Log Level"			//[01]
#define NCS_LOG_FILE_NAME_PREF				"IWS Log Filename"
#define NCS_LOG_FILE_LEVEL_PREF				"IWS Log Level"

typedef enum
{
	NCS_OFF_LEVEL = 60000, 
	NCS_FATAL_LEVEL = 50000,
	NCS_ERROR_LEVEL = 40000,
	NCS_WARN_LEVEL = 30000,
	NCS_INFO_LEVEL = 20000,
	NCS_DEBUG_LEVEL = 10000,
	NCS_TRACE_LEVEL = 0,
	NCS_ALL_LEVEL = NCS_TRACE_LEVEL,
	NCS_NOT_SET_LEVEL = -1
} NCSLogLevel;

void NCSLogGetConfig(char **pLogName, NCSLogLevel *pLogLevel);

void NCSLogA(char *moduleName, NCSLogLevel eLevel, char *szFormat, ...);
void NCSLogW(wchar_t *moduleName, NCSLogLevel eLevel, wchar_t *szFormat, ...);
#ifdef UNICODE

#define NCSLog NCSLogW

#else

#define NCSLog NCSLogA

#endif // UNICODE

void NCSLogSetServer(BOOLEAN bValue);



void NCSLogInit(void);
void NCSLogFini(void);

#endif //SWIG
#ifdef __cplusplus 
}

#ifndef NCSMUTEX_H
#include "NCSMutex.h"
#endif // NCSMUTEX_H

#ifndef NCSTHREAD_H
#include "NCSThread.h"
#endif // NCSTHREAD_H

#ifndef NCSSTRING_H
#include "NCSString.h"
#endif // NCSSTRING_H

#include <sstream>

#if defined(UNICODE) || defined( _UNICODE) 
#define ostringstream_i std::wostringstream 
#else
#define ostringstream_i std::ostringstream 
#endif

namespace log4cplus {
	class Logger;
}

namespace NCS {

class NCSECW_IMPEX CLog {
public:
	
	class NCSECW_IMPEX CRollingParameters {
	public:
		typedef enum {
			ROLLING_NONE,
			ROLLING_SIZE,
			ROLLING_MONTHLY,
			ROLLING_WEEKLY, 
			ROLLING_DAILY,
			ROLLING_TWICE_DAILY,
			ROLLING_HOURLY, 
			ROLLING_MINUTELY
		} RollingType;

		RollingType m_eRollingType;
		int m_nMaxFileSize;
		int m_nMaxBackupIndex;

		CRollingParameters(RollingType eRollingType, int nMaxFileSize, int nMaxBackupIndex):
			m_eRollingType(eRollingType), m_nMaxFileSize(nMaxFileSize), m_nMaxBackupIndex(nMaxBackupIndex)
		{
		};
		CRollingParameters() : m_eRollingType(ROLLING_NONE), m_nMaxFileSize(0), m_nMaxBackupIndex(0) {};
		CRollingParameters(const CRollingParameters &s) {
			(*this) = s;
		};
		virtual ~CRollingParameters() {};

		const CRollingParameters &operator=(const CRollingParameters &s) {
			m_eRollingType = s.m_eRollingType;
			m_nMaxFileSize = s.m_nMaxFileSize;
			m_nMaxBackupIndex = s.m_nMaxBackupIndex;
			return(*this);
		};

		bool operator==(const CRollingParameters &s) {
			return(m_eRollingType == s.m_eRollingType && m_nMaxFileSize == s.m_nMaxFileSize &&
				   m_nMaxBackupIndex == s.m_nMaxBackupIndex);
		}
	};

	static void Log(const wchar_t* moduleName, NCSLogLevel logLevel, const wchar_t* pFormat, ...);
	static void Log(const char* moduleName, NCSLogLevel logLevel, const char* pFormat, ...);
	static void LogInternal(const wchar_t* moduleName, NCSLogLevel logLevel, const wchar_t* pFormat, va_list va);
	static void LogInternal(const char* moduleName, NCSLogLevel logLevel, const char* pFormat, va_list va);
	static bool IsLogLevelEnabled(const CString& moduleName, NCSLogLevel logLevel);
	static void LogStream(const CString& moduleName, NCSLogLevel logLevel, const ostringstream_i& strStream);
	static void UpdateLogConfig(const char *pLogFile, const CRollingParameters &logRollingParams, NCSLogLevel logLevel = NCS_INFO_LEVEL);
	static void UpdateLogConfig(const wchar_t *pLogFile, const CRollingParameters &logRollingParams, NCSLogLevel logLevel = NCS_INFO_LEVEL);
	static void UpdateLogConfig(const NCSTChar *pLogFile, const NCSTChar *pConfigFile);

protected:
	CLog() {};
	virtual ~CLog() {};

private:

	static void Init(const CString& logFilePath, const CRollingParameters &logRollingParams);
	static void InitWithConfig(const CString& logFilePath, const CString& configFilePath);


	static NCS::CMutex	sm_Mutex;
	static bool s_bIsInitialised; 
	static wchar_t sm_szLogFile[MAX_PATH];
};

class NCSECW_IMPEX CLogFunctionTracer
{
public:
	CLogFunctionTracer(const CString& moduleName, const CString& functionName, const CString& message = NCS_T(""));
	virtual ~CLogFunctionTracer();
private:
	CString m_moduleName;
	CString m_functionName;
	CString m_message;
	bool m_bIsLogLevelEnabled;
};

}

#ifndef NCS_NO_COMPAT_NAMES
typedef NCS::CLog CNCSLog;
typedef NCS::CLogFunctionTracer CNCSLogFunctionTracer;
#endif

#define LOG_STREAM(moduleName, logLevel, streamContent) \
	if (CNCSLog::IsLogLevelEnabled(moduleName, logLevel)) { \
		ostringstream_i stream_buffer; \
			stream_buffer << streamContent; \
			CNCSLog::LogStream(moduleName, logLevel, stream_buffer); \
		}	

#define LOG_FUNCTION_TRACER(moduleName, functionName) \
	CNCSLogFunctionTracer funcTracer(moduleName, functionName);


#define LOGERROR0( t, e )	CLog::Log(__FILE__, __LINE__, NCS_FATAL_LEVEL, "Error: %s %s(%ld)", t, NCSGetErrorText(e), e)
#define LOGERROR1( t, e )	CLog::Log(__FILE__, __LINE__, NCS_ERROR_LEVEL, "Error: %s %s(%ld)", t, NCSGetErrorText(e), e)

#endif //__cplusplus

#endif //NCSLOG_H

