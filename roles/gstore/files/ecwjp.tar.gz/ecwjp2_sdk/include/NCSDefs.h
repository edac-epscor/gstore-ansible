/********************************************************
** Copyright, 1998 - 2013, Intergraph Corporation. All rights reserved.
**
** FILE:   	NCSDefs.h
** CREATED:	Tue Mar 2 09:19:00 WST 1999
** AUTHOR: 	Simon Cope
** PURPOSE:	General NCS defines
** EDITS:
** [01] sjc 30Apr00 Merged Mac SDK port
** [02]  ny 03Nov00 Merge WinCE/PALM SDK changes
** [03] tfl 14Jul04 Added radians/degrees conversion factors
 *******************************************************/

#ifndef NCSDEFS_H
#define NCSDEFS_H

#ifdef __cplusplus
extern "C" {
#endif

#ifndef NCS_BUILD_UNICODE
// Currently all targeted platforms support UNICODE.  This should currently never be undefined.
#define NCS_BUILD_UNICODE
#endif

#ifdef _WIN32
    #include <windows.h>
#else
    #include <wchar.h>
    #include <wctype.h>
#endif

#include <float.h>
#include <stdlib.h>
#include <string.h>

#ifdef POSIX
#ifndef NULL
#define NULL 0
#endif

#ifndef _strnicmp
#define _strnicmp strnicmp    
#endif    
    
#ifndef _wcsicmp
#define _wcsicmp wcsicmp
#endif     
    
#ifndef _wcsdup
#define _wcsdup wcsdup    
#endif    

#ifndef _wcsnicmp    
#define _wcsnicmp wcsnicmp
#endif
    
#ifndef _gcvt
#define _gcvt gcvt
#endif 

#endif

// When using the sun CC compiler you need to use %ls instead of %s for wide char strings
// also extern C functions must use 'extern "C"' when declared and implemented
#ifdef __SUNPRO_CC
	#define NCS_EXTERN_C_IMP extern "C"
    #ifdef NCS_BUILD_UNICODE
        #define NCS_TS NCS_T("%ls")
    #else
        #define NCS_TS NCS_T("%s")
    #endif
#else
	#define NCS_EXTERN_C_IMP
    #define NCS_TS NCS_T("%s")
#endif

#ifndef X86
#if defined(_WIN32) && (defined(_M_IX86) || defined(_M_X64)) // windows
#define X86
#elif defined(__GNUC__) && (defined(__i386__) || defined(__amd64__)) // gcc
#define X86
#endif
#endif // X86

#if (defined(SOLARIS) || defined(MACOSX)) && (!defined(X86))
#define NCSBO_MSBFIRST
#elif (defined(_WIN32) || defined(MACOSX) || defined(LINUX)) && defined(X86)
#define NCSBO_LSBFIRST
#else
#error Endianness not defined for platform
#endif

#if !defined(_WIN32_WCE)&&!defined(UNALIGNED)
#define UNALIGNED
#endif	/* !_WIN32_WCE */

#ifndef MAX
#define MAX(a, b) ((a) > (b) ? (a) : (b))
#endif
#ifndef MIN
#define MIN(a, b) ((a) > (b) ? (b) : (a))
#endif

#ifdef WIN32
    #define GCVT _gcvt
#else
    #define GCVT gcvt
#endif

#ifndef TRUE
#define TRUE 1
#endif
#ifndef FALSE
#define FALSE 0
#endif

#ifdef _WIN32

    #ifdef _WIN64
        #define NCS_64BIT
    #endif
    #ifndef MAXDOUBLE
        #define MAXDOUBLE   DBL_MAX			//1.7976931348623158e+308
        #define NCS_FQNAN	_FPCLASS_QNAN	//0x0002
        #define NCS_NAN		_FPCLASS_SNAN
    #endif	/* !MAXDOUBLE */

    #if defined(_WIN32_WCE)
        #define NCS_NO_UNALIGNED_ACCESS
        #ifndef MB_TASKMODAL
            #define MB_TASKMODAL MB_APPLMODAL
        #endif
    #endif // _WIN32_WCE

#elif defined MACOSX

    #include <limits.h>
    #include <ctype.h>
    #if defined(__LP64__) || defined(__x86_64__)
        #define NCS_64BIT
    #endif
    #define NCS_FQNAN	0x0002
    #define NCS_NAN		NAN
    #ifndef MAXDOUBLE
        #define MAXDOUBLE   DBL_MAX
    #endif
    //#define NCS_NO_UNALIGNED_ACCESS - this seems to be defined on Linux??

#elif defined SOLARIS || defined LINUX

    #ifdef LINUX
    #define wcsicmp wcscasecmp
    #endif

    #ifdef _AMD64_
    #define NCS_64BIT
    #endif

    #include <values.h>
    #include <limits.h>
    #include <ctype.h>
    #include <math.h>

    #ifndef MAXDOUBLE
    #define MAXDOUBLE   DBL_MAX			//1.7976931348623158e+308
    #endif	/* !MAXDOUBLE */

    #ifdef LINUX
        #define NCS_FQNAN	NAN	//0x0002
        #define NCS_NAN		NAN
    #elif defined(SOLARIS)
        #include <ieeefp.h>
        #define NCS_FQNAN	FP_QNAN
        #define NCS_NAN	FP_QNAN
    #else
        #error NAN not defined
    #endif

    // Solaris can't access types on unaligned addressed
    #define NCS_NO_UNALIGNED_ACCESS

    #if defined(SOLARIS)
        // SPARC has slow BYTE bit ops
        #define NCS_SLOW_CPU_BYTE_OPS
    #endif

#else

#error DEFINE SYSTEM INCLUDES FOR TYPES

#endif	/* _WIN32 */


/*Coodinate system defines*/
#define NCS_LINEAR_COORD_SYS	"linear"
#define	NCS_FEET_FACTOR			0.30480061
/*[03]*/
#define NCS_RADIANS_TO_DEGREES	57.29577951L
#define NCS_DEGREES_TO_RADIANS	1.745329252E-2L	

#if defined(_WIN32)

    #ifdef NCS_MANAGED_BUILD

    #define NCS_EXPORT
    #define NCS_IMPORT
    #define NCS_GC __gc
    #define NCS_VALUE __value
    #define NCS_PUBLIC public
    #define NCS_PROTECTED NCS_PUBLIC
    #define NCS_PRIVATE NCS_PUBLIC
    #ifdef __cplusplus
    #using <mscorlib.dll>
    #endif //__cplusplus

    #else // _MANAGED

    #if defined(_LIB)||defined(NCSECW_STATIC_LIBS)||defined(SWIG)
    #define NCS_EXPORT
    #define NCS_IMPORT
    #else
    #define NCS_EXPORT __declspec(dllexport)
    #define NCS_IMPORT __declspec(dllimport)
    #endif


    #define NCS_GC
    #define NCS_VALUE
    #define NCS_PUBLIC public
    #define NCS_PROTECTED protected
    #define NCS_PRIVATE private

    #endif // _MANAGED

    #ifdef _WIN32_WCE
    #define NCS_CALL
    #else
    #define NCS_CALL __cdecl
    #endif

    #define NCS_CB_CALL __cdecl

#else // _WIN32

#define NCS_EXPORT
#define NCS_IMPORT
#define NCS_GC
#define NCS_VALUE
#define NCS_PUBLIC public
#define NCS_PROTECTED protected
#define NCS_PRIVATE private

#define NCS_CALL
#define NCS_CB_CALL
#endif // _WIN32

#ifndef NCSECW_IMPEX
#ifdef NCSECW_EXPORTS
  #define NCSECW_IMPEX    NCS_EXPORT
#else
  #define NCSECW_IMPEX    NCS_IMPORT
#endif
#endif

#ifndef MAX_PATH
    #if defined SOLARIS || defined LINUX
        #ifdef PATH_MAX
        #define MAX_PATH	PATH_MAX
        #else
        #define MAX_PATH	1024
        #endif
    #elif defined MACOSX
        #define MAX_PATH 1024
    #else
        #define MAX_PATH	PATHNAMELEN
    #endif
#endif	/* !MAX_PATH */

#define NCSIsNullString(s) ((s) == (char *)0 || (*(s)) == '\0')
#define NCSIsNullStringW(s) ((s) == (wchar_t *)0 || (*(s)) == '\0')

#if	__ICL >= 700
#ifdef NCS_VECTOR_CC
//Note: need /QaxMiKW /Qvec_report3 /Qrestrict ICC flags to use vectorisation
#define NCS_RESTRICT restrict
#else
#define NCS_RESTRICT
#endif
#else
#define NCS_RESTRICT
#endif

#ifdef _OPENMP
#define NCS_OPENMP
#endif // _OPENMP

#ifdef NCS_OPENMP
#define NCS_VECTOR_CC
#endif // NCS_OPENMP

#ifndef NCS_INLINE
#ifdef SWIG
#define NCS_INLINE 
#elif _WIN32
#define NCS_INLINE __forceinline
#elif defined __GNUC__
#define NCS_INLINE __inline__
#elif __SUNPRO_CC
#define NCS_INLINE inline
#else
#define NCS_INLINE __inline
#endif // _WIN32
#endif // NCS_INLINE

#if defined(_WIN32) && !defined(NCSECW_STATIC_LIBS)
   #define CONDITIONAL_FORCEINLINE  __forceinline
#else
   #define CONDITIONAL_FORCEINLINE  
#endif

#include "NCSTypes.h"

/* 
 * Unicode/ASCII agnostic macros
 * These reimplement the Win32 "tchar" concept in a platform independent way.  
 * Just enough for what we need, extend as necessary.  Use in lieu of <tchar.h>
 * in any code that requires Unicode support.
 */

#ifndef NCS_TCHAR
#define NCS_TCHAR

#ifdef NCS_BUILD_UNICODE

#ifndef SWIG

#define NCSTChar wchar_t
#define NCS_T(x) L ## x
#define NCSTCmp(x,y) _wcsicmp(x,y)
#define NCSTCat(x,y) wcscat(x,y)
#define NCSTLen(x) wcslen(x)
#define NCSTCpy(x,y) wcscpy(x,y)
#define NCSTTol(x,y,z) wcstol(x,y,z)
#define NCSTTod(x,y) wcstod(x,y)
#ifdef POSIX
#define NCSTToll(x,y,z) wcstoll(x,y,z)
#else
#define NCSTToll(x,y,z) _wcstoi64(x,y,z)
#endif // POSIX
#define NCSTNCpy(x,y,z) wcsncpy(x,y,z)

#ifdef _WIN32
#define NCSTLwr _wcslwr
#define NCSTStr wcsstr
#ifdef _WIN32_WCE
#define NCSWinGPA_T NCS_T
#else
#define NCSWinGPA_T(x) x
#endif
#endif


#if !defined(MACOSX)
#include <malloc.h>
#endif
#include <stdio.h>

static NCS_INLINE wchar_t *NCSA2WHelper(wchar_t *lpw, const char *lpa, int nChars)
{
	if (!lpw) {

		return lpw; // NULL. the caller may use NCSChar2WChar instead

//#ifdef _WIN32
//		__try {
//			lpw = (wchar_t*) _alloca(((int)strlen(lpa)+1)*2*sizeof(wchar_t));
//		}
//		__except( GetExceptionCode() == STATUS_STACK_OVERFLOW )
//		{
//			//printf_s("_alloca failed!\n");
//			return lpw; // NULL. the caller may use NCSChar2WChar instead
//		};
//#else
//		lpw = (wchar_t*) _alloca(((int)strlen(lpa)+1)*2*sizeof(wchar_t));
//#endif
	}

	lpw[0] = '\0';
#ifdef _WIN32
	MultiByteToWideChar(CP_ACP, 0, (LPSTR)lpa, -1, (LPWSTR)lpw, nChars);
#else
	mbstowcs(lpw, lpa, nChars);
#endif
	return lpw;
}

static NCS_INLINE char *NCSW2AHelper(char *lpa, const wchar_t *lpw, int nChars)
{
	if (!lpa) {
        return NULL;
	}
	lpa[0] = '\0';
#ifdef _WIN32
	WideCharToMultiByte(CP_ACP, 0, (LPWSTR)lpw, -1, (LPSTR)lpa, nChars, NULL, NULL);
#else
	wcstombs(lpa, lpw, nChars);
#endif
	return lpa;
}


#define OS_STRING(lpa)		(((lpa) == NULL) ? NULL : NCSA2WHelper((wchar_t*) alloca(((int)strlen(lpa)+1)*2*sizeof(wchar_t)), (lpa), ((int)strlen(lpa)+1)))
#define CHAR_STRING(lpw)	(((lpw) == NULL) ? NULL : NCSW2AHelper((char*) alloca(((int)wcslen(lpw)+1)*2), (lpw), ((int)wcslen(lpw)+1)*2))


#endif //SWIG

#if defined POSIX
static NCS_INLINE int wcsnicmp(const wchar_t *s1, const wchar_t *s2, int nChars)
{
	int i=0;
	while ((*s1 != L'\0') && (*s2 != L'\0') && (towlower(*s1) == towlower(*s2)) && (i<nChars)) {
		s1++;
		s2++;
		i++;
	}
        if(i == nChars)
        {
            return 0;
        }
        else
        {
            return (towlower(*s1) - towlower(*s2));
        }
}
#endif

#if defined SOLARIS || defined MACOSX

static NCS_INLINE int wcsicmp(const wchar_t *s1, const wchar_t *s2)
{
	while ((*s2 != L'\0') && (towlower(*s1) == towlower(*s2))) {
		s1++;
		s2++;
	}
	return(towlower(*s1) - towlower(*s2));
}

#if __ENVIRONMENT_MAC_OS_X_VERSION_MIN_REQUIRED__ < 1070
/*
static NCS_INLINE wchar_t *wcsdup(const wchar_t *s1)
{
	size_t len = (wcslen(s1) + 1) * sizeof(wchar_t);
	wchar_t *s2 = (wchar_t*)malloc(len);
	memcpy(s2, s1, len);
	return(s2);
}
*/
#endif

#endif /* SOLARIS || MACOSX */

#define NCSTDup(x) _wcsdup(x)

#else	/* NCS_BUILD_UNICODE */
/* Define agnostic macros to provide ASCII character support */

#define NCSTChar char
#define NCS_T 
#define NCSTCmp(x,y) stricmp(x,y)
#define NCSTCat(x,y) strcat(x,y)
#define NCSTLen(x) strlen(x)
#define NCSTCpy(x,y) strcpy(x,y)
#define NCSTNCpy(x,y,z) strncpy(x,y,z)
#define NCSTTol(x,y,z) strtol(x,y,z)
#define NCSTTod(x,y) strtod(x,y)
#ifdef POSIX
#define NCSTToll(x,y,z) strtoll(x,y,z)
#else
#define NCSTToll(x,y,z) _strtoi64(x,y,z)
#endif // POSIX
#define NCSTDup(x)	NCSStrDup(x)

#ifdef _WIN32
#define NCSTLwr _strlwr
#define NCSTStr strstr
#define NCSWinGPA_T(x) x
#endif

#define OS_STRING(lpa)		(lpa)
#define CHAR_STRING(lpw)	(char *)(lpw)

#endif	/* NCS_BUILD_UNICODE */

#endif /* NCS_TCHAR */


#if defined(_WIN32)&&!defined(_WIN32_WCE)&&((defined(_M_IX86) && defined(_MSC_FULL_VER) && (_MSC_FULL_VER >= 12008804))||(defined(_M_X64) && defined(_MSC_VER) && _MSC_VER >= 1400))
//
// X86 "Multi Media Intrinsics" - ie, MMX, SSE, SSE2 optimisations
//
// Only defined if Win32, X86 and VC6 Processor Pack or newer _OR_ AMD64 and >= VS.NET 2005/AMD64 PlatformSDK compiler (ie, SSE intrinsics support in the compiler)
//
#define NCS_X86_MMI

#ifndef _M_X64
#define NCS_X86_MMI_MMX
#endif

#if (_MSC_VER >= 1500 || (__GNUC__ == 4 && __GNUC_MINOR__ >=3) || (__GNUC__ > 4) || __INTEL_COMPILER >= 1000)
    //FIXME MJS compiled out SSE code as its never worked
    //#define NCS_X86_MMI_SSSE3
    #define NCS_X86_MMI_SSE41
#endif

#endif

#ifdef LINUX
#   define NCS_X86_MMI
#endif //LINUX

#if defined (MACOSX) && defined(X86)
    #define NCS_X86_MMI
    #ifdef NOTDEF
        #ifdef __x86_64__
            #define _M_X64
        #endif
        #ifndef _M_X64
            #define NCS_X86_MMI_MMX
        #endif
        //#define NCS_X86_MMI_SSSE3
        //#define NCS_X86_MMI_SSE41
        //#define NCSJPC_X86_MMI
        //#define NCSJPC_X86_MMI_MMX
    #endif
#elif defined(MACOSX) && defined(_M_ARM)
    #define NCS_ARM_NEON
#endif //MACOSX

#if defined(_WIN32_WCE) && defined(_M_ARM)
    #define NCS_XSCALE_WMMX
#endif

#ifdef __cplusplus
}
#endif

#endif /* NCSDEFS_H */
