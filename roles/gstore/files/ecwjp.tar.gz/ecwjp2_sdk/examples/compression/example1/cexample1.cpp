/********************************************************** 
** Copyright, 1998 - 2013, Intergraph Corporation. All rights reserved.
**
** FILE:   	example1.c
** CREATED:	Tue 01/09/1999
** AUTHOR: 	Simon Cope
** PURPOSE:	ECW Compression SDK simple C Example
**			Creates an ECW v2.0 file in the current directory
**			based on image size defines below.
** EDITS:
**
********************************************************/

#include <stdio.h>
#include "NCSECWCompressClient.h"

/*
** Test image size
**
** Note: NOT limited to ^2 or square, we're just using that so we can create
** a simple pattern for the input
*/
#define TEST_NR_BANDS	4
#define TEST_WIDTH		500
#define TEST_HEIGHT		500

/*
** Structure to client read data
*/
typedef struct {
	UINT8		nPercent;
} ReadInfo;

/*
** Read callback function - called once for each input line
*/
static BOOLEAN ReadCallback(NCSCompressClient *pClient,
							UINT32 nNextLine,
							IEEE4 **ppInputArray)
{
	ReadInfo *pRI = (ReadInfo*)pClient->pClientData;
	UINT32 nBand;

	for(nBand = 0; nBand < pClient->nInputBands; nBand++) {
		UINT32 nCell;
		IEEE4 *pLine = ppInputArray[nBand];

		if(pClient->nInputBands == 1) {
			/* 1 band, do a grid pattern */
			for(nCell = 0; nCell < pClient->nInOutSizeX; nCell++) {
				if(((nCell / 30) % 2 == nBand) || ((nNextLine / 30) % 2 == nBand)) {
					pLine[nCell] = 255.0f;
				} else {
					pLine[nCell] = 0.0f;
				}
			}
		} else {
			if (pClient->nInputBands == 4 && nBand == 3) {
				for(nCell = 0; nCell < pClient->nInOutSizeX; nCell++) {
					// make a opacity box in the middle
					if (nCell > 125 &&
						nCell < 350 &&
						nNextLine > 80 &&
						nNextLine < 300) {
						pLine[nCell] = 0.0f;
					} else {
						pLine[nCell] = 1.0f;
					}
				}
			} else {
				for(nCell = 0; nCell < pClient->nInOutSizeX; nCell++) {
					// make a checkerboard effect 
					if(((nCell / 30) % 3 == nBand) && 
					   ((nNextLine / 30) % 3 == nBand)) {
						pLine[nCell] = 255.0f;
					} else {
						pLine[nCell] = 0.0f;
					}
				}
			}
		}
	}
	return(TRUE);	/* would return FALSE on an error */
}

/*
** Status callback function (OPTIONAL)
*/
static void StatusCallback(NCSCompressClient *pClient,
						   UINT32 nCurrentLine)
{
	ReadInfo *pRI = (ReadInfo*)pClient->pClientData;
	UINT32 nPercent = (nCurrentLine * 100) / (pClient->nInOutSizeY - 1);

	if(nPercent != pRI->nPercent) {
		fprintf(stdout, "%%%ld Complete\r\n", nPercent);
		fflush(stdout);
		pRI->nPercent = nPercent;
	}
}

/*
** Cancel callback function (OPTIONAL)
*/
static BOOLEAN CancelCallback(NCSCompressClient *pClient)
{
	/* Return TRUE to cancel compression */
	return(FALSE);
}

/*
** main()
*/
int main(int argc, char **argv)
{
	NCSCompressClient *pClient;

	if (argc != 2) 
	{
		fprintf(stderr,"Usage: %s <output filename>\r\n", argv[0]);
		exit(1);
	}

	/*
	** Initialize library resources
	*/
	NCSInit();
	
	// Please enter your company's name and key or contact erdasinfo@intergraph.com to obtain a key.
	char *szLicensee = getenv("ECW_Licensee");
	char *szOEMKey = getenv("ECW_Key");
	if(!szLicensee || !szOEMKey) {
		printf("Please enter your company's name and key in sample file: %s(%d).\nOr contact erdasinfo@intergraph.com to obtain a key.", __FILE__, __LINE__);
	} else {
		NCSCompressSetOEMKey(szLicensee, szOEMKey);
	}
	
	/*
	** First we need to alloc a client structure
	*/
	if(pClient = NCSCompressAllocClientA()) {
		NCSError eError;
		ReadInfo RI = { 0 };

		/*
		** Set up the input dimensions
		*/

		// To make an opacity channel for rgb - 
		// 1. set TEST_NR_BANDS to 4 and
		// 2. set pClient->eCompressFormat to COMPRESS_RGB
		// To make a normal rgb set set TEST_NR_BANDS to 3
		pClient->nInputBands = TEST_NR_BANDS;  
		pClient->nInOutSizeX = TEST_WIDTH;
		pClient->nInOutSizeY = TEST_HEIGHT;

		/*
		** Set format and ratio based on # of input bands
		**
		** Format can be:
		** COMPRESS_UINT8 (Grayscale)
		** COMPRESS_RGB   (RGB)
		** COMPRESS_MULTI (Multi band grayscale)
		** COMPRESS_YUV	  (YUV)
		*/
		if(pClient->nInputBands == 1) {
			pClient->eCompressFormat = NCS_COMPRESS_UINT8;
			pClient->fTargetCompression = 20.0f;
		} else if(pClient->nInputBands == 4) {
			pClient->eCompressFormat = NCS_COMPRESS_RGB;
			pClient->fTargetCompression = 10.0f;
		} else {
			pClient->eCompressFormat = NCS_COMPRESS_MULTI;
			pClient->fTargetCompression = 20.0f;
		}

		/*
		** Give output filename
		*/
		strncpy(pClient->uOutputFileName.szOutputFileName, argv[1], MAX_PATH);

		/*
		** Specify the callbacks and client data ptr
		*/
		pClient->pReadCallback = ReadCallback;
		pClient->pStatusCallback = StatusCallback;
		pClient->pCancelCallback = CancelCallback;
		pClient->pClientData = (void*)&RI;		

		/*
		** Open the compression
		*/
		eError = NCSCompressOpen(pClient, FALSE);

		if(eError == NCS_SUCCESS) {
			/*
			** Opened OK, now do the compression
			*/
			eError = NCSCompress(pClient);

			/*
			** Close the compression
			*/
			NCSCompressClose(pClient);
		}
		if(eError == NCS_SUCCESS) {
			/*
			** Compressed OK, output stats
			*/
			fprintf(stdout, "Target ratio:    %.1lf\r\n"
							"Actual ratio:    %.1lf\r\n"
#ifdef WIN32
							"Output size:     %I64d bytes\r\n"
#else
							"Output size:     %lld bytes\r\n"
#endif
							"Time taken:      %.1lf seconds\r\n"
							"Data Rate:       %.1lf MB/s\r\n",
							pClient->fTargetCompression,
							pClient->fActualCompression,
							pClient->nOutputSize,
							pClient->fCompressionSeconds,
							pClient->fCompressionMBSec);
			fflush(stdout);
		} else {
			/*
			** Got an error, dump to stderr
			*/
			fprintf(stderr, "Compression error: %s\r\n", NCSGetErrorText(eError)); 
			fflush(stderr);
		}
		/*
		** Free client
		*/
		NCSCompressFreeClient(pClient);
	} else {
		/*
		** Couldn't alloc client structure
		*/
		fprintf(stderr, "NCSCompressAllocClient() failed!");
		fflush(stderr);
	}

	NCSShutdown();
	
	return(0);
}
