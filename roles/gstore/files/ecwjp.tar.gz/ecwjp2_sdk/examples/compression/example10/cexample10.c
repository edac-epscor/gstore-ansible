/********************************************************** 
** Copyright, 1998 - 2013, Intergraph Corporation. All rights reserved.
**
** FILE:   	cexample10.cpp
** CREATED:	28th May 2012
** AUTHOR: 	Yakun Wang
**
** PURPOSE:	
**	1. Compress an ECW file with setting file metadata, rpc and stats data using C API functions
**  2. Retrieve the data from the file using C API functions and print them.
**			
** Note: output file should be the ecw type
*******************************************************/

#include "NCSECWClient.h"
#include "NCSUtil.h"
#include "NCSErrors.h"
#include "NCSECWCompressClient.h"
#include <time.h>


/*
** Read callback function - called once for each input line
*/
BOOLEAN ReadCallback(NCSCompressClient *pClient, UINT32 nNextLine, IEEE4 **ppInputArray)
{
	float fMin, fMax;
	UINT32 nBand;

	switch(pClient->nCellBitDepth) {
		case 8:
		default:
			fMin = 0.0f;
			fMax = 255.0f;
			break;
		case 16:
			fMin = 0.0f;
			fMax = 65535.0f;
			break;
		case 28:
			fMin = 0.0f;
			fMax = (float)0x0fffffff;
			break;
	}

	for(nBand = 0; nBand < pClient->nInputBands; nBand++) {
		UINT32 nCell;
		IEEE4 *pLine = ppInputArray[nBand];

		if(pClient->nInputBands == 1) {
			/* 1 band, do a grid pattern */
			for(nCell = 0; nCell < pClient->nInOutSizeX; nCell++) {
				if(((nCell / 30) % 2 == nBand) || ((nNextLine / 30) % 2 == nBand)) {
					pLine[nCell] = fMax;
				} else {
					pLine[nCell] = fMin;
				}
			}
		} else {
			if (pClient->nInputBands == 4 && nBand == 3) {
				for(nCell = 0; nCell < pClient->nInOutSizeX; nCell++) {
					// make a opacity box in the middle
					if (nCell > 125 &&
						nCell < 350 &&
						nNextLine > 80 &&
						nNextLine < 300) {
						pLine[nCell] = 0.0f;
					} else {
						pLine[nCell] = 255.0f;
					}
				}
			} else {
				for(nCell = 0; nCell < pClient->nInOutSizeX; nCell++) {
					// make a checkerboard effect 
					if(((nCell / 30) % 3 == nBand) && 
					   ((nNextLine / 30) % 3 == nBand)) {
						pLine[nCell] = fMax;
					} else {
						pLine[nCell] = fMin;
					}
				}
			}
		}
	}
	return(TRUE);	
}

/*
** Status callback function (OPTIONAL)
*/
void StatusCallback(NCSCompressClient *pClient,
						   UINT32 nCurrentLine)
{
}

/*
** Cancel callback function (OPTIONAL)
*/
BOOLEAN CancelCallback(NCSCompressClient *pClient)
{
	/* Return TRUE to cancel compression */
	return(FALSE);
}

NCSFileMetaData* GenerateFileMetaData(NCSFileMetaData* pFileMetaData)
{
	pFileMetaData->sClassification = (NCSTChar*)NCSMalloc(256, TRUE);
	NCSTCpy(pFileMetaData->sClassification, NCS_T("Perth metro region data map"));
	pFileMetaData->sAcquisitionDate = (NCSTChar*)NCSMalloc(256, TRUE);
	NCSTCpy(pFileMetaData->sAcquisitionDate, NCS_T("2012-02-29"));
	pFileMetaData->sAcquisitionSensorName = (NCSTChar*)NCSMalloc(256, TRUE);
	NCSTCpy(pFileMetaData->sAcquisitionSensorName, NCS_T("Satellite Leica Pixs N1344"));

	return pFileMetaData;
}

NCSFileStatistics* GenerateClientStatistics(UINT32 numberOfBands, UINT32 maxPixelValue, UINT32 histogramBucketCount)
{
	UINT32 i, j;
	
	//Generate some random numbers based on the range, please use the calculated values in real application
	NCSFileStatistics* pStats = NULL;
	srand ( time(NULL) );
	NCSInitStatisticsDefault(&pStats, numberOfBands, histogramBucketCount);
		
	for (i = 0; i < pStats->nNumberOfBands; i++)
	{
		pStats->BandsStats[i].fMinVal = 0;
		pStats->BandsStats[i].fMaxVal = rand() % (maxPixelValue + 1);
		if (pStats->BandsStats[i].fMaxVal == 0)
			pStats->BandsStats[i].fMaxVal += 1;
		pStats->BandsStats[i].fMeanVal = rand() % ((UINT32)pStats->BandsStats[i].fMaxVal);
		pStats->BandsStats[i].fMedianVal = rand() % ((UINT32)pStats->BandsStats[i].fMaxVal);
		pStats->BandsStats[i].fMode = rand() % pStats->BandsStats[i].nHistBucketCount;
		pStats->BandsStats[i].fStandardDev = rand() % ((UINT32)pStats->BandsStats[i].fMaxVal);
		for (j = 0; j < pStats->BandsStats[i].nHistBucketCount; j++)
		{
			pStats->BandsStats[i].Histogram[j] = rand();
		}
	}

	return pStats;
}

NCSRPCData* GenerateRPCData()
{
	NCSRPCData* pRPCData = NULL;
	pRPCData = (NCSRPCData*)NCSMalloc(sizeof(NCSRPCData), TRUE);
	pRPCData->ERR_BIAS = 12.23;
	pRPCData->ERR_RAND = 0.48;
	pRPCData->LINE_OFF = 3522;
	pRPCData->SAMP_OFF = 4406;
	pRPCData->LAT_OFF = 35.2298;
	pRPCData->LONG_OFF = -80.8601;
	pRPCData->HEIGHT_OFF = 186;
	pRPCData->LINE_SCALE = 3639;
	pRPCData->SAMP_SCALE = 4421;
	pRPCData->LAT_SCALE = 0.0780;
	pRPCData->LONG_SCALE = 0.1020;
	pRPCData->HEIGHT_SCALE = 501;
	
	pRPCData->LINE_NUM_COEFFS[0] = -2.082755E-03; pRPCData->LINE_NUM_COEFFS[1] = -2.790828E-02; pRPCData->LINE_NUM_COEFFS[2] = -9.964968E-01; pRPCData->LINE_NUM_COEFFS[3] = -3.190691E-02;
	pRPCData->LINE_NUM_COEFFS[4] = +2.425357E-05; pRPCData->LINE_NUM_COEFFS[5] = -5.681094E-06; pRPCData->LINE_NUM_COEFFS[6] = -5.331409E-05; pRPCData->LINE_NUM_COEFFS[7] = -1.206832E-04;
	pRPCData->LINE_NUM_COEFFS[8] = +2.643640E-03; pRPCData->LINE_NUM_COEFFS[9] = -8.340423E-07; pRPCData->LINE_NUM_COEFFS[10] =  -6.097826E-07; pRPCData->LINE_NUM_COEFFS[11] =  -6.092152E-07;
	pRPCData->LINE_NUM_COEFFS[12] = -1.137766E-05; pRPCData->LINE_NUM_COEFFS[13] = -8.744738E-07; pRPCData->LINE_NUM_COEFFS[14] = -2.174531E-05; pRPCData->LINE_NUM_COEFFS[15] = -1.302682E-04;
	pRPCData->LINE_NUM_COEFFS[16] =  -3.115474E-05; pRPCData->LINE_NUM_COEFFS[17] =  -7.160171E-07; pRPCData->LINE_NUM_COEFFS[18] =  -1.194601E-05; pRPCData->LINE_NUM_COEFFS[19] =  -5.147002E-07;
	
	pRPCData->LINE_DEN_COEFFS[0] = 1.000000E+00; pRPCData->LINE_DEN_COEFFS[1] = -3.544814E-05; pRPCData->LINE_DEN_COEFFS[2] = +6.950074E-04; pRPCData->LINE_DEN_COEFFS[3] = -1.014129E-04;
	pRPCData->LINE_DEN_COEFFS[4] = -1.088161E-05; pRPCData->LINE_DEN_COEFFS[5] = -4.797741E-07; pRPCData->LINE_DEN_COEFFS[6] = -5.799360E-06; pRPCData->LINE_DEN_COEFFS[7] = +2.503022E-05;
	pRPCData->LINE_DEN_COEFFS[8] = -7.031893E-05; pRPCData->LINE_DEN_COEFFS[9] = +3.031918E-05; pRPCData->LINE_DEN_COEFFS[10] = -2.059119E-06; pRPCData->LINE_DEN_COEFFS[11] = -2.263008E-08;
	pRPCData->LINE_DEN_COEFFS[12] = -4.625445E-05; pRPCData->LINE_DEN_COEFFS[13] = -6.111694E-08; pRPCData->LINE_DEN_COEFFS[14] = -1.372970E-06; pRPCData->LINE_DEN_COEFFS[15] = -5.243668E-04;
	pRPCData->LINE_DEN_COEFFS[16] = -2.111056E-06; pRPCData->LINE_DEN_COEFFS[17] = -4.327521E-08; pRPCData->LINE_DEN_COEFFS[18] = -3.563140E-05; pRPCData->LINE_DEN_COEFFS[19] = +2.449699E-07;

	pRPCData->SAMP_NUM_COEFFS[0] = -7.918007E-05; pRPCData->SAMP_NUM_COEFFS[1] =  +1.000871E+00; pRPCData->SAMP_NUM_COEFFS[2] =  -1.068091E-03; pRPCData->SAMP_NUM_COEFFS[3] = -2.365811E-03;
	pRPCData->SAMP_NUM_COEFFS[4] = -1.618173E-03; pRPCData->SAMP_NUM_COEFFS[5] =  +3.305229E-04; pRPCData->SAMP_NUM_COEFFS[6] =  -6.274837E-05; pRPCData->SAMP_NUM_COEFFS[7] = +2.923455E-04;
	pRPCData->SAMP_NUM_COEFFS[8] = +4.374891E-04; pRPCData->SAMP_NUM_COEFFS[9] =  -3.186432E-06; pRPCData->SAMP_NUM_COEFFS[10] =  -7.150948E-07; pRPCData->SAMP_NUM_COEFFS[11] = -8.546845E-06;
	pRPCData->SAMP_NUM_COEFFS[12] = -9.369117E-06; pRPCData->SAMP_NUM_COEFFS[13] =  -3.439202E-06; pRPCData->SAMP_NUM_COEFFS[14] =  +1.115874E-05; pRPCData->SAMP_NUM_COEFFS[15] = +3.265740E-05;
	pRPCData->SAMP_NUM_COEFFS[16] = -2.978212E-07; pRPCData->SAMP_NUM_COEFFS[17] =  +6.902997E-07; pRPCData->SAMP_NUM_COEFFS[18] =  +2.256772E-06; pRPCData->SAMP_NUM_COEFFS[19] = +6.943991E-08;

	pRPCData->SAMP_DEN_COEFFS[0] = +1.000000E+00; pRPCData->SAMP_DEN_COEFFS[1] = -2.142645E-04; pRPCData->SAMP_DEN_COEFFS[2] = +1.619261E-03; pRPCData->SAMP_DEN_COEFFS[3] = -3.311616E-04;
	pRPCData->SAMP_DEN_COEFFS[4] = -3.635326E-06; pRPCData->SAMP_DEN_COEFFS[5] = -2.020304E-07; pRPCData->SAMP_DEN_COEFFS[6] = +8.403076E-07; pRPCData->SAMP_DEN_COEFFS[7] = +5.506581E-07;
	pRPCData->SAMP_DEN_COEFFS[8] = +4.711838E-06; pRPCData->SAMP_DEN_COEFFS[9] = -3.610730E-06; pRPCData->SAMP_DEN_COEFFS[10] = -1.963179E-08; pRPCData->SAMP_DEN_COEFFS[11] = +0.000000E+00;
	pRPCData->SAMP_DEN_COEFFS[12] = +3.080076E-08; pRPCData->SAMP_DEN_COEFFS[13] = +0.000000E+00; pRPCData->SAMP_DEN_COEFFS[14] = -5.210861E-08; pRPCData->SAMP_DEN_COEFFS[15] = -5.862951E-07;
	pRPCData->SAMP_DEN_COEFFS[16] = -1.541843E-08; pRPCData->SAMP_DEN_COEFFS[17] = +0.000000E+00; pRPCData->SAMP_DEN_COEFFS[18] = -3.558677E-08; pRPCData->SAMP_DEN_COEFFS[19] = +0.000000E+00;
	
	return pRPCData;
}

BOOLEAN PrintDataToScreen(char* fileName)
{
	NCSFileView		*pNCSFileView = NULL;
	char pTemp[128];
	NCSFileStatistics* pStats = NULL;
	NCSFileInfo *pFileInfo = NULL;
	NCSRPCData* pRPCData = NULL;
	NCSError error;
	int j, k;

	error = NCSOpenFileViewA(fileName, &pNCSFileView, NULL);
	if (error != NCS_SUCCESS)
	{
		printf("Unable to open the file: %s\r\n", fileName);
		return FALSE;
	}
	
	printf("Start printing filemeta, stats and rpc data on file: %s\r\n", fileName);

	//get file info data
	if ((error = NCSGetViewFileInfo(pNCSFileView, &pFileInfo)) != NCS_SUCCESS)
	{
		printf("Unable to get file info from the file: %s\r\n", fileName);
		return FALSE;
	}
	if (pFileInfo && pFileInfo->pFileMetaData)
	{
		printf("File metadata :\r\n");
		printf("\tsClassification:\t%ls\r\n",pFileInfo->pFileMetaData->sClassification);
		printf("\tsAcquisitionDate:\t%ls\r\n",pFileInfo->pFileMetaData->sAcquisitionDate);
		printf("\tsAcquisitionSensorName:\t%ls\r\n",pFileInfo->pFileMetaData->sAcquisitionSensorName);
		printf("\tsCompressionSoftware:\t%ls\r\n",pFileInfo->pFileMetaData->sCompressionSoftware);
		printf("\tsAuthor:\t%ls\r\n",pFileInfo->pFileMetaData->sAuthor);
		printf("\tsCopyright:\t%ls\r\n",pFileInfo->pFileMetaData->sCopyright);
		printf("\tsCompany:\t%ls\r\n",pFileInfo->pFileMetaData->sCompany);
		printf("\tsEmail:\t%ls\r\n",pFileInfo->pFileMetaData->sEmail);
		printf("\tsAddress:\t%ls\r\n",pFileInfo->pFileMetaData->sAddress);
		printf("\tsTelephone:\t%ls\r\n",pFileInfo->pFileMetaData->sTelephone);
	}

	//get statistics data
	error =  NCSGetViewStatistics(pNCSFileView, &pStats);
	if (error != NCS_SUCCESS) 
	{
		printf("Unable to get statistics data from the file %s for extended reporting.\r\n", fileName);
		return FALSE;
	}
	if(pStats)
	{
		printf("Statistics Data: \r\n");
		for (j = 0; j < pStats->nNumberOfBands; j++)
		{
			printf("Band Min value: %lf\r\n", pStats->BandsStats[j].fMinVal);
			printf("Band Max value: %lf\r\n", pStats->BandsStats[j].fMaxVal);
			printf("Band Mean Value: %lf\r\n", pStats->BandsStats[j].fMeanVal);
			printf("Band Median Value: %lf\r\n", pStats->BandsStats[j].fMedianVal);
			printf("Band Mode Value: %lf\r\n", pStats->BandsStats[j].fMode);
			printf("Band Standard Deviation Value: %lf\r\n", pStats->BandsStats[j].fStandardDev);
			printf("Band Histogram: ");
			for (k = 0; k < pStats->BandsStats[j].nHistBucketCount; k++)
			{
				printf(" %ld |", pStats->BandsStats[j].Histogram[k]);
			}
			printf("\r\n");
		}
	}
	NCSFreeStatistics(pStats);

	//get RPC data
	error =  NCSGetViewRPCData(pNCSFileView, &pRPCData);
	if (error != NCS_SUCCESS) 
	{
		printf("Failure get rpc data from input ECW file %s for extended reporting.\r\n", fileName);
		return FALSE;
	}
	if (pRPCData)
	{
		printf("ERR_BIAS : %lf\r\n", pRPCData->ERR_BIAS);
		printf("ERR_RAND : %lf\r\n", pRPCData->ERR_RAND);
		printf("HEIGHT_OFF : %lf\r\n", pRPCData->HEIGHT_OFF);
		printf("HEIGHT_SCALE : %lf\r\n", pRPCData->HEIGHT_SCALE);
		printf("LAT_OFF : %lf\r\n", pRPCData->LAT_OFF);
		printf("LAT_OFF : %lf\r\n", pRPCData->LAT_SCALE);
		printf("LINE_OFF : %lf\r\n", pRPCData->LINE_OFF);
		printf("LINE_SCALE : %lf\r\n", pRPCData->LINE_SCALE);
		printf("LONG_OFF : %lf\r\n", pRPCData->LONG_OFF);
		printf("LONG_SCALE : %lf\r\n", pRPCData->LONG_SCALE);
		printf("SAMP_OFF : %lf\r\n", pRPCData->SAMP_OFF);
		printf("SAMP_SCALE : %lf\r\n", pRPCData->SAMP_SCALE);
		printf("LINE_DEN_COEFFS : ");
		for (j = 0; j < 20; j++)
		{
			printf(" %+E |", pRPCData->LINE_DEN_COEFFS[j]);
		}
		printf("\r\n");
		printf("LINE_NUM_COEFFS : ");
		for (j = 0; j < 20; j++)
		{
			printf(" %+E |", pRPCData->LINE_NUM_COEFFS[j]);
		}
		printf("\r\n");
		printf("SAMP_DEN_COEFFS : ");
		for (j = 0; j < 20; j++)
		{
			printf(" %+E |", pRPCData->SAMP_DEN_COEFFS[j]);
		}
		printf("\r\n");
		printf("SAMP_NUM_COEFFS : ");
		for (j = 0; j < 20; j++)
		{
			printf(" %+E |", pRPCData->SAMP_NUM_COEFFS[j]);
		}
		printf("\r\n");
	}
	NCSFreeRPCData(pRPCData);

	//close the file view
	NCSCloseFileView(pNCSFileView);

	printf("Finish printing filemeta, stats and rpc data on file: %s", fileName);

	return TRUE;
}

int main(int argc, char* argv[])
{
	char *szLicensee = NULL;
	char *szOEMKey = NULL;
	NCSCompressClient *pClient = NULL;
	NCSFileMetaData* pFileMetaData = NULL;
	NCSFileStatistics* pStats =  NULL;
	NCSRPCData* pRPCData = NULL;
	char* extName = NULL;

	NCSInit();

	if(argc < 2) {
		printf("Usage: %s <output filename.ecw>\n", argv[0]);
		exit(1);
	}

	extName = argv[1] + strlen(argv[1]) - 4;
	if(strcmp(extName, ".ecw") != 0){
		printf("Must be an .ecw file.\n\n");
		NCSShutdown();
		exit(1);
	}

	szLicensee = getenv("ECW_Licensee");
	szOEMKey = getenv("ECW_Key");
	// Please enter your company's name and key or contact erdasinfo@intergraph.com to obtain a key.
	if(!szLicensee || !szOEMKey) {
		printf("Please enter your company's name and key in sample file: %s(%d).\nOr contact erdasinfo@intergraph.com to obtain a key.", __FILE__, __LINE__);
		NCSShutdown();
		exit(1);
	} else {
		NCSCompressSetOEMKey(szLicensee, szOEMKey);
	}

	// Allocate compression client and set fields for compression
	pClient = NCSCompressAllocClient();
	if (pClient == NULL)
	{
		printf("Unable to create Compress Client.\n");
		NCSShutdown();
		exit(1);
	}

	pClient->nInputBands = (UINT16)3;  
	pClient->nInOutSizeX = 1000;
	pClient->nInOutSizeY = 1000;
	pClient->eCompressFormat = NCS_COMPRESS_RGB;
	pClient->fTargetCompression = 8.0f;
	strncpy(pClient->uOutputFileName.szOutputFileName, argv[1], MAX_PATH);

	pClient->pReadCallback = ReadCallback;
	pClient->pStatusCallback = StatusCallback;
	pClient->pCancelCallback = CancelCallback;
	pClient->nCellBitDepth = 8;
	pClient->nFormatVersion = 3;
	pClient->pClientData = NULL;


	//Populate the file metadata
	NCSInitMetaData(&pFileMetaData);
	GenerateFileMetaData(pFileMetaData);
	pClient->pFileMetaData = pFileMetaData;
	

	//Generate some valid statistics and rpc data
	pStats = GenerateClientStatistics(3, 255, 256);
	pRPCData = GenerateRPCData();
	
	//Open the compression client 
	if (NCSCompressOpen(pClient, FALSE) != NCS_SUCCESS)
	{
		printf("Unable to open the compressor.\n");
		NCSShutdown();
		exit(1);
	}
	
	//Set the generated statistics onto the client
	if (NCSCompressSetStatistics(pClient, pStats) != NCS_SUCCESS)
	{
		printf("Unable to set the stats.\n");
		NCSShutdown();
		exit(1);
	}

	//Set the generated RPC data onto the client
	if (NCSCompressSetRPCData(pClient, pRPCData) != NCS_SUCCESS)
	{
		printf("Unable to set the rpc data.\n");
		NCSShutdown();
		exit(1);
	}
	
	//Compress 
	if (NCSCompress(pClient) != NCS_SUCCESS)
	{
		printf("Compression failed.\n");
		NCSShutdown();
		exit(1);
	}
	
	//Close the pClient
	NCSCompressClose(pClient);
	
	//Compression is finished. Retrieve the rpc and stats and prints them. Free all the allocated structures
	PrintDataToScreen(argv[1]);
	NCSFreeMetaData(pFileMetaData);
	NCSFreeStatistics(pStats);
	NCSFreeRPCData(pRPCData);

	NCSShutdown();

	return 0;
}

