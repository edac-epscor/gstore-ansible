/********************************************************** 
** Copyright, 1998 - 2013, Intergraph Corporation. All rights reserved.
**  
** FILE:   	cexample9.cpp
** CREATED:	28th May 2012
** AUTHOR: 	Yakun Wang
**
** PURPOSE:	
**	1. Compress an ECW file with setting file metadata, rpc and stats data 
**  2. Retrieve the data from the file and print them.
**			
** Note: output file should be the ecw type
*******************************************************/

#include "NCSFile.h"
#include "NCSEcw/SDK/Buffer2D.h"
#include "NCSUtil.h"
#include "NCSEcw/API/HeaderEditor.h"

/**
 * \class	CTileCompressor
 *
 * \brief	Tile compressor class that handles the WriteReadTile Requests from the ECW compressor.
**/
class CTileCompressor : public NCS::CView
{
public:
	CTileCompressor() : NCS::CView(), m_ValidRegion(200, 200, 800, 800)
	{
		m_fMinValue = (IEEE4)0.0f;
		m_fMaxValue = (IEEE4)255.0f;

		m_BackgroundColours.resize(3);
		m_BackgroundColours[0] = 125.0f;
		m_BackgroundColours[1] = 38.0f;
		m_BackgroundColours[2] = 205.0f;
	};
	virtual ~CTileCompressor() {};

	/**
	 * \fn	NCS::CView::CompressInputType CTileCompressor::GetCompressInputType()
	 *
	 * \brief	Tells the SDK to use the TILE compressor.
	 *
	 * \return	The compress input type.
	**/
	NCS::CView::CompressInputType GetCompressInputType() { 
		return NCS::CView::TILE; 
	};

	/**
	 * \fn	virtual bool CTileCompressor::SetupBackgroundColour(std::vector<IEEE4> &BandColours)
	 *
	 * \brief	Sets up the background colour for NULL regions.
	 *
	 * \param [in,out]	BandColours	List of colours of the bands.
	 *
	 * \return	true if it succeeds, false if it fails.
	**/
	virtual bool SetupBackgroundColour(std::vector<IEEE4> &BandColours) { 
		BandColours[0] = m_BackgroundColours[0];
		BandColours[1] = m_BackgroundColours[1];
		BandColours[2] = m_BackgroundColours[2];
		return true;
	};

	/**
	 * \fn	bool CTileCompressor::WriteReadTile(const NCS::SDK::CRect2D &Tile,
	 * 		SDK::CBuffer2DVector &Buffers, bool &bIsRegionNULL)
	 *
	 * \brief	Returns the imagery data for the region designated by the Tile param.
	 *
	 * \param	Tile				 	The tile.
	 * \param [in,out]	Buffers		 	The buffers.
	 * \param [in,out]	bIsRegionNULL	The is region null.
	 *
	 * \return	true if it succeeds, false if it fails.
	**/
	bool WriteReadTile(const NCS::SDK::CRect2D &Tile, NCS::SDK::CBuffer2DVector &Buffers, bool &bIsRegionNULL)
	{
		IEEE4 *pLine;
		
		// If the Tile param does not intersect the valid region, then this tile is NULL
		NCS::SDK::CRect2D Intersection = Tile & m_ValidRegion;
		if(Intersection.GetX0() >= Intersection.GetX1() ||
		   Intersection.GetY0() >= Intersection.GetY1()) {

			bIsRegionNULL = true;
			return true;
		}

		bIsRegionNULL = false;
		for(INT32 nB = 0; nB < (INT32)Buffers.size(); nB++) {
			
			// if we only need to partially fill this buffer, then
			// prefill the buffer with the background colour
			if(Intersection != (NCS::SDK::CRect2D &)Buffers[0]) {
				Buffers[nB].Set(m_BackgroundColours[nB]);
			}
			
			for(INT32 nY = Intersection.GetY0(); nY < Intersection.GetY1(); nY++) {
				pLine = (IEEE4*)Buffers[nB].GetPtr(Intersection.GetX0(), nY);
				for(INT32 nX = Intersection.GetX0(); nX < Intersection.GetX1(); nX++) {
					//pLine[nX] = (IEEE4)nY;
					//// make a checkerboard effect 
					if(((nX / 30) % 3 == nB) && 
					   ((nY / 30) % 3 == nB)) {
						*pLine = m_fMaxValue;
					} else {
						*pLine = m_fMinValue;
					}
					pLine++;
				}
			}
		}
		return true;
	};
protected:
	IEEE4 m_fMinValue;
	IEEE4 m_fMaxValue;
	NCS::SDK::CRect2D m_ValidRegion;
	std::vector<IEEE4> m_BackgroundColours;
};

NCSFileMetaData* GenerateFileMetaData(NCSFileMetaData* pFileMetaData)
{
	pFileMetaData->sClassification = (NCSTChar*)NCSMalloc(256, true);
	NCSTCpy(pFileMetaData->sClassification, NCS_T("Perth metro region data map"));
	pFileMetaData->sAcquisitionDate = (NCSTChar*)NCSMalloc(256, true);
	NCSTCpy(pFileMetaData->sAcquisitionDate, NCS_T("2012-02-29"));
	pFileMetaData->sAcquisitionSensorName = (NCSTChar*)NCSMalloc(256, true);
	NCSTCpy(pFileMetaData->sAcquisitionSensorName, NCS_T("Satellite Leica Pixs N1344"));

	return pFileMetaData;
}

NCSFileStatistics* GenerateClientStatistics(UINT32 numberOfBands, UINT32 maxPixelValue, UINT32 histogramBucketCount)
{
	//Generate some random numbers based on the range, please use the calculated values in real application
	NCSFileStatistics* pStats = NULL;
	srand ( time(NULL) );
	NCSInitStatisticsDefault(&pStats, numberOfBands, histogramBucketCount);
		
	for (std::size_t i = 0; i < pStats->nNumberOfBands; i++)
	{
		pStats->BandsStats[i].fMinVal = 0;
		pStats->BandsStats[i].fMaxVal = rand() % (maxPixelValue + 1);
		if (pStats->BandsStats[i].fMaxVal == 0)
			pStats->BandsStats[i].fMaxVal += 1;
		pStats->BandsStats[i].fMeanVal = rand() % ((UINT32)pStats->BandsStats[i].fMaxVal);
		pStats->BandsStats[i].fMedianVal = rand() % ((UINT32)pStats->BandsStats[i].fMaxVal);
		pStats->BandsStats[i].fMode = rand() % pStats->BandsStats[i].nHistBucketCount;
		pStats->BandsStats[i].fStandardDev = rand() % ((UINT32)pStats->BandsStats[i].fMaxVal);
		for (std::size_t j = 0; j < pStats->BandsStats[i].nHistBucketCount; j++)
		{
			pStats->BandsStats[i].Histogram[j] = rand();
		}
	}

	return pStats;
}

NCSRPCData* GenerateRPCData()
{
	NCSRPCData* pRPCData = NULL;
	pRPCData = (NCSRPCData*)NCSMalloc(sizeof(NCSRPCData), true);
	pRPCData->ERR_BIAS = 12.23;
	pRPCData->ERR_RAND = 0.48;
	pRPCData->LINE_OFF = 3522;
	pRPCData->SAMP_OFF = 4406;
	pRPCData->LAT_OFF = 35.2298;
	pRPCData->LONG_OFF = -80.8601;
	pRPCData->HEIGHT_OFF = 186;
	pRPCData->LINE_SCALE = 3639;
	pRPCData->SAMP_SCALE = 4421;
	pRPCData->LAT_SCALE = 0.0780;
	pRPCData->LONG_SCALE = 0.1020;
	pRPCData->HEIGHT_SCALE = 501;
	
	pRPCData->LINE_NUM_COEFFS[0] = -2.082755E-03; pRPCData->LINE_NUM_COEFFS[1] = -2.790828E-02; pRPCData->LINE_NUM_COEFFS[2] = -9.964968E-01; pRPCData->LINE_NUM_COEFFS[3] = -3.190691E-02;
	pRPCData->LINE_NUM_COEFFS[4] = +2.425357E-05; pRPCData->LINE_NUM_COEFFS[5] = -5.681094E-06; pRPCData->LINE_NUM_COEFFS[6] = -5.331409E-05; pRPCData->LINE_NUM_COEFFS[7] = -1.206832E-04;
	pRPCData->LINE_NUM_COEFFS[8] = +2.643640E-03; pRPCData->LINE_NUM_COEFFS[9] = -8.340423E-07; pRPCData->LINE_NUM_COEFFS[10] =  -6.097826E-07; pRPCData->LINE_NUM_COEFFS[11] =  -6.092152E-07;
	pRPCData->LINE_NUM_COEFFS[12] = -1.137766E-05; pRPCData->LINE_NUM_COEFFS[13] = -8.744738E-07; pRPCData->LINE_NUM_COEFFS[14] = -2.174531E-05; pRPCData->LINE_NUM_COEFFS[15] = -1.302682E-04;
	pRPCData->LINE_NUM_COEFFS[16] =  -3.115474E-05; pRPCData->LINE_NUM_COEFFS[17] =  -7.160171E-07; pRPCData->LINE_NUM_COEFFS[18] =  -1.194601E-05; pRPCData->LINE_NUM_COEFFS[19] =  -5.147002E-07;
	
	pRPCData->LINE_DEN_COEFFS[0] = 1.000000E+00; pRPCData->LINE_DEN_COEFFS[1] = -3.544814E-05; pRPCData->LINE_DEN_COEFFS[2] = +6.950074E-04; pRPCData->LINE_DEN_COEFFS[3] = -1.014129E-04;
	pRPCData->LINE_DEN_COEFFS[4] = -1.088161E-05; pRPCData->LINE_DEN_COEFFS[5] = -4.797741E-07; pRPCData->LINE_DEN_COEFFS[6] = -5.799360E-06; pRPCData->LINE_DEN_COEFFS[7] = +2.503022E-05;
	pRPCData->LINE_DEN_COEFFS[8] = -7.031893E-05; pRPCData->LINE_DEN_COEFFS[9] = +3.031918E-05; pRPCData->LINE_DEN_COEFFS[10] = -2.059119E-06; pRPCData->LINE_DEN_COEFFS[11] = -2.263008E-08;
	pRPCData->LINE_DEN_COEFFS[12] = -4.625445E-05; pRPCData->LINE_DEN_COEFFS[13] = -6.111694E-08; pRPCData->LINE_DEN_COEFFS[14] = -1.372970E-06; pRPCData->LINE_DEN_COEFFS[15] = -5.243668E-04;
	pRPCData->LINE_DEN_COEFFS[16] = -2.111056E-06; pRPCData->LINE_DEN_COEFFS[17] = -4.327521E-08; pRPCData->LINE_DEN_COEFFS[18] = -3.563140E-05; pRPCData->LINE_DEN_COEFFS[19] = +2.449699E-07;

	pRPCData->SAMP_NUM_COEFFS[0] = -7.918007E-05; pRPCData->SAMP_NUM_COEFFS[1] =  +1.000871E+00; pRPCData->SAMP_NUM_COEFFS[2] =  -1.068091E-03; pRPCData->SAMP_NUM_COEFFS[3] = -2.365811E-03;
	pRPCData->SAMP_NUM_COEFFS[4] = -1.618173E-03; pRPCData->SAMP_NUM_COEFFS[5] =  +3.305229E-04; pRPCData->SAMP_NUM_COEFFS[6] =  -6.274837E-05; pRPCData->SAMP_NUM_COEFFS[7] = +2.923455E-04;
	pRPCData->SAMP_NUM_COEFFS[8] = +4.374891E-04; pRPCData->SAMP_NUM_COEFFS[9] =  -3.186432E-06; pRPCData->SAMP_NUM_COEFFS[10] =  -7.150948E-07; pRPCData->SAMP_NUM_COEFFS[11] = -8.546845E-06;
	pRPCData->SAMP_NUM_COEFFS[12] = -9.369117E-06; pRPCData->SAMP_NUM_COEFFS[13] =  -3.439202E-06; pRPCData->SAMP_NUM_COEFFS[14] =  +1.115874E-05; pRPCData->SAMP_NUM_COEFFS[15] = +3.265740E-05;
	pRPCData->SAMP_NUM_COEFFS[16] = -2.978212E-07; pRPCData->SAMP_NUM_COEFFS[17] =  +6.902997E-07; pRPCData->SAMP_NUM_COEFFS[18] =  +2.256772E-06; pRPCData->SAMP_NUM_COEFFS[19] = +6.943991E-08;

	pRPCData->SAMP_DEN_COEFFS[0] = +1.000000E+00; pRPCData->SAMP_DEN_COEFFS[1] = -2.142645E-04; pRPCData->SAMP_DEN_COEFFS[2] = +1.619261E-03; pRPCData->SAMP_DEN_COEFFS[3] = -3.311616E-04;
	pRPCData->SAMP_DEN_COEFFS[4] = -3.635326E-06; pRPCData->SAMP_DEN_COEFFS[5] = -2.020304E-07; pRPCData->SAMP_DEN_COEFFS[6] = +8.403076E-07; pRPCData->SAMP_DEN_COEFFS[7] = +5.506581E-07;
	pRPCData->SAMP_DEN_COEFFS[8] = +4.711838E-06; pRPCData->SAMP_DEN_COEFFS[9] = -3.610730E-06; pRPCData->SAMP_DEN_COEFFS[10] = -1.963179E-08; pRPCData->SAMP_DEN_COEFFS[11] = +0.000000E+00;
	pRPCData->SAMP_DEN_COEFFS[12] = +3.080076E-08; pRPCData->SAMP_DEN_COEFFS[13] = +0.000000E+00; pRPCData->SAMP_DEN_COEFFS[14] = -5.210861E-08; pRPCData->SAMP_DEN_COEFFS[15] = -5.862951E-07;
	pRPCData->SAMP_DEN_COEFFS[16] = -1.541843E-08; pRPCData->SAMP_DEN_COEFFS[17] = +0.000000E+00; pRPCData->SAMP_DEN_COEFFS[18] = -3.558677E-08; pRPCData->SAMP_DEN_COEFFS[19] = +0.000000E+00;
	
	return pRPCData;
}

bool PrintDataToScreen(char* fileName)
{
	NCS::CView fileView;
	std::string report;
	char pTemp[128];
	NCSFileStatistics* pStats = NULL;
	NCSRPCData* pRPCData = NULL;
	NCSError error = fileView.Open(fileName);
	
	std::cout << "Start printing filemeta, stats and rpc data on file: " << fileName << std::endl;

	//filemetadata 
	NCSFileInfo& info = *fileView.GetFileInfo();
	if (info.pFileMetaData)
	{
		report += "File metadata :\r\n";
		sprintf(pTemp,"\tsClassification:\t%ls\r\n",info.pFileMetaData->sClassification);
		report += pTemp;
		sprintf(pTemp,"\tsAcquisitionDate:\t%ls\r\n",info.pFileMetaData->sAcquisitionDate);
		report += pTemp;
		sprintf(pTemp,"\tsAcquisitionSensorName:\t%ls\r\n",info.pFileMetaData->sAcquisitionSensorName);
		report += pTemp;
		sprintf(pTemp,"\tsCompressionSoftware:\t%ls\r\n",info.pFileMetaData->sCompressionSoftware);
		report += pTemp;
		sprintf(pTemp,"\tsAuthor:\t%ls\r\n",info.pFileMetaData->sAuthor);
		report += pTemp;
		sprintf(pTemp,"\tsCopyright:\t%ls\r\n",info.pFileMetaData->sCopyright);
		report += pTemp;
		sprintf(pTemp,"\tsCompany:\t%ls\r\n",info.pFileMetaData->sCompany);
		report += pTemp;
		sprintf(pTemp,"\tsEmail:\t%ls\r\n",info.pFileMetaData->sEmail);
		report += pTemp;
		sprintf(pTemp,"\tsAddress:\t%ls\r\n",info.pFileMetaData->sAddress);
		report += pTemp;
		sprintf(pTemp,"\tsTelephone:\t%ls\r\n",info.pFileMetaData->sTelephone);
		report += pTemp;
	}

	//stats data
	error = fileView.GetClientStatistics(&pStats);
	if (error != NCS_SUCCESS) 
	{
		report += "Failure get stats data from input ECW file " + std::string(fileName) + " for extended reporting.\r\n";
		return false;
	}
	if(pStats)
	{
		report += "Statistics Data: \r\n";
		for (int j = 0; j < pStats->nNumberOfBands; j++)
		{
			sprintf(pTemp, "Band Min value: %lf\r\n", pStats->BandsStats[j].fMinVal);
			report += pTemp;
			sprintf(pTemp, "Band Max value: %lf\r\n", pStats->BandsStats[j].fMaxVal);
			report += pTemp;
			sprintf(pTemp, "Band Mean Value: %lf\r\n", pStats->BandsStats[j].fMeanVal);
			report += pTemp;
			sprintf(pTemp, "Band Median Value: %lf\r\n", pStats->BandsStats[j].fMedianVal);
			report += pTemp;
			sprintf(pTemp, "Band Mode Value: %lf\r\n", pStats->BandsStats[j].fMode);
			report += pTemp;
			sprintf(pTemp, "Band Standard Deviation Value: %lf\r\n", pStats->BandsStats[j].fStandardDev);
			report += pTemp;
			sprintf(pTemp, "Band Histogram: ");
			for (int k = 0; k < pStats->BandsStats[j].nHistBucketCount; k++)
			{
				sprintf(pTemp, " %ld |", pStats->BandsStats[j].Histogram[k]);
				report += pTemp;
			}
			report += "\r\n";
		}
	}
	NCSFreeStatistics(pStats);
	pStats = NULL;

	//rpc data
	error = fileView.GetRPCData(&pRPCData);
	if (error != NCS_SUCCESS) 
	{
		report += "Failure get rpc data from input ECW file " + std::string(fileName) + " for extended reporting.\r\n";
		return false;
	}
	if (pRPCData)
	{
		report += "RPC Data: \r\n";
		sprintf(pTemp, "ERR_BIAS : %lf\r\n", pRPCData->ERR_BIAS);
		report += pTemp;
		sprintf(pTemp, "ERR_RAND : %lf\r\n", pRPCData->ERR_RAND);
		report += pTemp;
		sprintf(pTemp, "HEIGHT_OFF : %lf\r\n", pRPCData->HEIGHT_OFF);
		report += pTemp;
		sprintf(pTemp, "HEIGHT_SCALE : %lf\r\n", pRPCData->HEIGHT_SCALE);
		report += pTemp;
		sprintf(pTemp, "LAT_OFF : %lf\r\n", pRPCData->LAT_OFF);
		report += pTemp;
		sprintf(pTemp, "LAT_OFF : %lf\r\n", pRPCData->LAT_SCALE);
		report += pTemp;
		sprintf(pTemp, "LINE_OFF : %lf\r\n", pRPCData->LINE_OFF);
		report += pTemp;
		sprintf(pTemp, "LINE_SCALE : %lf\r\n", pRPCData->LINE_SCALE);
		report += pTemp;
		sprintf(pTemp, "LONG_OFF : %lf\r\n", pRPCData->LONG_OFF);
		report += pTemp;
		sprintf(pTemp, "LONG_SCALE : %lf\r\n", pRPCData->LONG_SCALE);
		report += pTemp;
		sprintf(pTemp, "SAMP_OFF : %lf\r\n", pRPCData->SAMP_OFF);
		report += pTemp;
		sprintf(pTemp, "SAMP_SCALE : %lf\r\n", pRPCData->SAMP_SCALE);
		report += pTemp;
		report += "LINE_DEN_COEFFS : ";
		for (int j = 0; j < 20; j++)
		{
			sprintf(pTemp, " %+E |", pRPCData->LINE_DEN_COEFFS[j]);
			report += pTemp;
		}
		report += "\r\n";
		report += "LINE_NUM_COEFFS : ";
		for (int j = 0; j < 20; j++)
		{
			sprintf(pTemp, " %+E |", pRPCData->LINE_NUM_COEFFS[j]);
			report += pTemp;
		}
		report += "\r\n";
		report += "SAMP_DEN_COEFFS : ";
		for (int j = 0; j < 20; j++)
		{
			sprintf(pTemp, " %+E |", pRPCData->SAMP_DEN_COEFFS[j]);
			report += pTemp;
		}
		report += "\r\n";
		report += "SAMP_NUM_COEFFS : ";
		for (int j = 0; j < 20; j++)
		{
			sprintf(pTemp, " %+E |", pRPCData->SAMP_NUM_COEFFS[j]);
			report += pTemp;
		}
		report += "\r\n";
	}
	NCSFreeRPCData(pRPCData);
	pRPCData = NULL;

	//print it out
	std::cout << report << std::endl;
	std::cout << "Finish printing filemeta, stats and rpc data on file: " << fileName << std::endl;
}

int main(int argc, char* argv[])
{
	NCS::CApplication App;

	if(argc < 2) {
		printf("Usage: %s <output filename.ecw>\n", argv[0]);
		exit(1);
	}

	NCS::CString sFile = argv[1];
	if(!sFile.EndsWith(NCS_T(".ecw"), true)) {
		printf("Must be an .ecw file.\n\n");
		exit(1);
	}

	// Please enter your company's name and key or contact erdasinfo@intergraph.com to obtain a key.
	char *szLicensee = getenv("ECW_Licensee");
	char *szOEMKey = getenv("ECW_Key");
	if(!szLicensee || !szOEMKey) {
		printf("Please enter your company's name and key in sample file: %s(%d).\nOr contact erdasinfo@intergraph.com to obtain a key.", __FILE__, __LINE__);
		exit(1);
	} else {
		CNCSFile::SetOEMKey(szLicensee, szOEMKey);
	}

	NCS::CString sRAW = NCS_T("RAW");

	CTileCompressor Output;

	NCSFileInfo Info;
	NCSInitFileInfo(&Info);
	Info.eCellSizeUnits = ECW_CELL_UNITS_METERS;
	Info.eCellType = NCSCT_UINT8;
	Info.fCellIncrementX = 1.0;
	Info.fCellIncrementY = 1.0;
	Info.fOriginX = 0.0;
	Info.fOriginY = 0.0;
	Info.nBands = (UINT16)3;
	Info.nCompressionRate = (UINT16)8;
	Info.nSizeX = 1000;
	Info.nSizeY = 1000;
	Info.pBands = NULL;
	Info.szDatum = (char*)sRAW.a_str();
	Info.szProjection = (char*)sRAW.a_str();
	Info.eColorSpace = NCSCS_sRGB;
	Info.fCWRotationDegrees = 0.0;
	Info.nCellBitDepth = 8;
	Info.nFormatVersion = 3; // must be version 3 for NULL blocks to be supported
	
	//Populate the file metadata
	NCSFileMetaData* pFileMetaData = NULL;
	NCSInitMetaData(&pFileMetaData);
	GenerateFileMetaData(pFileMetaData);
	Info.pFileMetaData = pFileMetaData;

	Output.SetParameter("ECW:BLOCKSIZE:X", (INT32)64);
	Output.SetParameter("ECW:BLOCKSIZE:Y", (INT32)64);
	Output.SetParameter("ECW:HUFFMANEDCODE:FLAG", (INT32)1);
	NCS::CError Error;
	
	Error = Output.SetFileInfo(Info);

	if(!Error.Success()) {
		printf("Unable to set file info |: %s.\n\n", NCSGetLastErrorText(Error.GetErrorNumber()));
		exit(1);
	}

	//Generate some valid statistics and rpc data
	NCSFileStatistics* pStats = GenerateClientStatistics(3, 255, 256);
	NCSRPCData* pRPCData = GenerateRPCData();

	
	Error = Output.Open(sFile, false, true);
	if(!Error.Success()) {
		printf("Unable to open output file |: %s.\n\n", NCSGetLastErrorText(Error.GetErrorNumber()));
		exit(1);
	}
	Error = Output.SetClientStatistics(pStats);
	if(!Error.Success()) {
		printf("Unable to set the client stats. |: %s.\n\n", NCSGetLastErrorText(Error.GetErrorNumber()));
		exit(1);
	}
	Error = Output.SetRPCData(pRPCData);
	if(!Error.Success()) {
		printf("Unable to set the rpc data. |: %s.\n\n", NCSGetLastErrorText(Error.GetErrorNumber()));
		exit(1);
	}
	Error = Output.Write();
	if(!Error.Success()) {
		printf("Compression failed :: %s", NCSGetLastErrorText(Error.GetErrorNumber()));
		exit(1);
	}
	Error = Output.Close();
	if(!Error.Success()) {
		printf("Close failed :: %s", NCSGetLastErrorText(Error.GetErrorNumber()));
		exit(1);
	}
	
	
	//Compression is finished. Retrieve the rpc and stats and prints them. Free all the allocated structures
	PrintDataToScreen(argv[1]);
	NCSFreeMetaData(Info.pFileMetaData);
	NCSFreeStatistics(pStats);
	NCSFreeRPCData(pRPCData);

	return 0;
}

