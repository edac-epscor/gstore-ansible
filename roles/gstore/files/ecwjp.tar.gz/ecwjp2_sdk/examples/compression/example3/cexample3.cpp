/********************************************************** 
** Copyright, 1998 - 2013, Intergraph Corporation. All rights reserved.
**  
** FILE:   	example3.cpp
** CREATED:	Fri 24/09/2004
** AUTHOR: 	Tom Lynch
** PURPOSE:	ECW Compression SDK: recompression from ECW or JPEG 
**		2000 input to lossless JPEG 2000 output using C++ API
** EDITS:
**
********************************************************/

#include "NCSFile.h"

// CLosslessCompressor class
//
// A subclass of CNCSFile.
class CLosslessCompressor: public CNCSFile {
public:
	// Default constructor
	CLosslessCompressor() 
	{
		m_bGenNulls = true;
		m_nPercentComplete = 0;
	};
	// Virtual destructor.  
	virtual ~CLosslessCompressor() {};

	// Lossless recompression
	virtual CNCSError Recompress(char *pSrcFile, char *pDstFile);

	// WriteReadLine, WriteStatus, and WriteCancel are inherited from the base CNCSFile class, 
	// and overriden to perform the compression.

	// WriteReadLine() - called by SDK once for each line read.  
	// The parameters passed are the next line number being read from the input, 
	// and a pointer to a buffer into which that line's data should be loaded by 
	// your code.
	//
	// The cell type of the buffer is the same as that passed into SetFileInfo() in the 
	// NCSFileInfo struct.
	virtual CNCSError WriteReadLine(UINT32 nNextLine, void **ppInputArray);

	virtual void WriteReadLineOpacity(UINT32 nNextLine, UINT32 nSizeX, NCSCellType eCellType, void *ppInputArray);

	virtual void WriteStatus(IEEE4 fPercentComplete, const NCS::CString &sStatusText, const CompressionCounters &Counters);
	// A cancel function called by the SDK which will cancel the compression if it returns 
	// true.  We override it here without actually introducing cancel functionality.
	virtual bool WriteCancel();

	// Get the input cell type so the SDK can convert to the required type internally for compression
	virtual NCSCellType WriteReadLineGetCellType() {
		return GetFileInfo()->eCellType;
	}

private:
	// CNCSFile member variable that is used for our input file, which may be an ECW or JPEG 
	// 2000 file in this example.
	CNCSFile m_Src;
	int m_nPercentComplete;
	bool m_bGenNulls;
};


CNCSError CLosslessCompressor::Recompress(char *pSrcFile, char *pDstFile)
{
	// First open the input file, and check to make sure it opened OK.
	CNCSError Error = m_Src.Open(pSrcFile, false);
	if(Error == NCS_SUCCESS) {

			//NCSFileInfo has basic info about the file - dimensions, bands, 
			//georeferencing information etc.
			NCSFileInfo *pInfo = m_Src.GetFileInfo();
			NCSFileInfo *DstInfo = (NCSFileInfo *)NCSMalloc(sizeof(NCSFileInfo), true);
			NCSCopyFileInfo(DstInfo, pInfo);

			//Create some parameters for a SetView - in this case, since we 
			//are losslessly recompressing the entire file, we simply 
			//copy the extents of the input file.
			INT32 *Bands = new INT32[pInfo->nBands];
			for (INT32 nBand = 0; nBand < pInfo->nBands; nBand++)
				Bands[nBand] = nBand;
					
			UINT32 nWidth, nHeight;			
			IEEE8 fStartX, fStartY, fEndX, fEndY;
			
			nWidth = pInfo->nSizeX;
			nHeight = pInfo->nSizeY;
			fStartX = pInfo->fOriginX;
			fStartY = pInfo->fOriginY;
			
			fEndX = fStartX + pInfo->fCellIncrementX * nWidth;
			fEndY = fStartY + pInfo->fCellIncrementY * nHeight;

			Error = m_Src.SetView(pInfo->nBands, Bands,
								  nWidth, nHeight,
								  fStartX, 
								  fStartY,
								  fEndX,
								  fEndY);
			if(Error == NCS_SUCCESS) {
				// check if need to generate an opacity band
				if(DstInfo->pBands) {
					for(UINT32 b = 0; b < DstInfo->nBands; b++) {
						if( strcmp( NCS_BANDDESC_AllOpacity,DstInfo->pBands[b].szDesc)==0 ) {
							// already have an opacity band - dont need another one.
							m_bGenNulls = false;
						}
					}
				}
				if (m_bGenNulls) {
					// behaviour is generate an opacity layer if one does not already exist. 
					// generated opacity layer has a blocked out region in it - see 
					// WriteReadLineOpacity() below.
					// have to reset the pBands structure, and increase the nr of bands in the pInfo.
					DstInfo->pBands = (NCSFileBandInfo*)NCSRealloc(DstInfo->pBands, sizeof(NCSFileBandInfo) * (DstInfo->nBands+1), TRUE);
					DstInfo->nBands +=1;
					// simple get and check extension
					char *pExt = strrchr(pDstFile,'.');
					if (pExt) {
						if (strcmp(pExt,  ".ecw")==0) {
							// opacity nBits = 8 for ecw files
							DstInfo->pBands[DstInfo->nBands-1].nBits = DstInfo->nCellBitDepth; 
						} else {
							// opacity nBits = 1 for jp2 files
							DstInfo->pBands[DstInfo->nBands-1].nBits = 1; 
						}
					}
					DstInfo->pBands[DstInfo->nBands-1].bSigned = 0;
					DstInfo->pBands[DstInfo->nBands-1].szDesc = NCSStrDup(NCS_BANDDESC_AllOpacity);
				}
				// OK - now can copy the Source NCSFileInfo
				
				DstInfo->nCompressionRate = 1; //LOSSLESS for JPEG 2000 output (or near lossless for ecw)

				//Call SetFileInfo to establish the file information we are going to 
				//use for compression.  The parameters used is the NCSFileInfo 
				//struct we have populated using metadata derived from our input raster.
				Error = SetFileInfo(*DstInfo);
				if(Error == NCS_SUCCESS) {
					//Open the output file.  The second parameter is whether we are opening 
					//in progressive read mode (no) and the third is whether we want to write 
					//a new JPEG 2000 or ECW file (yes).
					Error = Open(pDstFile, false, true);
						
					if(Error == NCS_SUCCESS) {
						//Create the output.  Will return NCS_USER_CANCELLED_COMPRESSION if WriteCancel() 
						//returns true, another error code if something goes wrong, or NCS_SUCCESS.
						Error = Write();
						if (Error == NCS_SUCCESS)
							fprintf(stdout,"Finished compression\n");
						else if (Error == NCS_USER_CANCELLED_COMPRESSION)
							fprintf(stdout,"Compression cancelled\n");
						else fprintf(stdout,"Error during compression: %ls\n",Error.GetErrorMessage().c_str());
						fflush(stdout);
						Error = Close(true);
					}

				} else {
					Error = NCS_COULDNT_ALLOC_MEMORY;
				}
			}
			delete Bands;	
			NCSFreeFileInfo(DstInfo);
	}
	return(Error);
}

void CLosslessCompressor::WriteReadLineOpacity(UINT32 nNextLine, UINT32 nSizeX, NCSCellType eCellType, void *ppInputArray)
{
	UINT8 v;
	UINT32 tl_x = 125;
	UINT32 br_x = 350;
	UINT32 tl_y = 80;
	UINT32 br_y = 300;
	UINT32 nCell;

	// make a opacity box in the image somewhere
	// not this is an arbitary box - not be suited to very small images (< 350 x 300)
	// have to cater for all types...

	switch(eCellType) {
		case NCSCT_UINT8:
			for(nCell = 0; nCell < nSizeX; nCell++) {
				if (nCell > tl_x && nCell < br_x && nNextLine > tl_y &&	nNextLine < br_y) {
					v = 0;
				} else {
					v = 1;
				}
				((UINT8*)ppInputArray)[nCell] = v;
			}
		break;			
		case NCSCT_UINT16:
			for(nCell = 0; nCell < nSizeX; nCell++) {
				if (nCell > tl_x && nCell < br_x && nNextLine > tl_y &&	nNextLine < br_y) {
					v = 0;
				} else {
					v = 1;
				}
				((UINT16*)ppInputArray)[nCell] = v;
			}
			break;
		case NCSCT_UINT32:
			for(nCell = 0; nCell < nSizeX; nCell++) {
				if (nCell > tl_x && nCell < br_x && nNextLine > tl_y &&	nNextLine < br_y) {
					v = 0;
				} else {
					v = 1;
				}
				((UINT32*)ppInputArray)[nCell] = v;
			}
			break;
		case NCSCT_UINT64:
			for(nCell = 0; nCell < nSizeX; nCell++) {
				if (nCell > tl_x && nCell < br_x && nNextLine > tl_y &&	nNextLine < br_y) {
					v = 0;
				} else {
					v = 1;
				}
				((UINT64*)ppInputArray)[nCell] = v;
			}
			break;
		case NCSCT_INT8:	
			for(nCell = 0; nCell < nSizeX; nCell++) {
				if (nCell > tl_x && nCell < br_x && nNextLine > tl_y &&	nNextLine < br_y) {
					v = 0;
				} else {
					v = 1;
				}
				((INT8*)ppInputArray)[nCell] = v;
			}
			break;			
		case NCSCT_INT16:
			for(nCell = 0; nCell < nSizeX; nCell++) {
				if (nCell > tl_x && nCell < br_x && nNextLine > tl_y &&	nNextLine < br_y) {
					v = 0;
				} else {
					v = 1;
				}
				((INT16*)ppInputArray)[nCell] = v;
			}
			break;
		case NCSCT_INT32:
			for(nCell = 0; nCell < nSizeX; nCell++) {
				if (nCell > tl_x && nCell < br_x && nNextLine > tl_y &&	nNextLine < br_y) {
					v = 0;
				} else {
					v = 1;
				}
				((INT32*)ppInputArray)[nCell] = v;
			}
			break;
		case NCSCT_INT64:
			for(nCell = 0; nCell < nSizeX; nCell++) {
				if (nCell > tl_x && nCell < br_x && nNextLine > tl_y &&	nNextLine < br_y) {
					v = 0;
				} else {
					v = 1;
				}
				((INT64*)ppInputArray)[nCell] = v;
			}
			break;
		case NCSCT_IEEE4:
			for(nCell = 0; nCell < nSizeX; nCell++) {
				if (nCell > tl_x && nCell < br_x && nNextLine > tl_y &&	nNextLine < br_y) {
					v = 0;
				} else {
					v = 1;
				}
				((IEEE4*)ppInputArray)[nCell] = v;
			}
			break;
		case NCSCT_IEEE8:
			for(nCell = 0; nCell < nSizeX; nCell++) {
				if (nCell > tl_x && nCell < br_x && nNextLine > tl_y &&	nNextLine < br_y) {
					v = 0;
				} else {
					v = 1;
				}
				((IEEE8*)ppInputArray)[nCell] = v;
			}
			break;
		default:
			break;
	}
}

// This is called once for each output line.
// In this example, we can simply call ReadLineBIL on m_Src.
//

CNCSError CLosslessCompressor::WriteReadLine(UINT32 nNextLine, void **ppInputArray)
{
	NCSFileInfo *pInfo = GetFileInfo();
	if (m_bGenNulls) {
		// write opacity into the last band
		WriteReadLineOpacity(nNextLine, pInfo->nSizeX, pInfo->eCellType, ppInputArray[pInfo->nBands - 1]);
		return ((m_Src.ReadLineBIL(pInfo->eCellType, pInfo->nBands-1, ppInputArray) == NCS_READ_OK) ? NCS_SUCCESS : NCS_COULDNT_READ_INPUT_LINE);
	} else {
		// need to read all bands
		return ((m_Src.ReadLineBIL(pInfo->eCellType, pInfo->nBands, ppInputArray) == NCS_READ_OK) ? NCS_SUCCESS : NCS_COULDNT_READ_INPUT_LINE);
	}
}


void CLosslessCompressor::WriteStatus(IEEE4 fPercentComplete, const NCS::CString &sStatusText, const CompressionCounters &Counters){
	fprintf(stdout, "Completed %d%%\t\t\r", (int)(fPercentComplete));
	fflush(stdout);	
}
//Cancel check.  We always return false, but an application with a graphical user interface 
//could have a "Cancel" button that when pressed caused this to return true and halt the 
//compression process.
bool CLosslessCompressor::WriteCancel(void)
{
	// Return true to cancel compression - eg from a GUI cancel button.
	return false;
}

//main() - parse command line parameters, call CLosslessCompressor.Recompress().
extern "C" int main(int argc, char **argv)
{
	// Initialize libraries in case of static linkage
	NCS::CApplication App;

	// Please enter your company's name and key or contact erdasinfo@intergraph.com to obtain a key.
	char *szLicensee = getenv("ECW_Licensee");
	char *szOEMKey = getenv("ECW_Key");
	if(!szLicensee || !szOEMKey) {
		printf("Please enter your company's name and key in sample file: %s(%d).\nOr contact erdasinfo@intergraph.com to obtain a key.", __FILE__, __LINE__);
	} else {
		CNCSFile::SetOEMKey(szLicensee, szOEMKey);
	}

	{
	
		CLosslessCompressor compressor;

		if(argc != 3) {
			fprintf(stdout,"Usage: %s <input file> <output file>\n", argv[0]);
			return(1);
		}

		char *pSrcFile = argv[1];
		char *pDstFile = argv[2];

		CNCSError Error = compressor.Recompress(pSrcFile, pDstFile);

		if(Error != NCS_SUCCESS) {
			fprintf(stderr, "Error: %s", Error.GetErrorMessage().c_str());
			return(1);
		}

	}
	
	return(0);
}
