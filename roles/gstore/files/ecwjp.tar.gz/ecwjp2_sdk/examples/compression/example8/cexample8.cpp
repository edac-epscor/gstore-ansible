/********************************************************** 
** Copyright, 1998 - 2013, Intergraph Corporation. All rights reserved.
**  
** FILE:   	cexample7.cpp
** CREATED:	28th May 2012
** AUTHOR: 	Chris Tapley
**
** PURPOSE:	
**	Compress an ECW file via the Tilebased C++ API and use the NULL region mask
**			
** Note: output file should be the ecw type
*******************************************************/

#include "NCSFile.h"
#include "NCSEcw/SDK/Buffer2D.h"
#include "NCSUtil.h"

/**
 * \class	CTileCompressor
 *
 * \brief	Tile compressor class that handles the WriteReadTile Requests from the ECW compressor.
**/
class CTileCompressor : public NCS::CView
{
public:
	CTileCompressor() : NCS::CView(), m_ValidRegion(200, 200, 800, 800)
	{
		m_fMinValue = (IEEE4)0.0f;
		m_fMaxValue = (IEEE4)255.0f;

		m_BackgroundColours.resize(3);
		m_BackgroundColours[0] = 125.0f;
		m_BackgroundColours[1] = 38.0f;
		m_BackgroundColours[2] = 205.0f;
	};
	virtual ~CTileCompressor() {};

	/**
	 * \fn	NCS::CView::CompressInputType CTileCompressor::GetCompressInputType()
	 *
	 * \brief	Tells the SDK to use the TILE compressor.
	 *
	 * \return	The compress input type.
	**/
	NCS::CView::CompressInputType GetCompressInputType() { 
		return NCS::CView::TILE; 
	};

	/**
	 * \fn	virtual bool CTileCompressor::SetupBackgroundColour(std::vector<IEEE4> &BandColours)
	 *
	 * \brief	Sets up the background colour for NULL regions.
	 *
	 * \param [in,out]	BandColours	List of colours of the bands.
	 *
	 * \return	true if it succeeds, false if it fails.
	**/
	virtual bool SetupBackgroundColour(std::vector<IEEE4> &BandColours) { 
		BandColours[0] = m_BackgroundColours[0];
		BandColours[1] = m_BackgroundColours[1];
		BandColours[2] = m_BackgroundColours[2];
		return true;
	};

	/**
	 * \fn	bool CTileCompressor::WriteReadTile(const NCS::SDK::CRect2D &Tile,
	 * 		SDK::CBuffer2DVector &Buffers, bool &bIsRegionNULL)
	 *
	 * \brief	Returns the imagery data for the region designated by the Tile param.
	 *
	 * \param	Tile				 	The tile.
	 * \param [in,out]	Buffers		 	The buffers.
	 * \param [in,out]	bIsRegionNULL	The is region null.
	 *
	 * \return	true if it succeeds, false if it fails.
	**/
	bool WriteReadTile(const NCS::SDK::CRect2D &Tile, NCS::SDK::CBuffer2DVector &Buffers, bool &bIsRegionNULL)
	{
		IEEE4 *pLine;
		
		// If the Tile param does not intersect the valid region, then this tile is NULL
		NCS::SDK::CRect2D Intersection = Tile & m_ValidRegion;
		if(Intersection.GetX0() >= Intersection.GetX1() ||
		   Intersection.GetY0() >= Intersection.GetY1()) {

			bIsRegionNULL = true;
			return true;
		}

		bIsRegionNULL = false;
		for(INT32 nB = 0; nB < (INT32)Buffers.size(); nB++) {
			
			// if we only need to partially fill this buffer, then
			// prefill the buffer with the background colour
			if(Intersection != (NCS::SDK::CRect2D &)Buffers[0]) {
				Buffers[nB].Set(m_BackgroundColours[nB]);
			}
			
			for(INT32 nY = Intersection.GetY0(); nY < Intersection.GetY1(); nY++) {
				pLine = (IEEE4*)Buffers[nB].GetPtr(Intersection.GetX0(), nY);
				for(INT32 nX = Intersection.GetX0(); nX < Intersection.GetX1(); nX++) {
					//pLine[nX] = (IEEE4)nY;
					//// make a checkerboard effect 
					if(((nX / 30) % 3 == nB) && 
					   ((nY / 30) % 3 == nB)) {
						*pLine = m_fMaxValue;
					} else {
						*pLine = m_fMinValue;
					}
					pLine++;
				}
			}
		}
		return true;
	};
protected:
	IEEE4 m_fMinValue;
	IEEE4 m_fMaxValue;
	NCS::SDK::CRect2D m_ValidRegion;
	std::vector<IEEE4> m_BackgroundColours;
};

int main(int argc, char* argv[])
{
	NCS::CApplication App;

	if(argc < 2) {
		printf("Usage: %s <output filename>\n", argv[0]);
		exit(1);
	}

	NCS::CString sFile = argv[1];
	if(!sFile.EndsWith(NCS_T(".ecw"), true)) {
		printf("Must be an .ecw file.\n\n");
		exit(1);
	}

	// Please enter your company's name and key or contact erdasinfo@intergraph.com to obtain a key.
	char *szLicensee = getenv("ECW_Licensee");
	char *szOEMKey = getenv("ECW_Key");
	if(!szLicensee || !szOEMKey) {
		printf("Please enter your company's name and key in sample file: %s(%d).\nOr contact erdasinfo@intergraph.com to obtain a key.", __FILE__, __LINE__);
		exit(1);
	} else {
		CNCSFile::SetOEMKey(szLicensee, szOEMKey);
	}

	NCS::CString sRAW = NCS_T("RAW");

	CTileCompressor Output;

	NCSFileInfo Info;
	NCSInitFileInfo(&Info);
	Info.eCellSizeUnits = ECW_CELL_UNITS_METERS;
	Info.eCellType = NCSCT_UINT8;
	Info.fCellIncrementX = 1.0;
	Info.fCellIncrementY = 1.0;
	Info.fOriginX = 0.0;
	Info.fOriginY = 0.0;
	Info.nBands = (UINT16)3;
	Info.nCompressionRate = (UINT16)8;
	Info.nSizeX = 1000;
	Info.nSizeY = 1000;
	Info.pBands = NULL;
	Info.szDatum = (char*)sRAW.a_str();
	Info.szProjection = (char*)sRAW.a_str();
	Info.eColorSpace = NCSCS_sRGB;
	Info.fCWRotationDegrees = 0.0;
	Info.nCellBitDepth = 8;
	Info.nFormatVersion = 3; // must be version 3 for NULL blocks to be supported
	Info.pFileMetaData = NULL;

	Output.SetParameter("ECW:BLOCKSIZE:X", (INT32)64);
	Output.SetParameter("ECW:BLOCKSIZE:Y", (INT32)64);
	Output.SetFileInfo(Info);
	NCS::CError Error;

	Error = Output.Open(sFile, false, true);
	if(!Error.Success()) {
		printf("Unable to open output file |: %s.\n\n", NCSGetLastErrorText(Error.GetErrorNumber()));
	}
	Error = Output.Write();
	if(!Error.Success()) {
		printf("Compression failed :: %s", NCSGetLastErrorText(Error.GetErrorNumber()));
	}
	Error = Output.Close();
	if(!Error.Success()) {
		printf("Close failed :: %s", NCSGetLastErrorText(Error.GetErrorNumber()));
	}

	return 0;
}

