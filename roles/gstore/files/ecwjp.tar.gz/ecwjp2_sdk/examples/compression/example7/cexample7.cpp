/********************************************************** 
** Copyright, 1998 - 2013, Intergraph Corporation. All rights reserved.
**  
** FILE:   	example7.cpp
** CREATED:	27th January 2011
** AUTHOR: 	Yakun Wang
**
** PURPOSE: 	
**	Read a view content from an ecw file and write it to the jp2 file with a customised UUID box added.
**	Then read the jp2 file and retrieve the content of the added UUID box
**	
**			
** Note: output file should be the ecw type
*******************************************************/

#include "NCSFile.h"
#include "NCSEcw/JP2/File.h"
#ifdef WIN32
#include <tchar.h>
#else
#define _TCHAR NCSTChar
#endif

using namespace NCS;

//Read the content of ecw and write it to a jp2 file
template <typename T>
void DecompressAndWriteToJP2File(CNCSFile& inputEcwFile, CNCSFile& outputJP2File, UINT32 viewHeight, 
									NCSCellType celltype, UINT32 viewWidth, UINT32 nBands)
{
	T* pData_jp2 = new T[viewWidth * nBands * sizeof(T)];
	std::vector<T*> inputLineVector;
	std::vector<void*> outputLineVector;
	for (UINT32 i = 0; i < nBands; i++)
	{
		inputLineVector.push_back(pData_jp2 + i * viewWidth * sizeof(T));
		outputLineVector.push_back(pData_jp2 + i * viewWidth * sizeof(T));
	}

	for(UINT32 line = 0; line < viewHeight; line++ ) 
	{
		NCSReadStatus readStatus = inputEcwFile.ReadLineBIL( &inputLineVector[0] );

		if (readStatus != NCS_READ_OK)
		{
			printf("Reading error at line %s\n", line);
			break;
		}

		void* outputLine = pData_jp2;

		outputJP2File.WriteLineBIL(celltype, nBands, &outputLineVector[0] );

	}

	delete [] pData_jp2;
}

//Generate a UUID box with user data passed in
std::auto_ptr<JP2::CFile::CUUIDBox> GenerateCustomizedUUIDBox(const char* userData, unsigned int maxDataLength)
{
	//Prepare a UUID box and add it into the output jp2 file
	std::auto_ptr<JP2::CFile::CUUIDBox> pBox(new JP2::CFile::CUUIDBox);
	char* userDataToInsert = new char[maxDataLength];
	strcpy(userDataToInsert, userData);
	pBox->m_pData = userDataToInsert;
	pBox->m_bValid = true;
	pBox->m_nLength = strlen(userDataToInsert) + 1;
	for(UINT8 nI = 0; nI < 16; nI++) {
		pBox->m_UUID.m_UUID[nI] = nI;
	}
	return pBox;
}


int main(int argc, char* argv[])
{
	NCS::CApplication App;

	CNCSFile inputEcwFile;
	CNCSFile outputJP2File; 

	// Check user has specified a file on command line
	if (argc != 3) 
	{
		 printf("Usage: %s <input filename.ecw> <output filename.jp2>\n", argv[0]);
		 exit(1);
	}

	// Please enter your company's name and key or contact erdasinfo@intergraph.com to obtain a key.
	char *szLicensee = getenv("ECW_Licensee");
	char *szOEMKey = getenv("ECW_Key");
	if(!szLicensee || !szOEMKey) 
	{
		printf("Please enter your company's name and key in sample file: %s(%d).\nOr contact erdasinfo@intergraph.com to obtain a key.", __FILE__, __LINE__);
	} 
	else 
	{
		outputJP2File.SetOEMKey(szLicensee, szOEMKey);
	}

	//Open the input ecw file for read and jp2 file for writing
	CError err_ecw = inputEcwFile.Open(argv[1], false, false);
	
	if (!err_ecw.Success())
	{
		printf("Open file error at %s!\n", argv[1]);
		exit(-1);
	}

	NCSFileInfo* pSourceFileInfo = inputEcwFile.GetFileInfo();
	NCSFileInfo compressionFileInfo;
	NCSInitFileInfo(&compressionFileInfo);
	NCSCopyFileInfo(&compressionFileInfo, pSourceFileInfo);
	compressionFileInfo.nFormatVersion = 1;
	compressionFileInfo.pBands = NULL;

	std::vector<UINT32> bandList;
	for (UINT32 i = 0; i < pSourceFileInfo->nBands; i++)
		bandList.push_back(i);

	err_ecw = inputEcwFile.SetView(pSourceFileInfo->nBands, &bandList[0], 0, 0, pSourceFileInfo->nSizeX - 1,
		pSourceFileInfo->nSizeY - 1, pSourceFileInfo->nSizeX, pSourceFileInfo->nSizeY);

	if (!err_ecw.Success())
	{
		printf("Open file error at %s!\n", argv[1]);
		exit(-1);
	}

	outputJP2File.SetFileInfo(compressionFileInfo);
	outputJP2File.SetParameter(CNCSFile::JP2_GEODATA_USAGE, JP2_GEODATA_USE_PCS_ONLY);

	//Generate a uuid box which contains user's data
	std::auto_ptr<JP2::CFile::CUUIDBox> uuidBoxPtr = GenerateCustomizedUUIDBox("This is user data!", 256);
	CError err_jp2 = outputJP2File.AddBox(uuidBoxPtr.get());

	err_jp2 = outputJP2File.Open(argv[2], false, true);

	if (!err_jp2.Success())
	{
		printf("Open file error!\n", argv[0]);
		exit(-1);
	}
	
	//Allocate a bil buffer to read from the ecw file and write to the jp2 file
	if( err_jp2.Success())
	{
		switch (pSourceFileInfo->eCellType)
		{
		case NCSCT_UINT8:
			DecompressAndWriteToJP2File<UINT8>(inputEcwFile, outputJP2File, pSourceFileInfo->nSizeY, 
				pSourceFileInfo->eCellType, pSourceFileInfo->nSizeX, pSourceFileInfo->nBands);
			break;
		case NCSCT_UINT16:
			DecompressAndWriteToJP2File<UINT16>(inputEcwFile, outputJP2File, pSourceFileInfo->nSizeY, 
				pSourceFileInfo->eCellType, pSourceFileInfo->nSizeX, pSourceFileInfo->nBands);
			break;
		default:
			printf("Not supported type for jp2!\n");
			break;
		}
	}
	
	inputEcwFile.Close(true);
	outputJP2File.Close(true);

	//Reopen the new created jp2 file, retrieve the data from the added box and show the data on the console
	err_jp2 = outputJP2File.Open(argv[2], false, false);
	if(!err_jp2.Success()) {
		printf("Unable to open output file.");
		exit(1);
	}
	UINT8 nTypeChars[4] = {'u','u','i','d'};
	UINT32 nTBox = *((UINT32 *)nTypeChars);
	JP2::CFile::CUUIDBox* pBox = (JP2::CFile::CUUIDBox*)outputJP2File.GetUUIDBox(uuidBoxPtr->m_UUID);
	if(!pBox || !pBox->m_pData) {
		printf("Unable to retrieve custom data from output file.");
		exit(1);
	}
	char* restoredUserData = (char*)pBox->m_pData;

	printf("The customized data is %s", restoredUserData);

	outputJP2File.Close();

	return 0;
}

