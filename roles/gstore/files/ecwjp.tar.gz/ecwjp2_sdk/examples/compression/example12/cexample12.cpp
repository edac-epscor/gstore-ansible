/********************************************************** 
** Copyright, 1998 - 2013, Intergraph Corporation. All rights reserved.
**  
** FILE:   	cexample12.cpp
** CREATED:	28th May 2012
** AUTHOR: 	Chris Tapley
**
** PURPOSE:	
**	1. Compress an ECW file with custom boxes 
**			
** Note: output file should be the ecw type
*******************************************************/

#include "NCSFile.h"
#include "NCSEcw/SDK/Buffer2D.h"
#include "NCSUtil.h"
#include "NCSEcw/API/HeaderEditor.h"

#include "NCSEcw/ECW/File.h"

using namespace NCS;

/**
 * \class	CTileCompressor
 *
 * \brief	Tile compressor class that handles the WriteReadTile Requests from the ECW compressor.
**/
class CTileCompressor : public NCS::CView
{
public:
	CTileCompressor() : NCS::CView()
	{
		m_fMinValue = (IEEE4)0.0f;
		m_fMaxValue = (IEEE4)255.0f;
	};
	virtual ~CTileCompressor() {};

	/**
	 * \fn	NCS::CView::CompressInputType CTileCompressor::GetCompressInputType()
	 *
	 * \brief	Tells the SDK to use the TILE compressor.
	 *
	 * \return	The compress input type.
	**/
	NCS::CView::CompressInputType GetCompressInputType() { 
		return NCS::CView::TILE; 
	};

	/**
	 * \fn	bool CTileCompressor::WriteReadTile(const NCS::SDK::CRect2D &Tile,
	 * 		SDK::CBuffer2DVector &Buffers, bool &bIsRegionNULL)
	 *
	 * \brief	Returns the imagery data for the region designated by the Tile param.
	 *
	 * \param	Tile				 	The tile.
	 * \param [in,out]	Buffers		 	The buffers.
	 * \param [in,out]	bIsRegionNULL	The is region null.
	 *
	 * \return	true if it succeeds, false if it fails.
	**/
	bool WriteReadTile(const NCS::SDK::CRect2D &Tile, NCS::SDK::CBuffer2DVector &Buffers, bool &bIsRegionNULL)
	{
		IEEE4 *pLine;
		
		bIsRegionNULL = false;
		for(INT32 nB = 0; nB < (INT32)Buffers.size(); nB++) {
			
			for(INT32 nY = Tile.GetY0(); nY < Tile.GetY1(); nY++) {
				pLine = (IEEE4*)Buffers[nB].GetPtr(Tile.GetX0(), nY);
				for(INT32 nX = Tile.GetX0(); nX < Tile.GetX1(); nX++) {
					//pLine[nX] = (IEEE4)nY;
					//// make a checkerboard effect 
					if(((nX / 30) % 3 == nB) && 
					   ((nY / 30) % 3 == nB)) {
						*pLine = m_fMaxValue;
					} else {
						*pLine = m_fMinValue;
					}
					pLine++;
				}
			}
		}
		return true;
	};
protected:
	IEEE4 m_fMinValue;
	IEEE4 m_fMaxValue;
};

/**
 * \class	CCustomBox
 *
 * \brief	Custom box for embedding custom data in an ECW file.  This is a simple example it would be better to use the 
 * 			NCS::JP2::CFile::CUUIDBox for embedding custom data because it has a 16byte unique identifier to better distinguish
 * 			custom boxes
**/
class CCustomBox : public NCS::SDK::CBox {
public:
	void *m_pData;
	UINT32 m_nLength;

	static UINT32 s_BoxID;

	CCustomBox() {
		m_nTBox = s_BoxID; // Custom box identifier
		m_pData = NULL;
		m_nLength = 0;
	}

	CCustomBox(const CCustomBox &s) {
		*this = s;
	}
	const CCustomBox &operator=(const CCustomBox &s) {
		(NCS::SDK::CBox &)*this = (const NCS::SDK::CBox &)s; // Must do this

		m_nLength = s.m_nLength;
		m_pData = NULL;
		if(m_nLength > 0) {
			m_pData = NCSMalloc(m_nLength, FALSE);
			memcpy(m_pData, s.m_pData, m_nLength);
		}
		return *this;
	}
	virtual ~CCustomBox() {
		if(m_pData) {
			NCSFree(m_pData);
		}
	}

	NCS::CError Parse(NCS::SDK::CFileBase &FileBase, CIOStream &Stream) {
		NCS::CError Error;

		NCSJP2_CHECKIO_BEGIN(Error, Stream);
			m_nLength = (INT32)(m_nLDBox);
			m_pData = new UINT8[m_nLength];
			NCSJP2_CHECKIO(Read(m_pData, m_nLength));
		NCSJP2_CHECKIO_END();
		return(Error);
	}

	CError UnParse(NCS::SDK::CFileBase &FileBase, CIOStream &Stream)
	{
		CError Error;

		m_nLDBox = m_nLength;
		m_nXLBox = 8 + m_nLDBox;

		Error = CBox::UnParse(FileBase, Stream);
		NCSJP2_CHECKIO_BEGIN(Error, Stream);
			if(m_pData && m_nLength > 0) {
				NCSJP2_CHECKIO(Write(m_pData, (UINT32)m_nLength));
			}
		NCSJP2_CHECKIO_END();
		return(Error);
	}
};

UINT32 CCustomBox::s_BoxID = 'cust';


int main(int argc, char* argv[])
{
	NCS::CApplication App;

	if(argc < 2) {
		printf("Usage: %s <output filename.ecw>\n", argv[0]);
		exit(1);
	}

	NCS::CString sFile = argv[1];
	if(!sFile.EndsWith(NCS_T(".ecw"), true)) {
		printf("Must be an .ecw file.\n\n");
		exit(1);
	}

	// Please enter your company's name and key or contact erdasinfo@intergraph.com to obtain a key.
	char *szLicensee = getenv("ECW_Licensee");
	char *szOEMKey = getenv("ECW_Key");
	if(!szLicensee || !szOEMKey) {
		printf("Please enter your company's name and key in sample file: %s(%d).\nOr contact erdasinfo@intergraph.com to obtain a key.", __FILE__, __LINE__);
		exit(1);
	} else {
		CNCSFile::SetOEMKey(szLicensee, szOEMKey);
	}

	NCS::CString sRAW = NCS_T("RAW");

	CTileCompressor Output;

	NCSFileInfo Info;
	NCSInitFileInfo(&Info);
	Info.eCellSizeUnits = ECW_CELL_UNITS_METERS;
	Info.eCellType = NCSCT_UINT8;
	Info.fCellIncrementX = 1.0;
	Info.fCellIncrementY = 1.0;
	Info.fOriginX = 0.0;
	Info.fOriginY = 0.0;
	Info.nBands = (UINT16)3;
	Info.nCompressionRate = (UINT16)8;
	Info.nSizeX = 1000;
	Info.nSizeY = 1000;
	Info.pBands = NULL;
	Info.szDatum = (char*)sRAW.a_str();
	Info.szProjection = (char*)sRAW.a_str();
	Info.eColorSpace = NCSCS_sRGB;
	Info.fCWRotationDegrees = 0.0;
	Info.nCellBitDepth = 8;
	Info.nFormatVersion = 3; // must be version 3 for custom boxes
	
	Output.SetParameter("ECW:BLOCKSIZE:X", (INT32)64);
	Output.SetParameter("ECW:BLOCKSIZE:Y", (INT32)64);
	Output.SetParameter("ECW:HUFFMANEDCODE:FLAG", (INT32)1);
	NCS::CError Error;
	
	Error = Output.SetFileInfo(Info);

	if(!Error.Success()) {
		printf("Unable to set file info |: %s.\n\n", NCSGetLastErrorText(Error.GetErrorNumber()));
		exit(1);
	}

	// Boxes must be set before Open
	CCustomBox *pCustomBox = new CCustomBox();
	std::string sV;
	std::cout << "\r\nEnter custom data: ";
	std::cin >> sV;

	pCustomBox->m_nLength = sV.length()+1;
	pCustomBox->m_pData = NCSMalloc(pCustomBox->m_nLength, TRUE);
	strcpy((char*)pCustomBox->m_pData, sV.c_str());
	pCustomBox->m_bValid = true;
	
	Output.AddBox(pCustomBox);
		
	Error = Output.Open(sFile, false, true);
	if(!Error.Success()) {
		printf("Unable to open output file |: %s.\n\n", NCSGetLastErrorText(Error.GetErrorNumber()));
		exit(1);
	}
	Error = Output.Write();
	if(!Error.Success()) {
		printf("Compression failed :: %s", NCSGetLastErrorText(Error.GetErrorNumber()));
		exit(1);
	}
	Error = Output.Close();
	if(!Error.Success()) {
		printf("Close failed :: %s", NCSGetLastErrorText(Error.GetErrorNumber()));
		exit(1);
	}
	

	// Make sure the box exists in the new ECW file
	NCS::CView File;

	Error = File.Open(sFile, false, false);
	if(!Error.Success()) {
		printf("Unable to open new ecw file |: %s.\n\n", NCSGetLastErrorText(Error.GetErrorNumber()));
		exit(1);
	}

	NCS::SDK::CBox *pBox = File.GetBox(CCustomBox::s_BoxID);
	if(!pBox) {
		printf("Unable to get custom box from ecw file.\n\n");
		exit(1);
	}
	CCustomBox CustomBox;
	(NCS::SDK::CBox &)CustomBox = *pBox;
	NCS::CIOStream &Stream = *(File.GetFile()->m_pStream);
	Stream.Seek(CustomBox.m_nDBoxOffset, NCS::CIOStream::START); // must seek to start of box data
	Error = CustomBox.Parse(*(File.GetFile()), Stream);
	if(!Error.Success() || CustomBox.m_pData == NULL) {
		printf("Unable to parse custom box |: %s.\n\n", NCSGetLastErrorText(Error.GetErrorNumber()));
		exit(1);
	}
	std::cout << "\r\n\r\nCustom box data from output file: " << (char*)CustomBox.m_pData << std::endl;


	File.Close(true);
	
	return 0;
}

