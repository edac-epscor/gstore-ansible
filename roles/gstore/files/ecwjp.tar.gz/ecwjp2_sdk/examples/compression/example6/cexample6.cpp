/********************************************************** 
** Copyright, 1998 - 2013, Intergraph Corporation. All rights reserved.
**  
** FILE:   	example6.cpp
** CREATED:	19th January 2011
** AUTHOR: 	Yakun Wang
**
** PURPOSE:	
**	1. Reading an view content into a RGB buffer using ReadLineRGB(...)
**	2. Rearrange the RGB buffer into a BIL buffer
**  3. Write the BIL buffer to a compressed file using WriteLineBIL
**			
** Note: output file should be the ecw type
*******************************************************/

#include "NCSFile.h"

using namespace NCS;

const UINT32 MAXVIEW_WINDOWSIZE = 384;
#define RAND() ((double) rand() / (double) RAND_MAX)

//View size infomation
struct ViewSizeInfo
{
	UINT32 StartX;
	UINT32 StartY;
	UINT32 EndX;
	UINT32 EndY;
};

/*
	Randomly work out a view region based on input width and height of the image
*/
ViewSizeInfo GennerateViewRegion(UINT32 imgWidth, UINT32 imgHeight)
{	
	ViewSizeInfo viewSizeInfo;

	/* initialize random seed: */
	srand ((unsigned int)time(NULL) );

	// define a random region and size
	viewSizeInfo.StartX = (UINT32) (RAND() * imgWidth);
	viewSizeInfo.EndX	= (UINT32) (RAND() * (imgWidth - viewSizeInfo.StartX)) + viewSizeInfo.StartX;
	viewSizeInfo.StartY = (UINT32) (RAND() * imgHeight);
	viewSizeInfo.EndY	= (UINT32) (RAND() * (imgHeight - viewSizeInfo.StartX)) + viewSizeInfo.StartY;

	// make a square view area
	if( (viewSizeInfo.EndX - viewSizeInfo.StartX) < MAXVIEW_WINDOWSIZE ) {
		viewSizeInfo.EndX = viewSizeInfo.StartX + MAXVIEW_WINDOWSIZE;
		if( viewSizeInfo.EndX >= imgWidth ) { 
			viewSizeInfo.StartX = imgWidth - MAXVIEW_WINDOWSIZE;
			viewSizeInfo.EndX = imgWidth - 1;
		}
	}
	if( (viewSizeInfo.EndY - viewSizeInfo.StartY) < MAXVIEW_WINDOWSIZE ) {
		viewSizeInfo.EndY = viewSizeInfo.StartY + MAXVIEW_WINDOWSIZE;
		if( viewSizeInfo.EndY >= imgHeight ) { 
			viewSizeInfo.StartY = imgHeight - MAXVIEW_WINDOWSIZE;
			viewSizeInfo.EndY = imgHeight - 1;
		}
	}
	if( (viewSizeInfo.EndX - viewSizeInfo.StartX) < (viewSizeInfo.EndY - viewSizeInfo.StartY) )
		viewSizeInfo.EndY = viewSizeInfo.StartY + (viewSizeInfo.EndX - viewSizeInfo.StartX);
	else
		viewSizeInfo.EndX = viewSizeInfo.StartX + (viewSizeInfo.EndY - viewSizeInfo.StartY);

	return viewSizeInfo;
};

/* 
	Set file information for the compression file
*/
void SetCompressionFileInfo(NCSFileInfo& dstFileInfo, const ViewSizeInfo& viewSizeInfo, 
					 UINT32 numberOfAllocatedBands, const NCSFileInfo& srcFileInfo)
{
	dstFileInfo.eCellSizeUnits = srcFileInfo.eCellSizeUnits;
	dstFileInfo.eCellType = NCSCT_UINT8;
	dstFileInfo.fCellIncrementX =  srcFileInfo.fCellIncrementX;
	dstFileInfo.fCellIncrementY =  srcFileInfo.fCellIncrementY;
	dstFileInfo.fOriginX =  srcFileInfo.fOriginX;
	dstFileInfo.fOriginY =  srcFileInfo.fOriginY;
	dstFileInfo.nBands = numberOfAllocatedBands;
	dstFileInfo.nCompressionRate = srcFileInfo.nCompressionRate;
	dstFileInfo.nSizeX = viewSizeInfo.EndX - viewSizeInfo.StartX + 1;
	dstFileInfo.nSizeY = viewSizeInfo.EndY - viewSizeInfo.StartY + 1;
	dstFileInfo.pBands = NULL;
	dstFileInfo.szDatum = srcFileInfo.szDatum;
	dstFileInfo.szProjection = srcFileInfo.szProjection;
	dstFileInfo.eColorSpace = NCSCS_sRGB;
}

int main(int argc, char* argv[])
{
	NCS::CApplication App;

	CNCSFile inputImageFile;
	CNCSFile outputImageFile; 

	// Check user has specified a file on command line
	if (argc != 3) 
	{
		 printf("Usage: %s <input filename.ecw> <output filename.ecw> \n", argv[0]);
		 exit(1);
	}

	// Please enter your company's name and key or contact erdasinfo@intergraph.com to obtain a key.
	char *szLicensee = getenv("ECW_Licensee");
	char *szOEMKey = getenv("ECW_Key");
	if(!szLicensee || !szOEMKey) 
	{
		printf("Please enter your company's name and key in sample file: %s(%d).\nOr contact erdasinfo@intergraph.com to obtain a key.", __FILE__, __LINE__);
	} 
	else 
	{
		outputImageFile.SetOEMKey(szLicensee, szOEMKey);
	}

	CError fileOpenErr = inputImageFile.Open(argv[1], false, false);

	// Check if the extension name of output file is ecw 
	CString outputFileName(argv[2]);
	CString::size_type startOfExtensionName = outputFileName.find_last_of(L".ecw");
	if ((startOfExtensionName != std::wstring::npos) && (outputFileName.size() -  startOfExtensionName != 1))
	{
		printf("Output image should be ecw type!");
		exit(1);
	}

	if (!fileOpenErr.Success())
	{
		printf("File: {%s} open error: %ls\n ", argv[1], fileOpenErr.GetErrorMessage().c_str());
		return -1;
	}

	NCSFileInfo* pSourceFileInfo = inputImageFile.GetFileInfo();

	//Prepare the parameters to set view such as band and viewSizeInfo
	
	//always allocate three bands as we need to call ReadLineRGB
	UINT32 numberOfAllocatedBands = 3; 
	//numberOfViewBands is for setting a view
	UINT32 numberOfViewBands = pSourceFileInfo->nBands > 3 ? 3 : pSourceFileInfo->nBands;
	std::vector<UINT32> bandList;
	for (UINT32 i = 0; i < numberOfViewBands; i++)
		bandList.push_back(i);

	//work out a view region based on input width and height of the image
	ViewSizeInfo viewSizeInfo = GennerateViewRegion(pSourceFileInfo->nSizeX, pSourceFileInfo->nSizeY);
	UINT32 viewHeight = viewSizeInfo.EndY - viewSizeInfo.StartY + 1;
	UINT32 viewWidth = viewSizeInfo.EndX - viewSizeInfo.StartX + 1;

	inputImageFile.SetView(numberOfViewBands, &bandList[0], viewSizeInfo.StartX, viewSizeInfo.StartY, 
		viewSizeInfo.EndX, viewSizeInfo.EndY, viewWidth, viewHeight);

	//Allocate buffers for reading and writing
	UINT8* pRGBLineBuffer = new UINT8[viewWidth * numberOfAllocatedBands];
	UINT8* pBILLineBuffer = new UINT8[viewWidth * numberOfAllocatedBands];
	std::vector<UINT8*> bilBandIndexVector;
	std::vector<void*> outputLineVector;
	for (UINT32 i = 0; i < numberOfAllocatedBands; i++)
	{
		bilBandIndexVector.push_back(pBILLineBuffer + viewWidth * i);
		outputLineVector.push_back(bilBandIndexVector[i]);
	}

	NCSFileInfo compressionFileInfo;
	NCSInitFileInfo(&compressionFileInfo);

	SetCompressionFileInfo(compressionFileInfo, viewSizeInfo, numberOfAllocatedBands, *pSourceFileInfo);
	outputImageFile.SetFileInfo(compressionFileInfo);
	fileOpenErr = outputImageFile.Open(argv[2], false, true);

	if (!fileOpenErr.Success())
	{
		printf("File: {%s} open error: %ls\n ", argv[2], fileOpenErr.GetErrorMessage().c_str());
		return -1;
	}

	for (UINT32 i = 0; i < viewHeight; i++)
	{
		NCSReadStatus readingStatus = inputImageFile.ReadLineRGB(pRGBLineBuffer);
		
		if (readingStatus != NCS_READ_OK)
		{
			printf("Reading error !\n");
			break;
		}

		//Rearrange rgb buffer from reading into bil buffer
		for (UINT32 j = 0; j < viewWidth; j++)
		{
			for (UINT32 n = 0; n < numberOfAllocatedBands; n++)
			{
				*bilBandIndexVector[n] = *(pRGBLineBuffer + j * numberOfAllocatedBands + n);
				bilBandIndexVector[n]++;
			}
		}
		
		//Restore the bilIndexVector to the initial position
		for (UINT32 n = 0; n < numberOfAllocatedBands; n++)
		{
			bilBandIndexVector[n] = pBILLineBuffer + viewWidth * n;
		}
	
		//Write the BIL buffer, the SDK will compress it immediately
		CError writingErr = outputImageFile.WriteLineBIL(NCSCT_UINT8, numberOfAllocatedBands, &outputLineVector[0]);

		if (!writingErr.Success())
		{
			printf("Writing error !\n");
			break;
		}
	}

	delete []pRGBLineBuffer;
	delete []pBILLineBuffer;

	inputImageFile.Close();
	outputImageFile.Close();

	return 0;
}

