/********************************************************** 
** Copyright, 1998 - 2013, Intergraph Corporation. All rights reserved.
**  
** FILE:   	cexample11.c
** CREATED:	29th August 2012
** AUTHOR: 	Yakun Wang
**
** PURPOSE:	
**	1. Compress an ECW file with setting geotiff key/tags using C API functions
**  2. Retrieve the data from the file using C API functions and print them.
**			
** Note: output file should be the ecw type
*******************************************************/

#include "NCSECWClient.h"
#include "NCSUtil.h"
#include "NCSErrors.h"
#include "NCSECWCompressClient.h"
#include "NCSEcw/GTIF/geokeys.h"
#include "NCSEcw/GTIF/geovalues.h"
#include "NCSEcw/GTIF/geo_public_defs.h"
#include <time.h>


/*
** Read callback function - called once for each input line
*/
BOOLEAN ReadCallback(NCSCompressClient *pClient, UINT32 nNextLine, IEEE4 **ppInputArray)
{
	float fMin, fMax;
	UINT32 nBand;

	switch(pClient->nCellBitDepth) {
		case 8:
		default:
			fMin = 0.0f;
			fMax = 255.0f;
			break;
		case 16:
			fMin = 0.0f;
			fMax = 65535.0f;
			break;
		case 28:
			fMin = 0.0f;
			fMax = (float)0x0fffffff;
			break;
	}

	for(nBand = 0; nBand < pClient->nInputBands; nBand++) {
		UINT32 nCell;
		IEEE4 *pLine = ppInputArray[nBand];

		if(pClient->nInputBands == 1) {
			/* 1 band, do a grid pattern */
			for(nCell = 0; nCell < pClient->nInOutSizeX; nCell++) {
				if(((nCell / 30) % 2 == nBand) || ((nNextLine / 30) % 2 == nBand)) {
					pLine[nCell] = fMax;
				} else {
					pLine[nCell] = fMin;
				}
			}
		} else {
			if (pClient->nInputBands == 4 && nBand == 3) {
				for(nCell = 0; nCell < pClient->nInOutSizeX; nCell++) {
					// make a opacity box in the middle
					if (nCell > 125 &&
						nCell < 350 &&
						nNextLine > 80 &&
						nNextLine < 300) {
						pLine[nCell] = 0.0f;
					} else {
						pLine[nCell] = 255.0f;
					}
				}
			} else {
				for(nCell = 0; nCell < pClient->nInOutSizeX; nCell++) {
					// make a checkerboard effect 
					if(((nCell / 30) % 3 == nBand) && 
					   ((nNextLine / 30) % 3 == nBand)) {
						pLine[nCell] = fMax;
					} else {
						pLine[nCell] = fMin;
					}
				}
			}
		}
	}
	return(TRUE);	
}

/*
** Status callback function (OPTIONAL)
*/
void StatusCallback(NCSCompressClient *pClient,
						   UINT32 nCurrentLine)
{
}

/*
** Cancel callback function (OPTIONAL)
*/
BOOLEAN CancelCallback(NCSCompressClient *pClient)
{
	/* Return TRUE to cancel compression */
	return(FALSE);
}


void PrintGeotiffKeyTags(char* fileName)
{
	NCSFileView* pFileViewRead = NULL;
	NCSGeoKeyEntry* pGeoKeyEntry = NULL;
	UINT32 count = 0;
	unsigned short shortValue;
	IEEE8 doubleValue;
	char stringValue[512];
	int transformationMatrixCount;
	IEEE8* pTransformationMatrix = NULL;
	UINT32 i;

	if (NCSOpenFileViewA(fileName, &pFileViewRead, NULL) != NCS_SUCCESS)
	{
		printf("Unable to open file: %hs\n", fileName);
	}

	NCSGetAllGeotiffKeyEntries(pFileViewRead, &pGeoKeyEntry, &count);
	if (count > 0)
		printf("The file %hs has %d geotiff keys stored. They are: \n", fileName, count);
	else
		printf("The file %hs has no geotiff key stored. \n", fileName);
	for(i = 0; i < count; i++)
	{
		switch(pGeoKeyEntry[i].keyType)
		{
		case TYPE_SHORT:
			NCSGetGeotiffKey(pFileViewRead, pGeoKeyEntry[i].keyId, &shortValue, 0, 1); 
			printf("%s : %d\n", NCS_GTIFKeyName(pGeoKeyEntry[i].keyId), shortValue);
			break;
		case TYPE_DOUBLE:
			NCSGetGeotiffKey(pFileViewRead, pGeoKeyEntry[i].keyId, &doubleValue, 0, 1);
			printf("%s : %lf\n", NCS_GTIFKeyName(pGeoKeyEntry[i].keyId), doubleValue);
			break;
		case TYPE_ASCII:
			NCSGetGeotiffKey(pFileViewRead, pGeoKeyEntry[i].keyId, stringValue, 0, pGeoKeyEntry[i].valCount); 
			printf("%s : %s\n", NCS_GTIFKeyName(pGeoKeyEntry[i].keyId), stringValue);
			break;
		default:
			printf("Stored geotiff key type is incorrect!\n");
			break;
		}
	}

	if (NCSGetGeotiffTag(pFileViewRead, GTIFF_TRANSMATRIX, &transformationMatrixCount, &pTransformationMatrix) == NCS_SUCCESS)
	{
		printf("The file %hs has transformation matrix tag, the value is : ", fileName);
		for (i = 0; i < transformationMatrixCount; i++)
		{
			printf("%lf, ", pTransformationMatrix[i]);
		}
		printf("\n");
	}
	
	NCSFree(pGeoKeyEntry);

	NCSFree(pTransformationMatrix);

	NCSCloseFileViewEx(pFileViewRead,TRUE);
}

void GetETCPath(char *szPath, int nSize)
{
	char *pSZ;
#if defined(WIN32)
	HMODULE hMod = GetModuleHandle(NULL);
	GetModuleFileNameA(hMod, szPath, nSize);
	
	pSZ = szPath + (strlen(szPath)-1);
	while(*pSZ != '\\' && pSZ >= szPath) {
		pSZ--;
	}
	*pSZ = '\0';
	strcat_s(szPath, 1024, "\\..\\..\\..\\etc");
#elif defined(POSIX)
	getcwd(szPath, nSize);
	pSZ = szPath + (strlen(szPath)-1);
	while(*pSZ != '/' && pSZ >= szPath) {
		pSZ--;
	}
	*pSZ = '\0';
	strcat(szPath, "/../../etc");
#else
#error Platform not implemented
#endif
}

int main(int argc, char* argv[])
{
	char *szLicensee = NULL;
	char *szOEMKey = NULL;
	NCSCompressClient *pClient = NULL;
	char* extName = NULL;
	char szGdtPath[1024];

	double oriTransformationMatrix[16] = 
			{0.0, 100.0, 0.0, 400000.0,
			100.0, 0.0, 0.0, 500000.0,
			0.0, 0.0, 0.0, 0.0,
			0.0, 0.0, 0.0, 1.0};

	NCSInit();

	GetETCPath(szGdtPath, 1024);
	NCSSetGDTPath(szGdtPath);
	

	if(argc < 2) {
		printf("Usage: %s <output filename.ecw>\n", argv[0]);
		NCSShutdown();
		exit(1);
	}

	extName = argv[1] + strlen(argv[1]) - 4;
	if(strcmp(extName, ".ecw") != 0){
		printf("Must be an .ecw file.\n\n");
		NCSShutdown();
		exit(1);
	}
	
	// Please enter your company's name and key or contact erdasinfo@intergraph.com to obtain a key.
	szLicensee = getenv("ECW_Licensee");
	szOEMKey = getenv("ECW_Key");
	if(!szLicensee || !szOEMKey) {
		printf("Please enter your company's name and key in sample file: %s(%d).\nOr contact erdasinfo@intergraph.com to obtain a key.", __FILE__, __LINE__);
		NCSShutdown();
		exit(1);
	} else {
		NCSCompressSetOEMKey(szLicensee, szOEMKey);
	}

	// Allocate compression client and set fields for compression
	pClient = NCSCompressAllocClientA();
	if (pClient == NULL) {
		printf("Unable to create Compress Client.\n");
		NCSShutdown();
		exit(1);
	}

	pClient->nInputBands = (UINT16)3;  
	pClient->nInOutSizeX = 1000;
	pClient->nInOutSizeY = 1000;
	pClient->eCompressFormat = NCS_COMPRESS_RGB;
	pClient->fTargetCompression = 8.0f;
	strncpy(pClient->uOutputFileName.szOutputFileName, argv[1], MAX_PATH);

	pClient->pReadCallback = ReadCallback;
	pClient->pStatusCallback = StatusCallback;
	pClient->pCancelCallback = CancelCallback;
	pClient->nCellBitDepth = 8;
	pClient->nFormatVersion = 3;
	pClient->pClientData = NULL;
	pClient->pFileMetaData = NULL;

	
	//Open the compression client 
	if (NCSCompressOpen(pClient, FALSE) != NCS_SUCCESS)
	{
		printf("Unable to open the compressor.\n");
		NCSShutdown();
		exit(1);
	}
	
	//Set geotiff key and tags 
	NCSCompressSetGeotiffKey(pClient, GTModelTypeGeoKey, TYPE_SHORT, 1, ModelTypeProjected);
	NCSCompressSetGeotiffKey(pClient, GTRasterTypeGeoKey, TYPE_SHORT, 1, RasterPixelIsArea);
	NCSCompressSetGeotiffKey(pClient, ProjectedCSTypeGeoKey, TYPE_SHORT, 1, PCS_British_National_Grid);
	NCSCompressSetGeotiffKey(pClient, PCSCitationGeoKey, TYPE_ASCII, 1, "British National Grid, Zone NZ");
	NCSCompressSetGeotiffTag(pClient, GTIFF_TRANSMATRIX, 16, oriTransformationMatrix);

	
	//Compress 
	if (NCSCompress(pClient) != NCS_SUCCESS)
	{
		printf("Compression failed.\n");
		NCSShutdown();
		exit(1);
	}
	
	//Close the pClient
	NCSCompressClose(pClient);
	
	PrintGeotiffKeyTags(argv[1]);

	NCSShutdown();
	return 0;
}

