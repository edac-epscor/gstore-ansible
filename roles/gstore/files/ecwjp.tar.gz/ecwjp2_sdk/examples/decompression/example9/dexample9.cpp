/********************************************************** 
** Copyright, 1998 - 2013, Intergraph Corporation. All rights reserved.
**
** FILE:   	dexample9.cpp
** CREATED:	25th June 2012
** AUTHOR: 	Jeremy Jarvis
** PURPOSE: An example on how to use the header editor interface to modify the File Metadata
**********************************************************/

#ifdef WIN32
#include "stdafx.h"
#else
#endif
#include "NCSUtil.h"
#include "NCSEcw/API/HeaderEditor.h"
#include "NCSEcw/API/View.h"

void PrintUsage( char* sFunctionName )
{
		printf("Usage: %s file [-author AUTHOR][-address ADDRESS] [-email EMAIL]\n", sFunctionName);
		printf("      [-company COMPANY] [-copyright COPYRIGHT] [-telephone TELEPHONE]\n\n");
}

/*	 
 *	Parse all Metadata values for the output NCSFileMetaData
 *
 */
bool ParseArgs(int argc, char* argv[], NCSFileMetaData* pFileMetaData ) {
	CNCSString sArg, sValue , sTmpValue;
	bool bValid = true;

	for(int i = 2; i < argc-1 && bValid; i++) {
		sArg = CNCSString(argv[i]);
		char *szArg = (char*)sArg.a_str();
		if(szArg[0] == '-' || szArg[0] == '/') { 
			if(strcmp(szArg, "-author") == 0) {
				if(sizeof(argv[i++]) > 0) {
					if (pFileMetaData->sAuthor)
					{
						NCSFree(pFileMetaData->sAuthor);
					}
					sTmpValue = CNCSString(argv[i+1]);
					pFileMetaData->sAuthor = NCSStrDupT(sTmpValue.c_str());
				} else {
					bValid = false;
				}
			} else if(strcmp(szArg, "-copyright") == 0) {
				if(sizeof(argv[++i]) > 0) {
					if (pFileMetaData->sCopyright)
					{
						NCSFree(pFileMetaData->sCopyright);
					}
					sTmpValue = CNCSString(argv[i+1]);
					pFileMetaData->sCopyright = NCSStrDupT(sTmpValue.c_str());
				} else {
					bValid = false;
				}
			} else if(strcmp(szArg, "-company") == 0) {
				if(sizeof(argv[++i]) > 0) {
					if (pFileMetaData->sCompany)
					{
						NCSFree(pFileMetaData->sCompany);
					}
					sTmpValue = CNCSString(argv[i+1]);
					pFileMetaData->sCompany = NCSStrDupT(sTmpValue.c_str());
				} else {
					bValid = false;
				}
			} else if(strcmp(szArg, "-email") == 0) {
				if(sizeof(argv[++i]) > 0) {
					if (pFileMetaData->sEmail)
					{
						NCSFree(pFileMetaData->sEmail);
					}
					sTmpValue = CNCSString(argv[i+1]);
					pFileMetaData->sEmail = NCSStrDupT(sTmpValue.c_str());
				} else {
					bValid = false;
				}
			} else if(strcmp(szArg, "-address") == 0) {
				if(sizeof(argv[++i]) > 0) {
					if (pFileMetaData->sAddress)
					{
						NCSFree(pFileMetaData->sAddress);
					}
					sTmpValue = CNCSString(argv[i+1]);
					pFileMetaData->sAddress = NCSStrDupT(sTmpValue.c_str());
				} else {
					bValid = false;
				}
			} else if(strcmp(szArg, "-telephone") == 0) {
				if(sizeof(argv[++i]) > 0) {
					if (pFileMetaData->sTelephone)
					{
						NCSFree(pFileMetaData->sTelephone);
					}
					sTmpValue = CNCSString(argv[i+1]);
					pFileMetaData->sTelephone = NCSStrDupT(sTmpValue.c_str());
				} else {
					bValid = false;
				}
			}			
		}
	}
	return bValid;
}

void PrintComparison(NCSFileMetaData *pOld, NCSFileMetaData *pNew)
{
	if (pOld)
	{
		printf("ORIGINAL Metadata: \n\n");
		printf("Classification:\t\t%ls\n", pOld->sClassification);
		printf("Acquisition Date:\t%ls\n", pOld->sAcquisitionDate);
		printf("Sensor Name:\t\t%ls\n", pOld->sAcquisitionSensorName);
		printf("Compression Software:\t%ls\n", pOld->sCompressionSoftware); 
		printf("Author:\t\t\t%ls\n", pOld->sAuthor);
		printf("Copyright:\t\t%ls\n", pOld->sCopyright); 
		printf("Company:\t\t%ls\n", pOld->sCompany);
		printf("Email:\t\t\t%ls\n", pOld->sEmail);
		printf("Address:\t\t%ls\n", pOld->sAddress);
		printf("Telephone:\t\t%ls\n", pOld->sTelephone);
		printf("\n");
	}
	else
	{
		printf("Original file has no Metadata. \n");
	}

	printf("\nUPDATED Metadata: \n\n");
	if (pNew)
	{
		printf("Classification:\t\t%ls\n", pNew->sClassification);
		printf("Acquisition Date:\t%ls\n", pNew->sAcquisitionDate);
		printf("Sensor Name:\t\t%ls\n", pNew->sAcquisitionSensorName);
		printf("Compression Software:\t%ls\n", pNew->sCompressionSoftware); 
		printf("Author:\t\t\t%ls\n", pNew->sAuthor);
		printf("Copyright:\t\t%ls\n", pNew->sCopyright); 
		printf("Company:\t\t%ls\n", pNew->sCompany);
		printf("Email:\t\t\t%ls\n", pNew->sEmail);
		printf("Address:\t\t%ls\n", pNew->sAddress);
		printf("Telephone:\t\t%ls\n", pNew->sTelephone);
	}
	else
	{
		printf("\tMetadata is not set\n");
	}
	printf("\n\n");
}

int main(int argc, char* argv[])
{
	CNCSError Error;
	NCSTChar* wFileName = NULL;

	if(argc < 4) {
		PrintUsage(argv[0]);
		exit(1);
	}
	
	NCS::CApplication App;

	NCSUtf8Decode(argv[1], &wFileName);
	NCS::CHeaderEditor HeaderEditor;
	
	if((Error = HeaderEditor.OpenFile(wFileName)) != NCS_SUCCESS) {
		printf("Failed to open the file.\n\n%s\n\n", NCSGetLastErrorText(Error));
		exit(1);
	}
	
	NCSFileMetaData *pOriginalFileMetaData = NULL;
	NCSFileMetaData *pFileMetaDataForEditing = NULL;
	const NCSFileMetaData *pSourceMetaData = HeaderEditor.GetFileMetaData();
	if(!pSourceMetaData) {
		NCSFileMetaData *pNewMetaData = NULL;
		NCSInitMetaData(&pNewMetaData);
		pSourceMetaData = pNewMetaData; // leaks
	}
	NCSCopyMetaData(&pOriginalFileMetaData, pSourceMetaData);
	NCSCopyMetaData(&pFileMetaDataForEditing, pSourceMetaData);

	if(ParseArgs(argc, argv, pFileMetaDataForEditing) ) {
		if((Error = HeaderEditor.SetFileMetaData(pFileMetaDataForEditing)) != NCS_SUCCESS) {
			printf("%s\n\n", NCSGetLastErrorText(Error));		
			exit(1);
		}
	} else {
		printf("Invalid argument.\n\n");
		exit(1);
	}

	//flush the setting and close the headereditor
	HeaderEditor.FlushAll();
	HeaderEditor.Close();

	printf("Operation Completed Successfully.\n\n");

	PrintComparison(pOriginalFileMetaData, pFileMetaDataForEditing);
	NCSFreeMetaData(pFileMetaDataForEditing);
	NCSFreeMetaData(pOriginalFileMetaData);
	NCSFree(wFileName);
	return 0;
}

