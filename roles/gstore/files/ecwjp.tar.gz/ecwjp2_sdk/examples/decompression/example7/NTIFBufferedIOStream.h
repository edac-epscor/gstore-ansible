
#include "NCSBufferedIOStream.h"

using namespace NCS;

class NTIFBufferedIOStream : public CBufferedIOStream
{
public:

	NTIFBufferedIOStream(const CString& fileName, INT64 imageDataOffset, INT64 imageDataLength = -1)
		:m_imageDataOffset(imageDataOffset), m_imageDataLength(imageDataLength), m_fileName(fileName)
	{
		//Use the base class CBufferedIOStream to open the file
		CError openingErr = CBufferedIOStream::Open(m_fileName, false);

		if (openingErr)
		{
#ifdef WIN32			
			throw std::exception("Can't open file!");
#elif POSIX
			printf("Error: Can't open file!");
			throw std::exception();
#else
#error not implemented
#endif	
		}

		//Seek the file pointer to the image offset position.
		bool seekErr = CBufferedIOStream::Seek(m_imageDataOffset);	
		if (!seekErr)
		{
			Close();
#ifdef WIN32
			throw std::exception("File access error!");
#elif POSIX
			printf("Error: File access error!");
			throw std::exception();
#else
#error not implemented
#endif		
		}

    }

    virtual ~NTIFBufferedIOStream()
	{
        CBufferedIOStream::Close();
    }

    virtual bool  Seek() 
	{
        return(true);
    }
    
    virtual bool Seek(INT64 offset, Origin origin = CURRENT) 
	{
		INT64 seeked =	CBufferedIOStream::Seek(offset+ m_imageDataOffset, origin);
		if (seeked == -1)
		{
			return (false);
		} 
		else 
		{			
			return(true);
		}
    }


	virtual INT64  Tell() {
		INT64 tell_val = CBufferedIOStream::Tell() - m_imageDataOffset;
		return tell_val;
    }

	virtual NTIFBufferedIOStream *Clone() {
		NTIFBufferedIOStream *pDst = new NTIFBufferedIOStream(m_fileName, m_imageDataOffset, m_imageDataLength);
		return pDst;
	}
	
	virtual INT64  Size() {
        if( m_imageDataLength != -1 )
            return m_imageDataLength;
        else
        {
            INT64 curPos = Tell(), size;

            Seek( 0, END );
            size = Tell();
            Seek( curPos, START );
            return size;
        }
    }
	private:
		INT64    m_imageDataOffset;
		INT64    m_imageDataLength;
		CString  m_fileName;
};
