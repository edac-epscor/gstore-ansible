/********************************************************** 
** Copyright, 1998 - 2013, Intergraph Corporation. All rights reserved.
**  
** FILE:   	dexample7.cpp
** CREATED:	24th January 2010
** AUTHOR: 	Yakun Wang
**
** PURPOSE: The example works based on a NITF file which embeds a jp2 image. 
**			It creates a subclass of CBufferedIOStream and uses it to open the NITF file 
**			and extract the embedded image to a bil file. 
*******************************************************/

#include "NCSFile.h"
#include "NTIFBufferedIOStream.h"

using namespace NCS;

#define SCALE_TO  512
static UINT32 nQuality = 0;

//Decompress the embedded jp2 file and writ the bil buffer to a file
template <typename T>
void DecompressAndWriteToOutputFile(CNCSFile& embeddedJP2File, const char* outputFileName, UINT32 viewHeight, UINT32 viewWidthByBands)
{
	FILE* outputFp = fopen(outputFileName, "wb+");
	if (fopen == NULL){
		printf("Error openning file %s for write\n", outputFileName);
		return;
	};

	T *pData_jp2 = new T[viewWidthByBands];

	for(UINT32 line = 0; line < viewHeight; line++ ) 
	{
		NCSReadStatus readStatus = embeddedJP2File.ReadLineBIL( &pData_jp2 );

		if (readStatus != NCS_READ_OK)
		{
			printf("Reading error at line %d\n", line);
			break;
		}

		fwrite(pData_jp2, sizeof(T), viewWidthByBands, outputFp);
	}

	fclose(outputFp);
	
	delete [] pData_jp2;
}

int main(int argc, char* argv[])
{
	// Check user has specified a file on command line
	if (argc != 2) 
	{
		printf("Usage: %s <outputfilename.bil filename>\n", argv[0]);
		 exit(-1);
	}

	NCS::CApplication App;
	
	NCSSetConfig( NCSCFG_TEXTURE_DITHER, FALSE );
	CNCSFile embeddedImageFile;

	CString ntffilename = L"../../../testdata/Greyscale2.ntf";
	
	// This offset and length of image is different per nitf file
	INT64    imageDataOffset = 847;
	INT64    imageDataLength = 164426;
	std::auto_ptr<NTIFBufferedIOStream> pNTIFBufferedIOStream(NULL);
	try
	{
		pNTIFBufferedIOStream.reset(new NTIFBufferedIOStream(ntffilename, imageDataOffset, imageDataLength));
	}
	catch (std::exception& ex)
	{
		printf(ex.what());
		exit(-1);
	}

	//Use the buffer io stream to open an image file
	NCS::CError err_jp2 = embeddedImageFile.Open( pNTIFBufferedIOStream.get() );

	if( err_jp2.Success()) 
	{
		embeddedImageFile.SetParameter(NCS::CView::JP2_DECOMPRESS_LAYERS, nQuality);

		NCSFileInfo* pSourceFileInfo = embeddedImageFile.GetFileInfo();

		//prepare information to set view
		UINT32 numberOfViewBands = pSourceFileInfo->nBands > 3 ? 3 : pSourceFileInfo->nBands;
		std::vector<UINT32> bandList;
		for (UINT32 i = 0; i < numberOfViewBands; i++)
			bandList.push_back(i);
		UINT32 scaledWidth =  MIN(SCALE_TO, pSourceFileInfo->nSizeX);
		UINT32 scaledHeight = MIN(SCALE_TO, pSourceFileInfo->nSizeY);

		//set view to extract the whole embedded image and put it into a scaled view
		err_jp2 = embeddedImageFile.SetView(
						numberOfViewBands, &bandList[0], 
						0, 0, pSourceFileInfo->nSizeX - 1, pSourceFileInfo->nSizeY - 1,
						scaledWidth, scaledHeight);
		
		if( err_jp2.Success())
		{
			switch (pSourceFileInfo->eCellType)
			{
			case NCSCT_UINT8:
				DecompressAndWriteToOutputFile<UINT8>(embeddedImageFile, argv[1], scaledHeight, scaledWidth * numberOfViewBands);
				break;
			case NCSCT_UINT16:
				DecompressAndWriteToOutputFile<UINT16>(embeddedImageFile, argv[1], scaledHeight, scaledWidth * numberOfViewBands);
				break;
			case NCSCT_UINT32:
				DecompressAndWriteToOutputFile<UINT32>(embeddedImageFile, argv[1], scaledHeight, scaledWidth * numberOfViewBands);
				break;
			case NCSCT_UINT64:
				DecompressAndWriteToOutputFile<UINT64>(embeddedImageFile, argv[1], scaledHeight, scaledWidth * numberOfViewBands);
				break;
			case NCSCT_INT8:
				DecompressAndWriteToOutputFile<INT8>(embeddedImageFile, argv[1], scaledHeight, scaledWidth * numberOfViewBands);
				break;
			case NCSCT_INT16:
				DecompressAndWriteToOutputFile<INT16>(embeddedImageFile, argv[1], scaledHeight, scaledWidth * numberOfViewBands);
				break;
			case NCSCT_INT32:
				DecompressAndWriteToOutputFile<INT32>(embeddedImageFile, argv[1], scaledHeight, scaledWidth * numberOfViewBands);
				break;
			case NCSCT_INT64:
				DecompressAndWriteToOutputFile<INT64>(embeddedImageFile, argv[1], scaledHeight, scaledWidth * numberOfViewBands);
				break;
			case NCSCT_IEEE4:
				DecompressAndWriteToOutputFile<IEEE4>(embeddedImageFile, argv[1], scaledHeight, scaledWidth * numberOfViewBands);
				break;	
			case NCSCT_IEEE8:
				DecompressAndWriteToOutputFile<IEEE8>(embeddedImageFile, argv[1], scaledHeight, scaledWidth * numberOfViewBands);
				break;
			default:
				printf("Unsupported cell type from the embedded input image!");
				throw std::exception();
			}

		}
		//bFreeCache = true because otherwise stream would be freed before NCSShutdown which causes problems.
		embeddedImageFile.Close(true);
	}

	return 0;
}

