/********************************************************** 
** Copyright, 1998 - 2013, Intergraph Corporation. All rights reserved.
**
** FILE:   	dexample10.cpp
** CREATED:	25th June 2012
** AUTHOR: 	Yakun Wang
** PURPOSE: An example on how to use the header editor interface to set the file statistics on ecw version 3 files
**********************************************************/
#ifdef WIN32
#include "stdafx.h"
#endif
#include "NCSUtil.h"
#include "NCSEcw/API/HeaderEditor.h"
#include <time.h>
#include "NCSEcw/API/View.h"

void PrintUsage( char* sFunctionName )
{
	printf("Usage: %s <input filename ECW V3>\n", sFunctionName);
}

NCSFileStatistics* GenerateClientStatistics(UINT32 numberOfBands, UINT32 maxPixelValue, UINT32 histogramBucketCount)
{
	//Generate some random numbers based on the range, please use the calculated values in real application
	NCSFileStatistics* pStats = NULL;
	srand ( time(NULL) );
	NCSInitStatisticsDefault(&pStats, numberOfBands, histogramBucketCount);
		
	for (std::size_t i = 0; i < pStats->nNumberOfBands; i++)
	{
		pStats->BandsStats[i].fMinVal = 0;
		pStats->BandsStats[i].fMaxVal = rand() % (maxPixelValue + 1);
		if (pStats->BandsStats[i].fMaxVal == 0)
			pStats->BandsStats[i].fMaxVal += 1;
		pStats->BandsStats[i].fMeanVal = rand() % ((UINT32)pStats->BandsStats[i].fMaxVal);
		pStats->BandsStats[i].fMedianVal = rand() % ((UINT32)pStats->BandsStats[i].fMaxVal);
		pStats->BandsStats[i].fMode = rand() % pStats->BandsStats[i].nHistBucketCount;
		pStats->BandsStats[i].fStandardDev = rand() % ((UINT32)pStats->BandsStats[i].fMaxVal);
		pStats->BandsStats[i].fMinHist = pStats->BandsStats[i].fMinVal;
		pStats->BandsStats[i].fMaxHist = pStats->BandsStats[i].fMaxVal;

		for (std::size_t j = 0; j < pStats->BandsStats[i].nHistBucketCount; j++)
		{
			pStats->BandsStats[i].Histogram[j] = rand();
		}
	}

	return pStats;
}

void PrintComparison(NCSFileStatistics *pOld, NCSFileStatistics *pNew)
{
	std::string report = ""; 
	char pTemp[256];
	if(pOld)
	{
		report += "The statistics data on the original file is: \r\n";
		for (int j = 0; j < pOld->nNumberOfBands; j++)
		{
			sprintf(pTemp, "Band Min value: %lf\r\n", pOld->BandsStats[j].fMinVal);
			report += pTemp;
			sprintf(pTemp, "Band Max value: %lf\r\n", pOld->BandsStats[j].fMaxVal);
			report += pTemp;
			sprintf(pTemp, "Band Mean Value: %lf\r\n", pOld->BandsStats[j].fMeanVal);
			report += pTemp;
			sprintf(pTemp, "Band Median Value: %lf\r\n", pOld->BandsStats[j].fMedianVal);
			report += pTemp;
			sprintf(pTemp, "Band Mode Value: %lf\r\n", pOld->BandsStats[j].fMode);
			report += pTemp;
			sprintf(pTemp, "Band Standard Deviation Value: %lf\r\n", pOld->BandsStats[j].fStandardDev);
			report += pTemp;
			sprintf(pTemp, "Band Histogram Min Value: %lf\r\n", pOld->BandsStats[j].fMinHist);
			report += pTemp;
			sprintf(pTemp, "Band Histogram Max Value: %lf\r\n", pOld->BandsStats[j].fMaxHist);
			report += pTemp;
			
			sprintf(pTemp, "Band Histogram: ");
			for (int k = 0; k < pOld->BandsStats[j].nHistBucketCount; k++)
			{
				sprintf(pTemp, " %ld |", pOld->BandsStats[j].Histogram[k]);
				report += pTemp;
			}
			report += "\r\n";
		}
	}
	else
	{
		report += "Original file has no statistic data. \r\n";
	}
	
	if(pNew)
	{
		report += "Updated statistics on the file is: \r\n";
		for (int j = 0; j < pNew->nNumberOfBands; j++)
		{
			sprintf(pTemp, "Band Min value: %lf\r\n", pNew->BandsStats[j].fMinVal);
			report += pTemp;
			sprintf(pTemp, "Band Max value: %lf\r\n", pNew->BandsStats[j].fMaxVal);
			report += pTemp;
			sprintf(pTemp, "Band Mean Value: %lf\r\n", pNew->BandsStats[j].fMeanVal);
			report += pTemp;
			sprintf(pTemp, "Band Median Value: %lf\r\n", pNew->BandsStats[j].fMedianVal);
			report += pTemp;
			sprintf(pTemp, "Band Mode Value: %lf\r\n", pNew->BandsStats[j].fMode);
			report += pTemp;
			sprintf(pTemp, "Band Standard Deviation Value: %lf\r\n", pNew->BandsStats[j].fStandardDev);
			report += pTemp;
			sprintf(pTemp, "Band Histogram Min Value: %lf\r\n", pNew->BandsStats[j].fMinHist);
			report += pTemp;
			sprintf(pTemp, "Band Histogram Max Value: %lf\r\n", pNew->BandsStats[j].fMaxHist);
			report += pTemp;

			sprintf(pTemp, "Band Histogram: ");
			for (int k = 0; k < pNew->BandsStats[j].nHistBucketCount; k++)
			{
				sprintf(pTemp, " %ld |", pNew->BandsStats[j].Histogram[k]);
				report += pTemp;
			}
			report += "\r\n";
		}
	}
	else
	{
		report += "Statistic data is not set. \r\n";
	}

	printf(report.c_str());
	printf("\n\n");
}

int main(int argc, char* argv[])
{
	CNCSError Error;
	NCSTChar* wFileName = NULL;
	if(argc < 2) {
		PrintUsage(argv[0]);
		exit(1);
	}

	NCS::CApplication App;

	NCSUtf8Decode(argv[1], &wFileName);

	//First set the file name on the headereditor
	NCS::CHeaderEditor HeaderEditor;
	if((Error = HeaderEditor.OpenFile(wFileName)) != NCS_SUCCESS) {
		printf("Failed to open the file.\n\n%s\n\n", NCSGetLastErrorText(Error));
		exit(1);
	}

	//Get file type, version to tell if the file is able to set statistics
	if (HeaderEditor.GetVersion() <= 2 || HeaderEditor.GetFileType() != NCS_FILE_ECW)
	{
		printf("File type or version is not supported for setting statistics.\n\n");
		exit(1);
	}
	
	//get number of bands. The opacity band should not be counted when setting statistics
	UINT32 nBandNum = HeaderEditor.GetNumberOfBands();
	if (HeaderEditor.HasOpacity())
		nBandNum--;
	
	// histogram bucket counts could be less than (1 << bitdepth), currently set it to the full range
	UINT32 nMaxPixelValue, nHistBucketCounts;
	switch (HeaderEditor.GetCellType())
	{
	case NCSCT_UINT8:
		nMaxPixelValue = 255; 
		nHistBucketCounts = 256;
		break;
	case NCSCT_UINT16:
		nMaxPixelValue = 65535;
		nHistBucketCounts = 65536;
		break;
	default:
		printf("Cell type on the file is not supported for setting statistics.");
		exit(1);
	}

	//Get statistics from the header editor, and generate some valid random numbers on the new statistics for setting
	NCSFileStatistics *pOriginalStats = NULL;
	NCSFileStatistics *pStatsForEditing = GenerateClientStatistics(nBandNum, nMaxPixelValue, nHistBucketCounts);
	NCSCopyStatistics(&pOriginalStats, HeaderEditor.GetStatistics());

	//Set the new statistics on file
	if((Error = HeaderEditor.SetStatistics(pStatsForEditing)) != NCS_SUCCESS) {
		printf("%s\n\n", NCSGetLastErrorText(Error));		
		exit(1);
	}
	
	//flush the setting and close the headereditor
	HeaderEditor.FlushAll();
	HeaderEditor.Close();

	printf("Operation Completed Successfully.\n\n");

	//Print comparison and free the allocated structures
	PrintComparison(pOriginalStats, pStatsForEditing);
	NCSFree(wFileName);
	NCSFreeStatistics(pStatsForEditing);
	NCSFreeStatistics(pOriginalStats);
	return 0;
}
