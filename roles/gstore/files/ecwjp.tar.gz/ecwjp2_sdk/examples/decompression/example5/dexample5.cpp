/********************************************************** 
** Copyright, 1998 - 2013, Intergraph Corporation. All rights reserved.
**  
** FILE:   	dexample5.cpp
** CREATED:	1st June 2010
** AUTHOR: 	Chris Tapley
**
** PURPOSE:	Example program demonstrating reading an entire image at dataset
**			resolution.
**
*******************************************************/
#ifdef WIN32
#include "stdafx.h"
#endif
#include "NCSFile.h"

int main(int argc, char* argv[])
{
	if(argc < 2) {
		printf("Usage: %s <input filename>\n", argv[0]);
		exit(1);
	}

	NCS::CApplication App;

	NCSSetConfig(NCSCFG_CACHE_MAXMEM, 1000000000);

	NCSTimeStampMs tsStart = NCSGetTimeStampMs();

	CNCSString sFileName = CNCSString(argv[1]);
	CNCSFile File;
	CNCSError Error;
	if((Error = File.Open(sFileName, false, false)) == NCS_SUCCESS) {
		
		NCSFileInfo *pInfo = File.GetFileInfo();
		UINT32 *pBandList = (UINT32*)NCSMalloc(pInfo->nBands * sizeof(UINT32), FALSE);
		for(UINT16 nBand = 0; nBand < pInfo->nBands; nBand++) {
			pBandList[nBand] = nBand;
		}
		if((Error = File.SetView(pInfo->nBands, pBandList, 0, 0, pInfo->nSizeX-1, pInfo->nSizeY-1, pInfo->nSizeX, pInfo->nSizeY)) == NCS_SUCCESS) {
			// Reading each line as UINT8, this may not be desirable in your app when working with non 8 bit jp2's.
			UINT8 **pLine = (UINT8**)NCSMalloc(pInfo->nBands * sizeof(UINT8*), TRUE);
			for(UINT16 nBand = 0; nBand < pInfo->nBands; nBand++) {
				pLine[nBand] = (UINT8*)NCSMalloc(pInfo->nSizeX * sizeof(UINT8), TRUE);
			}
			for(UINT32 nLine = 0; nLine < pInfo->nSizeY && Error == NCS_SUCCESS; nLine++) {
				if(File.ReadLineBIL(pLine) == NCS_READ_OK) {
					fprintf(stdout, "Read: %d%% Complete\r", (int)(((((float)nLine) / pInfo->nSizeY) * 100) + 0.5));
					fflush(stdout); 
				} else {
					Error = NCS_FILE_IO_ERROR;
				}
			}
			for(UINT16 nBand = 0; nBand < pInfo->nBands; nBand++) {
				NCSFree(pLine[nBand]);
			}
			NCSFree(pLine);
			NCSFree(pBandList);
		}

		// passing true to close clears the cache for this file if there 
		// are no other file views open to this file
		File.Close(true);
	} else {
		printf("Unable to open file.\n\n");
		exit(1);
	}
	if(Error == NCS_SUCCESS) {
		printf("Read completed successfully in %I64d seconds\n", (NCSGetTimeStampMs()-tsStart)/1000);
	}

	return 0;
}

