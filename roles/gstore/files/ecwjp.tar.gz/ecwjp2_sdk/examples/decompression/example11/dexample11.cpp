/********************************************************** 
** Copyright, 1998 - 2013, Intergraph Corporation. All rights reserved.
**
** FILE:   	dexample11.cpp
** CREATED:	25th June 2012
** AUTHOR: 	Yakun Wang
** PURPOSE: An example on how to use the header editor interface to set the RPC data on ecw version 3 files
**********************************************************/

#ifdef WIN32
#include "stdafx.h"
#endif
#include "NCSUtil.h"
#include "NCSEcw/API/HeaderEditor.h"
#include "NCSEcw/API/View.h"
#include <time.h>

void PrintUsage( char* sFunctionName )
{
	printf("Usage: %s <input filename ECW V3>\n", sFunctionName);
}

NCSRPCData* GenerateRPCData()
{
	NCSRPCData* pRPCData = NULL;
	pRPCData = (NCSRPCData*)NCSMalloc(sizeof(NCSRPCData), true);
	pRPCData->ERR_BIAS = 12.23;
	pRPCData->ERR_RAND = 0.48;
	pRPCData->LINE_OFF = 3522;
	pRPCData->SAMP_OFF = 4406;
	pRPCData->LAT_OFF = 35.2298;
	pRPCData->LONG_OFF = -80.8601;
	pRPCData->HEIGHT_OFF = 186;
	pRPCData->LINE_SCALE = 3639;
	pRPCData->SAMP_SCALE = 4421;
	pRPCData->LAT_SCALE = 0.0780;
	pRPCData->LONG_SCALE = 0.1020;
	pRPCData->HEIGHT_SCALE = 501;
	
	pRPCData->LINE_NUM_COEFFS[0] = -2.082755E-03; pRPCData->LINE_NUM_COEFFS[1] = -2.790828E-02; pRPCData->LINE_NUM_COEFFS[2] = -9.964968E-01; pRPCData->LINE_NUM_COEFFS[3] = -3.190691E-02;
	pRPCData->LINE_NUM_COEFFS[4] = +2.425357E-05; pRPCData->LINE_NUM_COEFFS[5] = -5.681094E-06; pRPCData->LINE_NUM_COEFFS[6] = -5.331409E-05; pRPCData->LINE_NUM_COEFFS[7] = -1.206832E-04;
	pRPCData->LINE_NUM_COEFFS[8] = +2.643640E-03; pRPCData->LINE_NUM_COEFFS[9] = -8.340423E-07; pRPCData->LINE_NUM_COEFFS[10] =  -6.097826E-07; pRPCData->LINE_NUM_COEFFS[11] =  -6.092152E-07;
	pRPCData->LINE_NUM_COEFFS[12] = -1.137766E-05; pRPCData->LINE_NUM_COEFFS[13] = -8.744738E-07; pRPCData->LINE_NUM_COEFFS[14] = -2.174531E-05; pRPCData->LINE_NUM_COEFFS[15] = -1.302682E-04;
	pRPCData->LINE_NUM_COEFFS[16] =  -3.115474E-05; pRPCData->LINE_NUM_COEFFS[17] =  -7.160171E-07; pRPCData->LINE_NUM_COEFFS[18] =  -1.194601E-05; pRPCData->LINE_NUM_COEFFS[19] =  -5.147002E-07;
	
	pRPCData->LINE_DEN_COEFFS[0] = 1.000000E+00; pRPCData->LINE_DEN_COEFFS[1] = -3.544814E-05; pRPCData->LINE_DEN_COEFFS[2] = +6.950074E-04; pRPCData->LINE_DEN_COEFFS[3] = -1.014129E-04;
	pRPCData->LINE_DEN_COEFFS[4] = -1.088161E-05; pRPCData->LINE_DEN_COEFFS[5] = -4.797741E-07; pRPCData->LINE_DEN_COEFFS[6] = -5.799360E-06; pRPCData->LINE_DEN_COEFFS[7] = +2.503022E-05;
	pRPCData->LINE_DEN_COEFFS[8] = -7.031893E-05; pRPCData->LINE_DEN_COEFFS[9] = +3.031918E-05; pRPCData->LINE_DEN_COEFFS[10] = -2.059119E-06; pRPCData->LINE_DEN_COEFFS[11] = -2.263008E-08;
	pRPCData->LINE_DEN_COEFFS[12] = -4.625445E-05; pRPCData->LINE_DEN_COEFFS[13] = -6.111694E-08; pRPCData->LINE_DEN_COEFFS[14] = -1.372970E-06; pRPCData->LINE_DEN_COEFFS[15] = -5.243668E-04;
	pRPCData->LINE_DEN_COEFFS[16] = -2.111056E-06; pRPCData->LINE_DEN_COEFFS[17] = -4.327521E-08; pRPCData->LINE_DEN_COEFFS[18] = -3.563140E-05; pRPCData->LINE_DEN_COEFFS[19] = +2.449699E-07;

	pRPCData->SAMP_NUM_COEFFS[0] = -7.918007E-05; pRPCData->SAMP_NUM_COEFFS[1] =  +1.000871E+00; pRPCData->SAMP_NUM_COEFFS[2] =  -1.068091E-03; pRPCData->SAMP_NUM_COEFFS[3] = -2.365811E-03;
	pRPCData->SAMP_NUM_COEFFS[4] = -1.618173E-03; pRPCData->SAMP_NUM_COEFFS[5] =  +3.305229E-04; pRPCData->SAMP_NUM_COEFFS[6] =  -6.274837E-05; pRPCData->SAMP_NUM_COEFFS[7] = +2.923455E-04;
	pRPCData->SAMP_NUM_COEFFS[8] = +4.374891E-04; pRPCData->SAMP_NUM_COEFFS[9] =  -3.186432E-06; pRPCData->SAMP_NUM_COEFFS[10] =  -7.150948E-07; pRPCData->SAMP_NUM_COEFFS[11] = -8.546845E-06;
	pRPCData->SAMP_NUM_COEFFS[12] = -9.369117E-06; pRPCData->SAMP_NUM_COEFFS[13] =  -3.439202E-06; pRPCData->SAMP_NUM_COEFFS[14] =  +1.115874E-05; pRPCData->SAMP_NUM_COEFFS[15] = +3.265740E-05;
	pRPCData->SAMP_NUM_COEFFS[16] = -2.978212E-07; pRPCData->SAMP_NUM_COEFFS[17] =  +6.902997E-07; pRPCData->SAMP_NUM_COEFFS[18] =  +2.256772E-06; pRPCData->SAMP_NUM_COEFFS[19] = +6.943991E-08;

	pRPCData->SAMP_DEN_COEFFS[0] = +1.000000E+00; pRPCData->SAMP_DEN_COEFFS[1] = -2.142645E-04; pRPCData->SAMP_DEN_COEFFS[2] = +1.619261E-03; pRPCData->SAMP_DEN_COEFFS[3] = -3.311616E-04;
	pRPCData->SAMP_DEN_COEFFS[4] = -3.635326E-06; pRPCData->SAMP_DEN_COEFFS[5] = -2.020304E-07; pRPCData->SAMP_DEN_COEFFS[6] = +8.403076E-07; pRPCData->SAMP_DEN_COEFFS[7] = +5.506581E-07;
	pRPCData->SAMP_DEN_COEFFS[8] = +4.711838E-06; pRPCData->SAMP_DEN_COEFFS[9] = -3.610730E-06; pRPCData->SAMP_DEN_COEFFS[10] = -1.963179E-08; pRPCData->SAMP_DEN_COEFFS[11] = +0.000000E+00;
	pRPCData->SAMP_DEN_COEFFS[12] = +3.080076E-08; pRPCData->SAMP_DEN_COEFFS[13] = +0.000000E+00; pRPCData->SAMP_DEN_COEFFS[14] = -5.210861E-08; pRPCData->SAMP_DEN_COEFFS[15] = -5.862951E-07;
	pRPCData->SAMP_DEN_COEFFS[16] = -1.541843E-08; pRPCData->SAMP_DEN_COEFFS[17] = +0.000000E+00; pRPCData->SAMP_DEN_COEFFS[18] = -3.558677E-08; pRPCData->SAMP_DEN_COEFFS[19] = +0.000000E+00;
	
	return pRPCData;
}

void PrintComparison(NCSRPCData *pOld, NCSRPCData *pNew)
{
	std::string report = ""; 
	char pTemp[256];
	if (pOld)
	{
		report += "The RPC data on the original file is: \r\n";
		sprintf(pTemp, "ERR_BIAS : %lf\r\n", pOld->ERR_BIAS);
		report += pTemp;
		sprintf(pTemp, "ERR_RAND : %lf\r\n", pOld->ERR_RAND);
		report += pTemp;
		sprintf(pTemp, "HEIGHT_OFF : %lf\r\n", pOld->HEIGHT_OFF);
		report += pTemp;
		sprintf(pTemp, "HEIGHT_SCALE : %lf\r\n", pOld->HEIGHT_SCALE);
		report += pTemp;
		sprintf(pTemp, "LAT_OFF : %lf\r\n", pOld->LAT_OFF);
		report += pTemp;
		sprintf(pTemp, "LAT_OFF : %lf\r\n", pOld->LAT_SCALE);
		report += pTemp;
		sprintf(pTemp, "LINE_OFF : %lf\r\n", pOld->LINE_OFF);
		report += pTemp;
		sprintf(pTemp, "LINE_SCALE : %lf\r\n", pOld->LINE_SCALE);
		report += pTemp;
		sprintf(pTemp, "LONG_OFF : %lf\r\n", pOld->LONG_OFF);
		report += pTemp;
		sprintf(pTemp, "LONG_SCALE : %lf\r\n", pOld->LONG_SCALE);
		report += pTemp;
		sprintf(pTemp, "SAMP_OFF : %lf\r\n", pOld->SAMP_OFF);
		report += pTemp;
		sprintf(pTemp, "SAMP_SCALE : %lf\r\n", pOld->SAMP_SCALE);
		report += pTemp;
		report += "LINE_DEN_COEFFS : ";
		for (int j = 0; j < 20; j++)
		{
			sprintf(pTemp, " %+E |", pOld->LINE_DEN_COEFFS[j]);
			report += pTemp;
		}
		report += "\r\n";
		report += "LINE_NUM_COEFFS : ";
		for (int j = 0; j < 20; j++)
		{
			sprintf(pTemp, " %+E |", pOld->LINE_NUM_COEFFS[j]);
			report += pTemp;
		}
		report += "\r\n";
		report += "SAMP_DEN_COEFFS : ";
		for (int j = 0; j < 20; j++)
		{
			sprintf(pTemp, " %+E |", pOld->SAMP_DEN_COEFFS[j]);
			report += pTemp;
		}
		report += "\r\n";
		report += "SAMP_NUM_COEFFS : ";
		for (int j = 0; j < 20; j++)
		{
			sprintf(pTemp, " %+E |", pOld->SAMP_NUM_COEFFS[j]);
			report += pTemp;
		}
		report += "\r\n";
	}
	else
	{
		report += "Original file has no RPC data. \r\n";
	}
	if (pNew)
	{
		report += "Updated RPC Data on the file is: \r\n";
		sprintf(pTemp, "ERR_BIAS : %lf\r\n", pNew->ERR_BIAS);
		report += pTemp;
		sprintf(pTemp, "ERR_RAND : %lf\r\n", pNew->ERR_RAND);
		report += pTemp;
		sprintf(pTemp, "HEIGHT_OFF : %lf\r\n", pNew->HEIGHT_OFF);
		report += pTemp;
		sprintf(pTemp, "HEIGHT_SCALE : %lf\r\n", pNew->HEIGHT_SCALE);
		report += pTemp;
		sprintf(pTemp, "LAT_OFF : %lf\r\n", pNew->LAT_OFF);
		report += pTemp;
		sprintf(pTemp, "LAT_OFF : %lf\r\n", pNew->LAT_SCALE);
		report += pTemp;
		sprintf(pTemp, "LINE_OFF : %lf\r\n", pNew->LINE_OFF);
		report += pTemp;
		sprintf(pTemp, "LINE_SCALE : %lf\r\n", pNew->LINE_SCALE);
		report += pTemp;
		sprintf(pTemp, "LONG_OFF : %lf\r\n", pNew->LONG_OFF);
		report += pTemp;
		sprintf(pTemp, "LONG_SCALE : %lf\r\n", pNew->LONG_SCALE);
		report += pTemp;
		sprintf(pTemp, "SAMP_OFF : %lf\r\n", pNew->SAMP_OFF);
		report += pTemp;
		sprintf(pTemp, "SAMP_SCALE : %lf\r\n", pNew->SAMP_SCALE);
		report += pTemp;
		report += "LINE_DEN_COEFFS : ";
		for (int j = 0; j < 20; j++)
		{
			sprintf(pTemp, " %+E |", pNew->LINE_DEN_COEFFS[j]);
			report += pTemp;
		}
		report += "\r\n";
		report += "LINE_NUM_COEFFS : ";
		for (int j = 0; j < 20; j++)
		{
			sprintf(pTemp, " %+E |", pNew->LINE_NUM_COEFFS[j]);
			report += pTemp;
		}
		report += "\r\n";
		report += "SAMP_DEN_COEFFS : ";
		for (int j = 0; j < 20; j++)
		{
			sprintf(pTemp, " %+E |", pNew->SAMP_DEN_COEFFS[j]);
			report += pTemp;
		}
		report += "\r\n";
		report += "SAMP_NUM_COEFFS : ";
		for (int j = 0; j < 20; j++)
		{
			sprintf(pTemp, " %+E |", pNew->SAMP_NUM_COEFFS[j]);
			report += pTemp;
		}
		report += "\r\n";
	}
	else
	{
		report += "RPC data is not set. \r\n";
	}
	printf(report.c_str());
	printf("\n\n");
}

int main(int argc, char* argv[])
{
    CNCSError Error;
	NCSTChar* wFileName = NULL;
	if(argc < 2) {
		PrintUsage(argv[0]);
		exit(1);
	}

	NCS::CApplication App;

	NCSUtf8Decode(argv[1], &wFileName);

	//First set the file name on the headereditor
	NCS::CHeaderEditor HeaderEditor;
	if((Error = HeaderEditor.OpenFile(wFileName)) != NCS_SUCCESS) {
		printf("Failed to open the file.\n\n%s\n\n", NCSGetLastErrorText(Error));
		exit(1);
	}

	//Get file type, version to tell if the file is able to set RPC data
	if (HeaderEditor.GetVersion() <= 2 || HeaderEditor.GetFileType() != NCS_FILE_ECW)
	{
		printf("File type or version is not supported for setting rpc data.\n\n");
		exit(1);
	}
	

	//Get rpc data from the header editor, and generate some valid rpc data values for setting
	NCSRPCData *pOriginRPCData = NULL;
	NCSRPCData *pRPCDataForEditing = GenerateRPCData();
	NCSCopyRPCData(&pOriginRPCData, HeaderEditor.GetRPCData());

	//Set the new rpc data on the file
	if((Error = HeaderEditor.SetRPCData(pRPCDataForEditing)) != NCS_SUCCESS) {
		printf("%s\n\n", NCSGetLastErrorText(Error));	
		exit(1);
	}
	
	//flush the setting and close the headereditor
	HeaderEditor.FlushAll();
	HeaderEditor.Close();
	
	printf("Operation Completed Successfully.\n\n");

	//Print comparison and free the allocated 
	PrintComparison(pOriginRPCData, pRPCDataForEditing);
	NCSFreeRPCData(pRPCDataForEditing);
	NCSFreeRPCData(pOriginRPCData);

	return 0;
}

