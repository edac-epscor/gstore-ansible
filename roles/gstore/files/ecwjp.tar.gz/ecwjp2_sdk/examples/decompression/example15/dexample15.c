/********************************************************** 
** Copyright, 1998 - 2013, Intergraph Corporation. All rights reserved.
**
** FILE:   	dexample15.c
** CREATED:	25th June 2012
** AUTHOR: 	Yakun Wang
** PURPOSE: An example on how to use the C interface to define a custom projection using setting geotiff key/tags on ecw version 3 files
**********************************************************/

#include "NCSUtil.h"
#include "NCSECWHeaderEditor.h"
#include "NCSEcw/GTIF/geokeys.h"
#include "NCSEcw/GTIF/geovalues.h"
#include "NCSEcw/GTIF/geo_public_defs.h"
#include <time.h>

void PrintUsage( char* sFunctionName )
{
	printf("Usage: %s <input filename>\n", sFunctionName);
}

void PrintGeotiffKeyTags(NCSTChar* fileName)
{
	NCSFileView* pFileViewRead = NULL;
	NCSGeoKeyEntry* pGeoKeyEntry = NULL;
	UINT32 count = 0;
	unsigned short shortValue;
	IEEE8 doubleValue;
	char stringValue[512];
	int transformationMatrixCount, pixelScaleCount, tiePointCount;
	IEEE8* pTransformationMatrix = NULL;
	IEEE8* pPixelScale = NULL;
	IEEE8* pTiepoints = NULL;
	UINT32 i;

	if (NCSOpenFileViewW(fileName, &pFileViewRead, NULL) != NCS_SUCCESS)
	{
		printf("Unable to open file: %hs\n", fileName);
		exit(1);
	}
	printf("The original geotiff keys and tags on the file are: \n");
	NCSGetAllGeotiffKeyEntries(pFileViewRead, &pGeoKeyEntry, &count);
	if (count == 0)
		printf("no geotiff key is detected. \n");
	else
		printf("%d geotiff key are detected, they are: \n", count);
	for(i = 0; i < count; i++)
	{
		switch(pGeoKeyEntry[i].keyType)
		{
		case TYPE_SHORT:
			NCSGetGeotiffKey(pFileViewRead, pGeoKeyEntry[i].keyId, &shortValue, 0, 1); 
			printf("%s : %s\n", NCS_GTIFKeyName(pGeoKeyEntry[i].keyId), NCS_GTIFValueName(pGeoKeyEntry[i].keyId, shortValue));
			break;
		case TYPE_DOUBLE:
			NCSGetGeotiffKey(pFileViewRead, pGeoKeyEntry[i].keyId, &doubleValue, 0, 1);
			printf("%s : %lf\n", NCS_GTIFKeyName(pGeoKeyEntry[i].keyId), doubleValue);
			break;
		case TYPE_ASCII:
			NCSGetGeotiffKey(pFileViewRead, pGeoKeyEntry[i].keyId, stringValue, 0, pGeoKeyEntry[i].valCount); 
			printf("%s : %s\n", NCS_GTIFKeyName(pGeoKeyEntry[i].keyId), stringValue);
			break;
		default:
			printf("Stored geotiff key type is incorrect!\n");
			break;
		}
	}

	if (NCSGetGeotiffTag(pFileViewRead, GTIFF_TIEPOINTS, &tiePointCount, &pTiepoints) == NCS_SUCCESS)
	{
		if (tiePointCount > 0 && pTiepoints != NULL)
		{
			printf("Pixel tag is detected, the values are : ", fileName);
			for (i = 0; i < tiePointCount; i++)
			{
				printf("%lf, ", pTiepoints[i]);
			}
			printf("\n");
		}
	}

	if (NCSGetGeotiffTag(pFileViewRead, GTIFF_PIXELSCALE, &pixelScaleCount, &pPixelScale) == NCS_SUCCESS)
	{
		if (pixelScaleCount > 0 && pPixelScale != NULL)
		{
			printf("Pixel tag is detected, the values are : ", fileName);
			for (i = 0; i < pixelScaleCount; i++)
			{
				printf("%lf, ", pPixelScale[i]);
			}
			printf("\n");
		}
	}

	if (NCSGetGeotiffTag(pFileViewRead, GTIFF_TRANSMATRIX, &transformationMatrixCount, &pTransformationMatrix) == NCS_SUCCESS)
	{
		if (transformationMatrixCount > 0 && pTransformationMatrix != NULL)
		{
			printf("Transformation matrix tag is detected, the values are : ", fileName);
			for (i = 0; i < transformationMatrixCount; i++)
			{
				printf("%lf, ", pTransformationMatrix[i]);
			}
			printf("\n");
		}
	}
	
	NCSFree(pGeoKeyEntry);

	NCSFree(pPixelScale);
	NCSFree(pTiepoints);
	NCSFree(pTransformationMatrix);

	NCSCloseFileViewEx(pFileViewRead, TRUE);
}

void GetETCPath(char *szPath, int nSize)
{
	char *pSZ;
#if defined(WIN32)
	HMODULE hMod = GetModuleHandle(NULL);
	GetModuleFileNameA(hMod, szPath, nSize);
	
	pSZ = szPath + (strlen(szPath)-1);
	while(*pSZ != '\\' && pSZ >= szPath) {
		pSZ--;
	}
	*pSZ = '\0';
	strcat_s(szPath, 1024, "\\..\\..\\..\\etc");
#elif defined(POSIX)
	getcwd(szPath, nSize);
	pSZ = szPath + (strlen(szPath)-1);
	while(*pSZ != '/' && pSZ >= szPath) {
		pSZ--;
	}
	*pSZ = '\0';
	strcat(szPath, "../../../etc");
#else
#error Platform not implemented
#endif
}

int main(int argc, char* argv[])
{
	NCSTChar* pFilename = NULL;
	NCSFileView* pFileView = NULL;
	double oriTransformationMatrix[16] = 
			{0.0, 100.0, 0.0, 400000.0,
			100.0, 0.0, 0.0, 500000.0,
			0.0, 0.0, 0.0, 0.0,
			0.0, 0.0, 0.0, 1.0};
	char szGdtPath[1024]; 

	NCSInit();

	GetETCPath(szGdtPath, 1024);
	
	if(argc < 2) {
		PrintUsage(argv[0]);
		exit(1);
	}

	//change it to a custom projection using setting geotiff key/tags
	NCSUtf8Decode(argv[1], &pFilename);

	
	PrintGeotiffKeyTags(pFilename);

	pFileView = NCSEditOpen(pFilename);

	if (pFileView)
	{
		NCSEditSetGeotiffKey(pFileView, GTModelTypeGeoKey, TYPE_SHORT, 1, ModelTypeProjected);
		NCSEditSetGeotiffKey(pFileView, GTRasterTypeGeoKey, TYPE_SHORT, 1, RasterPixelIsArea);
		NCSEditSetGeotiffKey(pFileView, ProjectedCSTypeGeoKey, TYPE_SHORT, 1, PCS_British_National_Grid);
		NCSEditSetGeotiffKey(pFileView, PCSCitationGeoKey, TYPE_ASCII, 1, "British National Grid, Zone NZ");
		
		NCSEditSetGeotiffTag(pFileView, GTIFF_TRANSMATRIX, 16, oriTransformationMatrix);
		NCSEditFlushAll(pFileView);
		NCSEditClose(pFileView);
	}
	else
	{
		printf("Unable to open the file: %s\n", argv[1]); 
		NCSFree(pFilename);
		NCSShutdown();
		exit(1);
	}

	printf("The modified geotiff keys and tags on the file are: \n");
	PrintGeotiffKeyTags(pFilename);
	
	NCSFree(pFilename);
	NCSShutdown();

	return 0;
}

