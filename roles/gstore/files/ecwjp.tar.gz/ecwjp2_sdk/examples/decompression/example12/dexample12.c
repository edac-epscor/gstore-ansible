/********************************************************** 
** Copyright, 1998 - 2013, Intergraph Corporation. All rights reserved.
**
** FILE:   	dexample12.cpp
** CREATED:	25th June 2012
** AUTHOR: 	Jeremy Jarvis
** PURPOSE: An example on how to use the header editor C interface to modify the File Metadata
**********************************************************/

#include "NCSErrors.h"
#include "NCSUtil.h"
#include "NCSECWHeaderEditor.h"

void PrintUsage(char* sFunctionName)
{
		printf("Usage: %s file [-author AUTHOR][-address ADDRESS] [-email EMAIL]\n", sFunctionName);
		printf("      [-company COMPANY] [-copyright COPYRIGHT] [-telephone TELEPHONE]\n\n");
}

/*	 
 *	Parse all Metadata values for the output NCSFileMetaData
 *
 */
BOOLEAN ParseArgs(int argc, char* argv[], NCSFileMetaData* pFileMetaData ) {
	char* sArg;
	BOOLEAN bValid = TRUE;
	int i;

	for(i = 2; i < argc-1 && bValid; i++) {
		sArg = argv[i];
		if(sArg[0] == '-' || sArg[0] == '/') { 
			if(strcmp(sArg, "-author") == 0) {
				if(sizeof(argv[i++]) > 0) {
					if (pFileMetaData->sAuthor)
					{
						NCSFree(pFileMetaData->sAuthor);
						pFileMetaData->sAuthor = NULL;
					}
					NCSUtf8Decode(argv[i+1], &pFileMetaData->sAuthor);
				} else {
					bValid = FALSE;
				}
			} else if(strcmp(sArg, "-copyright") == 0) {
				if(sizeof(argv[++i]) > 0) {
					if (pFileMetaData->sCopyright)
					{
						NCSFree(pFileMetaData->sCopyright);
						pFileMetaData->sCopyright = NULL;
					}
					NCSUtf8Decode(argv[i+1], &pFileMetaData->sCopyright);
				} else {
					bValid = FALSE;
				}
			} else if(strcmp(sArg, "-company") == 0) {
				if(sizeof(argv[++i]) > 0) {
					if (pFileMetaData->sCompany)
					{
						NCSFree(pFileMetaData->sCompany);
						pFileMetaData->sCompany = NULL;
					}
					NCSUtf8Decode(argv[i+1], &pFileMetaData->sCompany);
				} else {
					bValid = FALSE;
				}
			} else if(strcmp(sArg, "-email") == 0) {
				if(sizeof(argv[++i]) > 0) {
					if (pFileMetaData->sEmail)
					{
						NCSFree(pFileMetaData->sEmail);
						pFileMetaData->sEmail = NULL;
					}
					NCSUtf8Decode(argv[i+1], &pFileMetaData->sEmail);
				} else {
					bValid = FALSE;
				}
			} else if(strcmp(sArg, "-address") == 0) {
				if(sizeof(argv[++i]) > 0) {
					if (pFileMetaData->sAddress)
					{
						NCSFree(pFileMetaData->sAddress);
						pFileMetaData->sAddress = NULL;
					}
					NCSUtf8Decode(argv[i+1], &pFileMetaData->sAddress);
				} else {
					bValid = FALSE;
				}
			} else if(strcmp(sArg, "-telephone") == 0) {
				if(sizeof(argv[++i]) > 0) {
					if (pFileMetaData->sTelephone)
					{
						NCSFree(pFileMetaData->sTelephone);
						pFileMetaData->sTelephone = NULL;
					}
					NCSUtf8Decode(argv[i+1], &pFileMetaData->sTelephone);
				} else {
					bValid = FALSE;
				}
			}			
		}
	}
	return bValid;
}

void PrintComparison(NCSFileMetaData *pOld, NCSFileMetaData *pNew)
{
	if (pOld)
	{
		printf("ORIGINAL Metadata: \n\n");
		printf("Classification:\t\t%ls\n", pOld->sClassification);
		printf("Acquisition Date:\t%ls\n", pOld->sAcquisitionDate);
		printf("Sensor Name:\t\t%ls\n", pOld->sAcquisitionSensorName);
		printf("Compression Software:\t%ls\n", pOld->sCompressionSoftware); 
		printf("Author:\t\t\t%ls\n", pOld->sAuthor);
		printf("Copyright:\t\t%ls\n", pOld->sCopyright); 
		printf("Company:\t\t%ls\n", pOld->sCompany);
		printf("Email:\t\t\t%ls\n", pOld->sEmail);
		printf("Address:\t\t%ls\n", pOld->sAddress);
		printf("Telephone:\t\t%ls\n", pOld->sTelephone);
		printf("\n");
	}
	else
	{
		printf("Original file has no Metadata. \n");
	}

	printf("\nUPDATED Metadata: \n\n");
	if (pNew)
	{
		printf("Classification:\t\t%ls\n", pNew->sClassification);
		printf("Acquisition Date:\t%ls\n", pNew->sAcquisitionDate);
		printf("Sensor Name:\t\t%ls\n", pNew->sAcquisitionSensorName);
		printf("Compression Software:\t%ls\n", pNew->sCompressionSoftware); 
		printf("Author:\t\t\t%ls\n", pNew->sAuthor);
		printf("Copyright:\t\t%ls\n", pNew->sCopyright); 
		printf("Company:\t\t%ls\n", pNew->sCompany);
		printf("Email:\t\t\t%ls\n", pNew->sEmail);
		printf("Address:\t\t%ls\n", pNew->sAddress);
		printf("Telephone:\t\t%ls\n", pNew->sTelephone);
	}
	else
	{
		printf("\tMetadata is not set\n");
	}
	printf("\n\n");
}

int main(int argc, char* argv[])
{
	NCSError Error;
	NCSFileMetaData *pOriginalFileMetaData = NULL;
	NCSFileInfo *pFileInfo = NULL;
	NCSFileMetaData *pFileMetaDataForEditing = NULL;
	NCSTChar* wFileName = NULL;
	NCSFileView *pNCSFileView = NULL;

	if(argc < 4) {
		PrintUsage(argv[0]);
		exit(1);
	}

	NCSInit();

	//Open the file 
	Error = NCSOpenFileViewA(argv[1], &pNCSFileView, NULL);
	if (Error != NCS_SUCCESS)
	{
		printf("Unable to open the file: %s\n",argv[1]); 
		NCSShutdown();
		exit(1);
	}
		
	//Get the file info
	if ((Error = NCSGetViewFileInfo(pNCSFileView, &pFileInfo)) != NCS_SUCCESS)
	{
		printf("Unable to get file info from the file: %s\n ", argv[1]);
		NCSShutdown();
		exit(1);
	}


	//Get file type, version to tell if the file is able to set statistics
	if (pFileInfo->nFormatVersion <= 2 || NCSGetFileType(pNCSFileView) != NCS_FILE_ECW)
	{
		printf("File type or version is not supported for setting statistics.");
		NCSShutdown();
		exit(1);
	}
	
	//copy the file meta data
	NCSCopyMetaData(&pOriginalFileMetaData, pFileInfo->pFileMetaData);
	NCSCopyMetaData(&pFileMetaDataForEditing, pFileInfo->pFileMetaData);

	if(pFileMetaDataForEditing == NULL) {
		NCSInitMetaData(&pFileMetaDataForEditing);
	}

	//close the file view
	NCSCloseFileViewEx(pNCSFileView, TRUE);
	pNCSFileView = NULL;

	//Get file metadata from the header editor, and generate some valid random numbers on the new statistics for setting
	NCSUtf8Decode(argv[1], &wFileName);
	if((pNCSFileView = NCSEditOpen(wFileName)) == NULL) {
		printf("%s\n\n", NCSGetLastErrorText(Error));	
		NCSShutdown();
		exit(1);
	}
	
	if(ParseArgs(argc, argv, pFileMetaDataForEditing) ) {
		if((Error = NCSEditSetFileMetaData(pNCSFileView, pFileMetaDataForEditing)) != NCS_SUCCESS) {
			printf("%s\n\n", NCSGetLastErrorText(Error));		
			NCSShutdown();
			exit(1);
		}
	} else {
		printf("Invalid argument.\n\n");
		NCSShutdown();
		exit(1);
	}
	
	//flush the setting and close the file
	NCSEditFlushAll(pNCSFileView);
	NCSEditClose(pNCSFileView);
	pNCSFileView = NULL;

	printf("Operation Completed Successfully.\n\n");
	
	PrintComparison(pOriginalFileMetaData, pFileMetaDataForEditing);
	NCSFreeMetaData(pFileMetaDataForEditing);
	NCSFreeMetaData(pOriginalFileMetaData);
	NCSFree(wFileName);

	NCSShutdown();

	return 0;
}

