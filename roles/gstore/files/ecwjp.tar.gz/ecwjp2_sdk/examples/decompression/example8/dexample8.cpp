/********************************************************** 
** Copyright, 1998 - 2013, Intergraph Corporation. All rights reserved.
**  
** FILE:   	dexample8.cpp
** CREATED:	28th January 2011
** AUTHOR: 	Yakun Wang
**
** PURPOSE:	The example demonstrates how to read an view content into a buffer and access  
**			individual band pixel value at x and y coordinate of the dataset
**
*******************************************************/

#include "NCSFile.h"
#include <iostream>
#ifdef WIN32
#include <tchar.h>
#endif

using namespace NCS;

const UINT32 MAXVIEW_WINDOWSIZE = 384;
#define RAND() ((double) rand() / (double) RAND_MAX)

struct ViewSizeInfo
{
	UINT32 StartX;
	UINT32 StartY;
	UINT32 EndX;
	UINT32 EndY;
};

/*
	Randomly work out a view region based on input width and height of the image
*/
ViewSizeInfo GennerateViewRegion(UINT32 imgWidth, UINT32 imgHeight)
{	
	ViewSizeInfo viewSizeInfo;

	/* initialize random seed: */
	srand ((unsigned int)time(NULL) );

	// define a random region and size
	viewSizeInfo.StartX = (UINT32) (RAND() * imgWidth);
	viewSizeInfo.EndX	= (UINT32) (RAND() * (imgWidth - viewSizeInfo.StartX)) + viewSizeInfo.StartX;
	viewSizeInfo.StartY = (UINT32) (RAND() * imgHeight);
	viewSizeInfo.EndY	= (UINT32) (RAND() * (imgHeight - viewSizeInfo.StartX)) + viewSizeInfo.StartY;

	// make a square view area
	if( (viewSizeInfo.EndX - viewSizeInfo.StartX) < MAXVIEW_WINDOWSIZE ) {
		viewSizeInfo.EndX = viewSizeInfo.StartX + MAXVIEW_WINDOWSIZE;
		if( viewSizeInfo.EndX >= imgWidth ) { 
			viewSizeInfo.StartX = imgWidth - MAXVIEW_WINDOWSIZE;
			viewSizeInfo.EndX = imgWidth - 1;
		}
	}
	if( (viewSizeInfo.EndY - viewSizeInfo.StartY) < MAXVIEW_WINDOWSIZE ) {
		viewSizeInfo.EndY = viewSizeInfo.StartY + MAXVIEW_WINDOWSIZE;
		if( viewSizeInfo.EndY >= imgHeight ) { 
			viewSizeInfo.StartY = imgHeight - MAXVIEW_WINDOWSIZE;
			viewSizeInfo.EndY = imgHeight - 1;
		}
	}
	if( (viewSizeInfo.EndX - viewSizeInfo.StartX) < (viewSizeInfo.EndY - viewSizeInfo.StartY) )
		viewSizeInfo.EndY = viewSizeInfo.StartY + (viewSizeInfo.EndX - viewSizeInfo.StartX);
	else
		viewSizeInfo.EndX = viewSizeInfo.StartX + (viewSizeInfo.EndY - viewSizeInfo.StartY);

	return viewSizeInfo;
};

int main(int argc, char *argv[])
{
	if (argc != 2) 
	{
	  printf("Usage: %s <input filename.jp2>\n", argv[0]);
	  return(1);
	}
	
	NCS::CApplication App;

	CView* ecwFileView = new CView();

	CError ecwFileErr = ecwFileView->Open(argv[1]);

	if (!ecwFileErr.Success())
	{
#ifdef WN32
		std::cout << "File open failure due to " << ecwFileErr.GetErrorMessage() << std::endl;
#else
		printf("File open failure due to %s",ecwFileErr.GetErrorMessage().a_str());
		exit(1);
#endif
	}

	//Prepare parameters to set a view on the file
	NCSFileInfo* ecwFileInfo = ecwFileView->GetFileInfo();
	UINT32 width = ecwFileInfo->nSizeX;
	UINT32 height = ecwFileInfo->nSizeY;
	UINT32 numberOfBand = NCSMin(3, ecwFileInfo->nBands);
	std::vector<UINT32> bandList;
	for (UINT32 bandIndex = 0; bandIndex < numberOfBand; bandIndex++)
		bandList.push_back(bandIndex);

	//Automatically generate a view region 
	ViewSizeInfo viewSizeInfo = GennerateViewRegion(width, height);

	CError ecwSetViewErr = ecwFileView->SetView(
						numberOfBand,
						&bandList[0], 
						viewSizeInfo.StartX, viewSizeInfo.StartY, viewSizeInfo.EndX - 1, viewSizeInfo.EndY - 1,
						viewSizeInfo.EndX - viewSizeInfo.StartX, viewSizeInfo.EndY - viewSizeInfo.StartY 
						);
	
	if (!ecwFileErr.Success())
	{
#ifdef WIN32
		std::cout << "View setting error due to " << ecwFileErr.GetErrorMessage() << std::endl;
#else
		printf("View setting error due to %ls",ecwFileErr.GetErrorMessage().c_str());
#endif
	}

	//allocate a buffer for reading the file
	SDK::CBuffer2DVector Buffers;
	Buffers.resize(numberOfBand);
	for( UINT32 b = 0; b < numberOfBand; b++ ) 
	{
		Buffers[b].Alloc(viewSizeInfo.EndX - viewSizeInfo.StartX, viewSizeInfo.EndY - viewSizeInfo.StartY,
			NCS::SDK::CBuffer2D::BT_INT16);
	}

	//Read the view content into the buffer
	NCSReadStatus readErr = ecwFileView->Read(Buffers, ecwFileInfo->eCellType);

	//Access the buffer content by coordinate of x, y 
	bool bMessageSent = false;
	if(readErr == NCS_READ_OK) 
	{
		for( UINT32 y = 0; y < viewSizeInfo.EndY - viewSizeInfo.StartY; y++ ) 
		{
			for( UINT32 x = 0; x < viewSizeInfo.EndX - viewSizeInfo.StartX; x++ ) 
			{
				UINT32 nPixel = 0;
				if( numberOfBand == 1 ) 
				{
					UINT32 nVal = *((BYTE *)Buffers[0].GetPtr(x, y));
					nPixel = nVal | nVal << 8 | nVal << 16;	
				} 
				else if( numberOfBand == 3 ) 
				{
					UINT32 nR = *((BYTE *)Buffers[0].GetPtr(x, y)); //Get band 0 pixel value at (x, y)
					UINT32 nG = *((BYTE *)Buffers[1].GetPtr(x, y)); //Get band 1 pixel value at (x, y)
					UINT32 nB = *((BYTE *)Buffers[2].GetPtr(x, y)); //Get band 2 pixel value at (x, y)
					nPixel = nB | nG << 8 | nR << 16;	//Combine them into a 3 bytes rgb value
				}
				if (!bMessageSent) 
				{
					printf("ToDo: Write your code here to render on UI or save to a file");
					bMessageSent = true;
				}

			}
			
		}	
	}

	for( UINT32 b = 0; b < numberOfBand; b++ ) 
	{
		Buffers[b].Free();
	}

	return 0;
}

