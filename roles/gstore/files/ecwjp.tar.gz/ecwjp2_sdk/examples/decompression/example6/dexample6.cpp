/********************************************************** 
** Copyright, 1998 - 2013, Intergraph Corporation. All rights reserved.
**
** FILE:   	example6.cpp
** CREATED:	June 2010
** AUTHOR: 	Chris Tapley
** PURPOSE: An example on how to use the header editor C interface to set editInfo
**********************************************************/
#ifdef WIN32
#include "stdafx.h"
#endif
#include "NCSUtil.h"
#include "NCSEcw/API/HeaderEditor.h"
#include "NCSEcw/API/View.h"

bool ParseArgs(int argc, char* argv[], NCSEditInfo* pEditInfo) {
	CNCSString sArg, sValue;
	bool bValid = true;

	for(int i = 2; i < argc-1 && bValid; i++) {
		sArg = CNCSString(argv[i]);
		char *szArg = (char*)sArg.a_str();
		if(szArg[0] == '-' || szArg[0] == '/') { 
			if(strcmp(szArg, "-proj") == 0) {
				sValue = CNCSString(argv[++i]);
				if(sValue.size() > 0) {
					if (pEditInfo->szProjection)
					{
						NCSFree(pEditInfo->szProjection);
					}
					pEditInfo->szProjection = NCSStrDup((char*)sValue.a_str());
				} else {
					bValid = false;
				}
			} else if(strcmp(szArg, "-datum") == 0) {
				sValue = CNCSString(argv[++i]);
				if(sValue.size() > 0) {
					if (pEditInfo->szDatum)
					{
						NCSFree(pEditInfo->szDatum);
					}
					pEditInfo->szDatum = NCSStrDup((char*)sValue.a_str());
				} else {
					bValid = false;
				}
			} else if(strcmp(szArg, "-originx") == 0) {
				sValue = CNCSString(argv[++i]);
				try {
					pEditInfo->fOriginX = atof(sValue.a_str());
				} catch(...) {
					bValid = false;
				}
			} else if(strcmp(szArg, "-originy") == 0) {
				sValue = CNCSString(argv[++i]);
				try {
					pEditInfo->fOriginY = atof(sValue.a_str());
				} catch(...) {
					bValid = false;
				}
			} else if(strcmp(szArg, "-cellx") == 0) {
				sValue = CNCSString(argv[++i]);
				try {
					pEditInfo->fCellIncrementX = atof(sValue.a_str());
				} catch(...) {
					bValid = false;
				}
			} else if(strcmp(szArg, "-celly") == 0) {
				sValue = CNCSString(argv[++i]);
				try {
					pEditInfo->fCellIncrementY = atof(sValue.a_str());
				} catch(...) {
					bValid = false;
				}
			}
		}
	}
	return bValid;
}

void PrintComparison(NCSEditInfo *pOld, NCSEditInfo *pNew)
{
	printf("ORIGINAL:\nNCSEditInfo {\n");
	//printf("\tnVersion:\t%d\n", pOld->nVersion);
	printf("\tfCellIncX:\t%f\n", pOld->fCellIncrementX);
	printf("\tfCellIncY:\t%f\n", pOld->fCellIncrementY);
	printf("\tfOriginX:\t%f\n", pOld->fOriginX);
	printf("\tfOriginY:\t%f\n", pOld->fOriginY);
	printf("\tszDatum:\t%s\n", pOld->szDatum);
	printf("\tszProjection:\t%s\n", pOld->szProjection);
	//printf("\tEPSGcode:\t%d\n", pOld->EPSGcode);
	printf("}\n\n");

	printf("\nUPDATED:\nNCSEditInfo {\n");
	//printf("\tnVersion:\t%d\n", pNew->nVersion);
	printf("\tfCellIncX:\t%f\n", pNew->fCellIncrementX);
	printf("\tfCellIncY:\t%f\n", pNew->fCellIncrementY);
	printf("\tfOriginX:\t%f\n", pNew->fOriginX);
	printf("\tfOriginY:\t%f\n", pNew->fOriginY);
	printf("\tszDatum:\t%s\n", pNew->szDatum);
	printf("\tszProjection:\t%s\n", pNew->szProjection);
	//printf("\tEPSGcode:\t%d\n", pNew->EPSGcode);
	printf("}\n\n");
}

int main(int argc, char* argv[])
{
	CNCSError Error;
	NCSTChar* wFileName = NULL;
	if(argc < 4) {
		printf("Usage: %s file [-proj PROJECTION] [-datum DATUM] [-originx ORIGINX]\n", argv[0]);
		printf("  [-originy ORIGINY] [-cellx CELLX] [-celly CELLY]\n\n");
		exit(1);
	}

	NCS::CApplication App;

	NCSEditInfo *pOriginalInfo = NULL;
	NCSEditInfo *pEditInfoForEditing = NULL;

	NCSUtf8Decode(argv[1], &wFileName);
	if((Error = NCSEditReadInfo(wFileName, &pOriginalInfo)) != NCS_SUCCESS) {
		printf("Failed to read original edit info.\n\n%s\n\n", NCSGetErrorText(Error));
		goto exit;
	}

	NCSEditCopyInfo(pOriginalInfo, &pEditInfoForEditing);

	if(ParseArgs(argc, argv, pEditInfoForEditing)) {
		if((Error = NCSEditWriteInfo(wFileName, pEditInfoForEditing, NULL, NULL, NULL)) != NCS_SUCCESS) {
			printf("Failed to write to the file.\n\n%s\n\n", NCSGetErrorText(Error));
			goto exit;
		}
	} else {
		printf("Invalid argument.\n\n");
		goto exit;

	}
	printf("Operation Completed Successfully.\n\n");

	PrintComparison(pOriginalInfo, pEditInfoForEditing);
	NCSEditFreeInfo(pOriginalInfo);
	NCSEditFreeInfo(pEditInfoForEditing);
	NCSFree(wFileName);
	exit:

	return 0;

}

